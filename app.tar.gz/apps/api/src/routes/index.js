import { Router } from 'express';
import healthCheck from './health-check.js';
import sms from './sms.js';
import { sendOtp, verifyOtp } from './otp.js';

const router = Router();

export default () => {
    router.get('/health', healthCheck);
    router.post('/sms', sms);
    router.post('/otp/send', sendOtp);
    router.post('/otp/verify', verifyOtp);

    return router;
};

