const ARKESEL_API_KEY = "SmpUeUFsRWZsd3BKZGJ6bElMang";
const ARKESEL_BASE = "https://sms.arkesel.com/sms/api";

// Registered sender / message IDs
export const SENDER_IDS = {
  default: "TeNDA PPD",
  transfer: "Transfer",
};

export default async (req, res) => {
  const { to, message, senderId } = req.body;
  if (!to || !message) {
    return res.status(422).json({ error: "to and message are required" });
  }

  const from = SENDER_IDS[senderId] || senderId || SENDER_IDS.default;
  const phone = String(to).replace(/\s+/g, "").replace(/^\+/, "");
  const url = `${ARKESEL_BASE}?action=send-sms&api_key=${ARKESEL_API_KEY}&to=${encodeURIComponent(phone)}&from=${encodeURIComponent(from)}&sms=${encodeURIComponent(message)}`;

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Arkesel SMS failed: ${response.status} ${response.statusText}`);
  }

  const data = await response.json().catch(() => ({}));
  res.json({ success: true, data, from });
};
