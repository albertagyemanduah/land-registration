import pocketbaseClient from "../utils/pocketbaseClient.js";

const ARKESEL_API_KEY = "SmpUeUFsRWZsd3BKZGJ6bElMang";
const ARKESEL_BASE = "https://sms.arkesel.com/sms/api";
const SENDER_ID = "TNDA";

async function sendSms(to, message) {
  if (!to) return;
  const phone = String(to).replace(/\s+/g, "").replace(/^\+/, "");
  const url = `${ARKESEL_BASE}?action=send-sms&api_key=${ARKESEL_API_KEY}&to=${encodeURIComponent(phone)}&from=${encodeURIComponent(SENDER_ID)}&sms=${encodeURIComponent(message)}`;
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`SMS failed: ${res.status} ${res.statusText}`);
  } catch (_) {}
}

export const sendOtp = async (req, res) => {
  const { userId } = req.body;
  if (!userId) return res.status(422).json({ error: "userId is required" });

  // Get user info
  let user;
  try {
    user = await pocketbaseClient.collection("users").getOne(userId);
  } catch (_) {
    return res.status(404).json({ error: "User not found" });
  }

  const code = String(Math.floor(100000 + Math.random() * 900000));
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

  // Save OTP to PocketBase (hook will send email)
  await pocketbaseClient.collection("otp_sessions").create({
    userId,
    email: user.email || "",
    phone: user.phone || "",
    code,
    expiresAt,
    used: false,
  });

  // Send SMS
  const phone = user.phone || user.whatsappNumber;
  if (phone) {
    await sendSms(phone, `TNDA Login Code: ${code}. Valid for 10 minutes. Do not share this code.`);
  }

  // Also send to whatsapp if different
  if (user.whatsappNumber && user.whatsappNumber !== phone) {
    await sendSms(user.whatsappNumber, `TNDA Login Code: ${code}. Valid for 10 minutes. Do not share this code.`);
  }

  res.json({
    success: true,
    emailSent: !!(user.email),
    smsSent: !!(phone),
    maskedEmail: user.email ? user.email.replace(/(.{2}).+(@.+)/, "$1***$2") : null,
    maskedPhone: phone ? phone.slice(0, 4) + "****" + phone.slice(-2) : null,
  });
};

export const verifyOtp = async (req, res) => {
  const { userId, code } = req.body;
  if (!userId || !code) return res.status(422).json({ error: "userId and code are required" });

  // Find matching session
  let sessions;
  try {
    sessions = await pocketbaseClient.collection("otp_sessions").getFullList({
      filter: `userId = "${userId}" && code = "${code}" && used = false`,
      sort: "-created",
      requestKey: `otp-verify-${userId}`,
    });
  } catch (_) {
    return res.status(400).json({ error: "Invalid code" });
  }

  if (!sessions || sessions.length === 0) {
    return res.status(400).json({ error: "Invalid or expired code" });
  }

  const session = sessions[0];
  const expiry = new Date(session.expiresAt).getTime();
  if (Date.now() > expiry) {
    return res.status(400).json({ error: "Code has expired. Please request a new one." });
  }

  // Mark as used
  try {
    await pocketbaseClient.collection("otp_sessions").update(session.id, { used: true });
  } catch (_) {}

  res.json({ success: true, verified: true });
};
