import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

function loadFooterSettings() {
  try {
    return JSON.parse(localStorage.getItem("tnda-footer") || "null") || {};
  } catch {
    return {};
  }
}

export default function PublicFooter() {
  const fs = loadFooterSettings();
  const companyName = fs.companyName || "Techiman North District Assembly";
  const tagline = fs.tagline || "Land Registry System";
  const address = fs.address || "Tuobodom, Bono East Region, Ghana";
  const phone = fs.phone || "+233 XX XXX XXXX";
  const email = fs.email || "info@tenda.gov.gh";
  const copyright = fs.copyright || `© ${new Date().getFullYear()} Techiman North District Assembly. All rights reserved.`;
  const developerName = fs.developerName || "Albert Fordjour Antwi";
  const developerTitle = fs.developerTitle || "Head, MIS Unit-TeNDA";
  const showDeveloper = fs.showDeveloper !== false; // default true

  return (
    <footer className="border-t border-border bg-card dark:bg-card">
      <div className="mx-auto max-w-[80rem] px-5 py-10">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary font-display text-xs font-extrabold text-primary-foreground">TN</span>
              <div>
                <p className="font-display text-sm font-bold">{companyName.split(" ").slice(0, 2).join(" ")}</p>
                <p className="text-xs text-muted-foreground">{tagline}</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed mb-3">
              The official digital land administration platform for the {companyName}, Bono East Region, Ghana.
            </p>
            <div className="space-y-1 text-xs text-muted-foreground">
              {address && <p>{address}</p>}
              {phone && <p>{phone}</p>}
              {email && <p><a href={`mailto:${email}`} className="hover:text-foreground transition">{email}</a></p>}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <p className="font-semibold text-sm mb-3">Quick Links</p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {[
                { to: "/", label: "Home" },
                { to: "/about", label: "About Us" },
                { to: "/services", label: "Services" },
                { to: "/verify-land", label: "Verify Land" },
                { to: "/contact", label: "Contact Us" },
                { to: "/faq", label: "FAQ" },
              ].map((l) => (
                <li key={l.to}><Link to={l.to} className="hover:text-foreground transition">{l.label}</Link></li>
              ))}
            </ul>
          </div>

          {/* Area Councils */}
          <div>
            <p className="font-semibold text-sm mb-3">Area Councils</p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {["Tuobodom", "Offuman", "Aworowa", "Buoyem", "Krobo"].map((ac) => (
                <li key={ac}>{ac}</li>
              ))}
            </ul>
            {/* Social links */}
            {(fs.facebook || fs.twitter || fs.linkedin) && (
              <div className="mt-4 flex gap-2">
                {fs.facebook && <a href={fs.facebook} target="_blank" rel="noreferrer" className="text-xs text-muted-foreground hover:text-foreground transition">Facebook</a>}
                {fs.twitter && <a href={fs.twitter} target="_blank" rel="noreferrer" className="text-xs text-muted-foreground hover:text-foreground transition">Twitter</a>}
                {fs.linkedin && <a href={fs.linkedin} target="_blank" rel="noreferrer" className="text-xs text-muted-foreground hover:text-foreground transition">LinkedIn</a>}
              </div>
            )}
          </div>

          {/* Compliance + Login */}
          <div>
            <p className="font-semibold text-sm mb-3">Compliance</p>
            <ul className="space-y-2 text-xs text-muted-foreground">
              <li>Land Registration Act 2020 (Act 1036)</li>
              <li>Data Protection Act (Act 843)</li>
              <li>Cybersecurity Act (Act 1038)</li>
              <li>Ghana Land Policy 2024</li>
            </ul>
            <Button asChild className="mt-4 w-full bg-accent text-accent-foreground hover:bg-accent/90" size="sm">
              <Link to="/auth">Staff Login</Link>
            </Button>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-8 border-t border-border pt-6 space-y-2">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
            <p>{copyright}</p>
            <p>Bono East Region, Ghana</p>
          </div>
          {showDeveloper && developerName && (
            <div className="text-center text-[11px] text-muted-foreground/70 pt-1 border-t border-border/50">
              Developed &amp; Managed by{" "}
              <span className="font-semibold text-muted-foreground">{developerName}</span>
              {developerTitle && <> &mdash; {developerTitle}</>}
            </div>
          )}
        </div>
      </div>
    </footer>
  );
}
