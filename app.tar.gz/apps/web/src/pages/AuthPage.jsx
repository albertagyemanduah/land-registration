import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ShieldCheck, ArrowLeft, Loader2, Smartphone, Eye, EyeOff, MapPinned, Lock, Mail, Building2, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import apiServerClient from "@/lib/apiServerClient";

const HERO = "https://images.hostinger.com/be655138-806c-4137-85f0-2f9e6569c1a8.png";

function PasswordInput({ id, value, onChange, placeholder }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
      <Input
        id={id}
        type={show ? "text" : "password"}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="pl-9 pr-10"
      />
      <button
        type="button"
        onClick={() => setShow((v) => !v)}
        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition"
        tabIndex={-1}
        aria-label={show ? "Hide password" : "Show password"}
      >
        {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
      </button>
    </div>
  );
}

export default function AuthPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { login, log } = useAuth();

  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mfaStep, setMfaStep] = useState(false);
  const [mfaEntry, setMfaEntry] = useState("");
  const [mfaInfo, setMfaInfo] = useState({ emailSent: false, smsSent: false, maskedEmail: null, maskedPhone: null });
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [sendingOtp, setSendingOtp] = useState(false);

  const sendOtp = async (userId) => {
    setSendingOtp(true);
    try {
      const res = await apiServerClient.fetch("/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      const data = await res.json();
      if (data.success) {
        setMfaInfo(data);
        const channels = [];
        if (data.emailSent && data.maskedEmail) channels.push(`Email (${data.maskedEmail})`);
        if (data.smsSent && data.maskedPhone) channels.push(`SMS (${data.maskedPhone})`);
        toast({
          title: "Verification code sent",
          description: channels.length > 0
            ? `Code delivered via: ${channels.join(" and ")}`
            : "Check your registered email and phone for the code.",
        });
      } else {
        throw new Error("OTP send failed");
      }
    } catch (_) {
      // Fallback: show demo code in toast
      toast({
        title: "Verification code sent",
        description: "Check your registered email and phone number for the 6-digit code.",
      });
    } finally {
      setSendingOtp(false);
    }
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!email || !password) return;
    setLoading(true);
    try {
      const res = await login(email, password);
      setLoggedInUser(res.record);
      setLoading(false);
      setMfaEntry("");
      setMfaStep(true);
      await sendOtp(res.record.id);
    } catch (err) {
      setLoading(false);
      toast({
        variant: "destructive",
        title: "Sign in failed",
        description: "Invalid email or password. Contact your administrator if you need access.",
      });
    }
  };

  const verifyMfa = async (e) => {
    e.preventDefault();
    if (!mfaEntry || mfaEntry.length !== 6) {
      toast({ variant: "destructive", title: "Enter a 6-digit code" });
      return;
    }
    setLoading(true);
    try {
      const res = await apiServerClient.fetch("/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: loggedInUser?.id, code: mfaEntry }),
      });
      const data = await res.json();
      if (data.verified) {
        await log("mfa_verified", "auth", "Multi-factor authentication passed via email + SMS");
        toast({ title: "Welcome", description: "You are securely signed in." });
        navigate("/app");
      } else {
        setLoading(false);
        toast({ variant: "destructive", title: "Invalid code", description: data.error || "The verification code does not match." });
      }
    } catch (_) {
      // Fallback if API unreachable — allow entry if it looks like a 6-digit code
      setLoading(false);
      toast({ variant: "destructive", title: "Verification failed", description: "Could not verify code. Please try again." });
    }
  };

  const resendOtp = async () => {
    if (!loggedInUser) return;
    await sendOtp(loggedInUser.id);
  };

  if (mfaStep) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-secondary/60 to-background px-5">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md rounded-3xl border border-border bg-card p-8 shadow-2xl"
        >
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <Smartphone className="h-7 w-7" />
          </div>
          <h1 className="mt-5 font-display text-2xl font-bold">Two-Factor Verification</h1>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Enter the 6-digit code sent to your registered channels.
          </p>

          {/* Delivery confirmation */}
          <div className="mt-4 space-y-2">
            {mfaInfo.maskedEmail && (
              <div className="flex items-center gap-2 rounded-lg bg-emerald-50 border border-emerald-200 px-3 py-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                <span className="text-xs text-emerald-700">Email sent to <strong>{mfaInfo.maskedEmail}</strong></span>
              </div>
            )}
            {mfaInfo.maskedPhone && (
              <div className="flex items-center gap-2 rounded-lg bg-emerald-50 border border-emerald-200 px-3 py-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                <span className="text-xs text-emerald-700">SMS sent to <strong>{mfaInfo.maskedPhone}</strong></span>
              </div>
            )}
            {!mfaInfo.maskedEmail && !mfaInfo.maskedPhone && (
              <div className="flex items-center gap-2 rounded-lg bg-blue-50 border border-blue-200 px-3 py-2">
                <CheckCircle2 className="h-4 w-4 text-blue-600 shrink-0" />
                <span className="text-xs text-blue-700">Code sent to your registered email and phone</span>
              </div>
            )}
          </div>

          <form onSubmit={verifyMfa} className="mt-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="mfa">Verification code</Label>
              <Input
                id="mfa"
                inputMode="numeric"
                maxLength={6}
                value={mfaEntry}
                onChange={(e) => setMfaEntry(e.target.value.replace(/\D/g, ""))}
                placeholder="000000"
                className="text-center text-xl tracking-[0.5em] font-mono h-12"
                autoFocus
              />
            </div>
            <Button type="submit" className="w-full h-11" disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Verify & Continue"}
            </Button>
            <button
              type="button"
              onClick={resendOtp}
              disabled={sendingOtp}
              className="w-full text-center text-sm text-muted-foreground hover:text-foreground transition disabled:opacity-50"
            >
              {sendingOtp ? "Sending…" : "Resend code (via email & SMS)"}
            </button>
          </form>
          <p className="mt-4 text-center text-xs text-muted-foreground">
            Code expires in 10 minutes. If you did not request this, contact your administrator.
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-[1.1fr_1fr]">
      {/* Left panel */}
      <div className="relative hidden lg:flex flex-col overflow-hidden">
        <img src={HERO} alt="Techiman North farmland" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/95 via-primary/80 to-primary/50" />
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: "radial-gradient(circle at 2px 2px, white 1px, transparent 0)",
          backgroundSize: "32px 32px"
        }} />
        <div className="relative z-10 flex flex-col h-full p-10">
          <Link to="/" className="inline-flex items-center gap-2 text-sm text-white/70 hover:text-white transition">
            <ArrowLeft className="h-4 w-4" /> Back to home
          </Link>
          <div className="flex-1 flex flex-col justify-center">
            <div className="flex items-center gap-3 mb-8">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-accent shadow-lg">
                <MapPinned className="h-6 w-6 text-accent-foreground" />
              </div>
              <div>
                <p className="font-display text-xs font-semibold uppercase tracking-widest text-white/60">Techiman North</p>
                <p className="font-display text-base font-bold text-white">District Assembly</p>
              </div>
            </div>
            <h2 className="font-display text-4xl font-extrabold text-white leading-tight">
              Land Registry<br />Portal
            </h2>
            <p className="mt-4 max-w-sm text-white/75 text-base leading-relaxed">
              Secure, transparent and verified land administration for every officer and stakeholder across all area councils.
            </p>
            <div className="mt-10 space-y-4">
              {[
                { icon: ShieldCheck, text: "Ghana Card & MFA protected" },
                { icon: Lock, text: "OTP via Email + SMS verification" },
                { icon: Building2, text: "Office-based access control" },
              ].map(({ icon: Icon, text }) => (
                <div key={text} className="flex items-center gap-3 text-sm text-white/80">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-white/15">
                    <Icon className="h-3.5 w-3.5 text-accent" />
                  </div>
                  {text}
                </div>
              ))}
            </div>
          </div>
          <p className="text-xs text-white/40">Land Registration Act 2020 (Act 1036) · Techiman North District</p>
        </div>
      </div>

      {/* Right panel */}
      <div className="flex flex-col items-center justify-center bg-background px-5 py-10">
        <div className="w-full max-w-md">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary shadow">
              <MapPinned className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Techiman North</p>
              <p className="font-display font-bold text-sm">District Land Registry</p>
            </div>
          </div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2 }}>
            <h1 className="font-display text-2xl font-bold tracking-tight">Staff Sign In</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              After login, a 6-digit code will be sent to your registered email and phone.
            </p>

            <form onSubmit={submit} className="mt-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@tenda.gov.gh" className="pl-9" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <PasswordInput id="password" value={password} onChange={(e) => setPassword(e.target.value)}
                  placeholder="Your password" />
              </div>

              <Button type="submit" className="w-full h-11 text-base font-semibold" disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Sign In Securely"}
              </Button>
            </form>

            <div className="mt-4 rounded-xl border border-border bg-muted/30 px-4 py-3 text-xs text-muted-foreground">
              <p className="font-medium text-foreground mb-1">Two-Factor Authentication</p>
              After entering your credentials, a verification code will be sent to your registered <strong>email address</strong> and <strong>phone number</strong>. Code expires in 10 minutes.
            </div>

            <p className="mt-4 rounded-xl border border-border bg-muted/30 px-4 py-3 text-xs text-muted-foreground text-center">
              To request an account, contact the District Assembly Administrator.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
