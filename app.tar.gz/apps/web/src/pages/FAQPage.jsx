import React, { useState } from "react";
import { motion } from "framer-motion";
import { ChevronDown, ChevronUp, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import PublicNav from "@/components/PublicNav";
import PublicFooter from "@/components/PublicFooter";
import { cn } from "@/lib/utils";

const FAQS = [
  { cat: "General", q: "Who can use the Techiman North Land Registry System?", a: "The system is for authorized district staff including Planning Officers, Surveyors, Land Registrars, Finance Officers, and District Administrators. Staff accounts are created by the District Assembly Administrator." },
  { cat: "General", q: "What are the Area Councils covered by the system?", a: "The system covers all five Area Councils in the Techiman North District: Tuobodom, Offuman, Aworowa, Buoyem, and Krobo." },
  { cat: "General", q: "Is the system available 24/7?", a: "The online system is available 24/7 for staff login and record viewing. However, physical office services are available Monday–Friday, 8:00am–5:00pm." },
  { cat: "Registration", q: "What documents do I need to register land?", a: "You typically need a site plan, Ghana Card identification, proof of ownership (deed/indenture or allocation letter), and any relevant customary documentation. The system supports uploading all document types securely." },
  { cat: "Registration", q: "How long does land registration take?", a: "The process typically takes 5–14 working days depending on the complexity of the application. Applications with complete documentation and no disputes are processed faster." },
  { cat: "Registration", q: "Can I register land that was given to me by my family or chief?", a: "Yes. Customary land grants and family allocations can be registered. You will need documentation of the customary allocation, witnesses, and a site plan. The Customary Land Secretariat can assist with customary land documentation." },
  { cat: "Registration", q: "What is a Land ID and how is it assigned?", a: "A Land ID (e.g., LAND-001) is a unique identifier assigned to each registered parcel in the district. It is generated automatically during registration and used for all subsequent transactions related to that parcel." },
  { cat: "Payment", q: "What payment methods are accepted?", a: "The system accepts Mobile Money (MTN, Vodafone, AirtelTigo), debit/credit cards, bank transfers, and cash payments at the district office." },
  { cat: "Payment", q: "What is the registration fee?", a: "The standard registration fee starts at GHS 250. Additional fees may apply for surveys (GHS 400+), title searches (GHS 50), and processing (GHS 120). Contact the district office for the current fee schedule." },
  { cat: "Payment", q: "Can I get a receipt for my payment?", a: "Yes. Official receipts are issued for all payments made through the system, both digitally and in hard copy at the district office." },
  { cat: "Security", q: "Is my data secure on this platform?", a: "Yes. All data is encrypted with AES-256, access is controlled by role-based permissions, all actions are immutably logged in an audit trail, and multi-factor authentication (OTP via email and SMS) protects every account." },
  { cat: "Security", q: "What is the two-factor authentication (MFA)?", a: "After entering your email and password, the system sends a 6-digit verification code to your registered email address AND phone number via SMS. You must enter this code to complete your login. The code expires in 10 minutes." },
  { cat: "Security", q: "What happens if I forget my password?", a: "Contact the District Assembly Administrator or your office supervisor to request a password reset. For security, password resets require identity verification." },
  { cat: "Transfers", q: "How do I transfer land to another person?", a: "The current registered owner initiates a transfer request through the system, specifying the new owner's details. The transfer requires approval from the Physical Planning Officer and District Assembly Administrator. Once approved, a transfer certificate is issued." },
  { cat: "Transfers", q: "Who approves land transfers?", a: "Only the Physical Planning Officer and District Assembly Administrator are authorized to approve land transfers. The Land Registrar is responsible for updating the registry after approval." },
  { cat: "Technical", q: "I can't log in to my account. What should I do?", a: "First, ensure you are using your correct @tenda.gov.gh email address. If you've forgotten your password or your account is locked, contact the District Assembly Administrator or submit a support ticket through this website." },
  { cat: "Technical", q: "How do I submit a support ticket?", a: "Log in to your staff account and navigate to 'Support Tickets' in the sidebar. Click 'New Ticket', fill in the subject, category, priority, and description, then submit. You will receive an email confirmation and be notified of all updates." },
];

const CATEGORIES = ["All", "General", "Registration", "Payment", "Security", "Transfers", "Technical"];

function FAQItem({ q, a }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-border last:border-0">
      <button onClick={() => setOpen((v) => !v)} className="flex w-full items-center justify-between gap-4 py-5 text-left">
        <span className="font-medium text-foreground">{q}</span>
        {open ? <ChevronUp className="h-4 w-4 shrink-0 text-primary" /> : <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />}
      </button>
      {open && <p className="pb-5 text-sm leading-relaxed text-muted-foreground">{a}</p>}
    </div>
  );
}

export default function FAQPage() {
  const [cat, setCat] = useState("All");
  const [searchQ, setSearchQ] = useState("");

  const filtered = FAQS.filter((f) => {
    const matchCat = cat === "All" || f.cat === cat;
    const q = searchQ.toLowerCase();
    const matchQ = !q || f.q.toLowerCase().includes(q) || f.a.toLowerCase().includes(q);
    return matchCat && matchQ;
  });

  return (
    <div className="min-h-screen bg-background">
      <PublicNav />

      {/* Hero */}
      <section className="bg-primary pt-16">
        <div className="mx-auto max-w-[80rem] px-5 py-16">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <p className="text-sm font-semibold uppercase tracking-wider text-accent">FAQ</p>
            <h1 className="mt-2 font-display text-4xl font-extrabold text-white sm:text-5xl">Frequently Asked Questions</h1>
            <p className="mt-4 max-w-xl text-lg text-primary-foreground/80">
              Find answers to common questions about land registration, payments, and our system.
            </p>
            {/* Search */}
            <div className="relative mt-8 max-w-lg">
              <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <Input value={searchQ} onChange={(e) => setSearchQ(e.target.value)}
                placeholder="Search FAQ…" className="pl-10 h-12 bg-white text-foreground" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* FAQ Body */}
      <section className="mx-auto max-w-[80rem] px-5 py-16">
        {/* Category filters */}
        <div className="flex flex-wrap gap-2 mb-10">
          {CATEGORIES.map((c) => (
            <button key={c} onClick={() => setCat(c)}
              className={cn("rounded-full px-4 py-1.5 text-sm font-medium transition border",
                cat === c ? "bg-primary text-primary-foreground border-primary" : "border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground")}>
              {c}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-muted/30 p-12 text-center">
            <p className="text-muted-foreground">No FAQs match your search.</p>
          </div>
        ) : (
          <div className="divide-y divide-border rounded-2xl border border-border bg-card px-6">
            {filtered.map((f) => <FAQItem key={f.q} q={f.q} a={f.a} />)}
          </div>
        )}

        <div className="mt-10 rounded-2xl border border-border bg-muted/30 p-6 text-center">
          <p className="font-medium">Still have questions?</p>
          <p className="mt-1 text-sm text-muted-foreground">Contact the Techiman North District Assembly office or visit in person.</p>
          <div className="mt-4 flex flex-wrap justify-center gap-3">
            <a href="mailto:info@tenda.gov.gh" className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2 text-sm font-medium hover:bg-muted transition">
              Email: info@tenda.gov.gh
            </a>
            <a href="tel:+233XXXXXXXX" className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2 text-sm font-medium hover:bg-muted transition">
              Call: +233 XX XXX XXXX
            </a>
          </div>
        </div>
      </section>

      <PublicFooter />
    </div>
  );
}
