import React, { useState, useRef, useMemo, useEffect } from "react";
import {
  MapPinned, Plus, MapPin, Download, Clock, Pencil, FileCheck,
  AlertTriangle, RefreshCw, Filter, Search, Upload, CheckCircle2,
  ChevronDown, ChevronUp, FileSpreadsheet, ArrowRightLeft, Bell,
  XCircle, Check, X, LayoutList, Grid2X2, LayoutGrid, Maximize2,
  Trash2, RotateCcw, Eye,
} from "lucide-react";
import pb from "@/lib/pocketbaseClient";
import { useAuth } from "@/lib/auth";
import { useCollection, notify } from "@/lib/useCollection";
import { PageHeader, StatusBadge, Spinner, EmptyState } from "@/components/shared";
import { titleCase, formatDate } from "@/lib/format";
import { getUserAreaCouncils, ALL_AREA_COUNCILS, OFFICES } from "@/lib/offices";
import { useHierarchy } from "@/hooks/useHierarchy";
import { loadActiveCertTemplate } from "@/lib/certTemplates";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { sendSms } from "@/lib/messaging";
import PaginationControl, { usePagination } from "@/components/Pagination";
import SearchableSelect from "@/components/SearchableSelect";


const STATUSES = ["all", "draft", "submitted", "under_survey", "under_review", "registered", "disputed", "rejected"];

const VIEW_MODES = [
  { key: "medium", label: "Medium", icon: Grid2X2 },
  { key: "list",   label: "List",   icon: LayoutList },
  { key: "small",  label: "Small",  icon: LayoutGrid },
  { key: "large",  label: "Large",  icon: Maximize2 },
];

function getViewMode() {
  try { return localStorage.getItem("parcels_view") || "list"; } catch { return "list"; }
}
function setViewMode(v) {
  try { localStorage.setItem("parcels_view", v); } catch {}
}
const RELIGIONS = ["Christian", "Muslim", "Traditionalist", "Other"];
const TRIBES = ["Akan", "Ewe", "Ga", "Dagomba", "Fante", "Brong", "Bono", "Other"];

const EMPTY_FORM = {
  applicantName: "", contactPhone: "", alternateMobile: "", whatsapp: "", applicantEmail: "",
  religion: "", tribe: "", office: "", areaCouncil: "", community: "", sector: "",
  plotNumber: "", block: "", allocationDate: "", registrationDate: "",
  // Payment fields
  paymentAmount: "", paymentMethod: "", paymentStatus: "pending", paymentDate: "", paymentReference: "", paymentNotes: "",
};

// ── Sequential ID generator ─────────────────────────────────────────────────
let _importSeq = 0;
function genLandId() {
  _importSeq++;
  const year = new Date().getFullYear();
  const seq = String(_importSeq).padStart(3, "0");
  const rand = Math.floor(100 + Math.random() * 900);
  return `LAND-${year}-${seq}${rand}`;
}

// ── UI helpers ───────────────────────────────────────────────────────────────
function FGroup({ label }) {
  return (
    <h4 className="mt-1 border-b border-border pb-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
      {label}
    </h4>
  );
}
function FRow({ children }) { return <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">{children}</div>; }
function FF({ label, required, children }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-medium">
        {label}{required && <span className="ml-0.5 text-destructive">*</span>}
      </Label>
      {children}
    </div>
  );
}

// ── Certificate ──────────────────────────────────────────────────────────────
const CERT_FIELD_LABELS = {
  parcelNumber: "Land / Parcel ID", applicantName: "Name of Applicant",
  areaCouncil: "Area Council", community: "Community", sector: "Sector",
  plotNumber: "Plot Number", block: "Block", allocationDate: "Allocation Date",
  registrationDate: "Registration Date", contactPhone: "Mobile",
  alternateMobile: "Alternate Mobile", whatsapp: "WhatsApp",
  applicantEmail: "Email", tribe: "Tribe", religion: "Religion", status: "Status",
};

function CertificateModal({ parcel, onClose }) {
  const tpl = loadActiveCertTemplate();
  const { toast } = useToast();

  // Determine which fields to show: if template exists use its fields, else show all
  const fieldKeys = tpl
    ? Object.entries(tpl.fields || {}).filter(([, v]) => v !== false).map(([k]) => k)
    : Object.keys(CERT_FIELD_LABELS);

  const activeFields = (fieldKeys.length > 0 ? fieldKeys : Object.keys(CERT_FIELD_LABELS))
    .map((k) => ({ key: k, label: CERT_FIELD_LABELS[k] || k }));

  const getValue = (key) => {
    const v = parcel[key];
    if (!v) return "—";
    if (key.includes("Date")) return formatDate(v);
    return v;
  };

  const printCertificate = () => {
    const printWin = window.open("", "_blank", "width=800,height=1100");
    if (!printWin) { toast({ variant: "destructive", title: "Pop-up blocked. Allow pop-ups for this site." }); return; }
    const rows = activeFields.map(({ key, label }) => `
      <tr>
        <td style="padding:7px 12px;border-bottom:1px solid #e5e7eb;color:#6b7280;font-weight:500;width:40%">${label}</td>
        <td style="padding:7px 12px;border-bottom:1px solid #e5e7eb;font-weight:600">${getValue(key)}</td>
      </tr>`).join("");
    const bgImg = tpl?.imageData ? `background-image:url(${tpl.imageData});background-size:cover;background-position:center;` : "";
    printWin.document.write(`<!DOCTYPE html><html><head><title>Land Certificate — ${parcel.parcelNumber}</title>
      <style>body{font-family:Georgia,serif;margin:0;padding:0} @media print{body{margin:0}}</style></head>
      <body style="${bgImg}">
      <div style="background:rgba(255,255,255,0.93);min-height:100vh;padding:40px 50px;box-sizing:border-box">
        <div style="text-align:center;border-bottom:3px double #1a4731;padding-bottom:20px;margin-bottom:24px">
          <p style="margin:0;font-size:11px;color:#6b7280;text-transform:uppercase;letter-spacing:2px">Republic of Ghana · Techiman North District Assembly</p>
          <h1 style="margin:8px 0 4px;font-size:26px;color:#1a4731">${tpl?.headerText || "LAND USE CERTIFICATE"}</h1>
          <p style="margin:0;font-size:12px;color:#6b7280">Certificate No: ${parcel.parcelNumber}</p>
        </div>
        <table style="width:100%;border-collapse:collapse;font-size:13px">${rows}</table>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:60px;margin-top:50px">
          <div style="text-align:center"><div style="height:60px;border-bottom:2px dashed #ccc;margin-bottom:8px"></div><p style="font-size:11px;color:#6b7280;margin:0">Land Registrar Signature & Stamp</p></div>
          <div style="text-align:center"><div style="height:60px;border-bottom:2px dashed #ccc;margin-bottom:8px"></div><p style="font-size:11px;color:#6b7280;margin:0">District Assembly Administrator</p></div>
        </div>
        <div style="text-align:center;margin-top:40px;border-top:2px solid #1a4731;padding-top:16px">
          <p style="font-size:11px;color:#6b7280;margin:0">${tpl?.footerText || "Issued under the Land Registration Act 2020 (Act 1036)."}</p>
          <p style="font-size:10px;color:#9ca3af;margin:6px 0 0">Issued: ${new Date().toLocaleDateString("en-GH", { year: "numeric", month: "long", day: "numeric" })}</p>
        </div>
      </div></body></html>`);
    printWin.document.close();
    printWin.focus();
    setTimeout(() => { printWin.print(); }, 500);
    onClose();
  };

  const downloadTxt = () => {
    const lines = [
      tpl?.headerText || "LAND USE CERTIFICATE",
      "Techiman North District Assembly",
      "─".repeat(50),
      ...activeFields.map(({ key, label }) => `${label.padEnd(25)}: ${getValue(key)}`),
      "─".repeat(50),
      tpl?.footerText || "Issued under the Land Registration Act 2020 (Act 1036).",
      `Issued: ${new Date().toLocaleDateString()}`,
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `certificate-${parcel.parcelNumber}.txt`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {tpl && (
        <div className="flex items-center gap-2 rounded-lg bg-primary/5 border border-primary/20 px-3 py-2">
          <FileCheck className="h-4 w-4 text-primary shrink-0" />
          <p className="text-xs text-primary font-medium">Using template: <strong>{tpl.name}</strong></p>
        </div>
      )}
      <div className="relative rounded-xl border-2 border-primary/20 overflow-hidden">
        {tpl?.imageData && (
          <img src={tpl.imageData} alt="Template" className="absolute inset-0 w-full h-full object-cover opacity-10" />
        )}
        <div className="relative z-10 bg-gradient-to-br from-primary/5 to-accent/5 p-5">
          <div className="mb-4 text-center border-b border-primary/20 pb-4">
            <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Republic of Ghana · Techiman North District Assembly</p>
            <h3 className="font-display text-lg font-bold text-primary mt-1">{tpl?.headerText || "LAND USE CERTIFICATE"}</h3>
            <p className="text-xs text-muted-foreground">No: {parcel.parcelNumber}</p>
          </div>
          <div className="space-y-1.5">
            {activeFields.map(({ key, label }) => (
              <div key={key} className="flex justify-between gap-4 border-b border-border/60 py-1.5 text-sm last:border-0">
                <span className="shrink-0 text-muted-foreground">{label}</span>
                <span className="text-right font-medium">{getValue(key)}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 border-t border-primary/20 pt-3 text-center">
            <p className="text-[10px] text-muted-foreground">{tpl?.footerText || "Issued under the Land Registration Act 2020 (Act 1036)."}</p>
          </div>
        </div>
      </div>
      <div className="flex gap-2">
        <Button onClick={printCertificate} className="flex-1"><Download className="mr-2 h-4 w-4" /> Print / Save PDF</Button>
        <Button variant="outline" onClick={downloadTxt}><Download className="mr-1 h-4 w-4" /> .txt</Button>
      </div>
      {!tpl && (
        <p className="text-center text-xs text-muted-foreground">No template configured. Go to Admin → Certificates to add one.</p>
      )}
    </div>
  );
}

// ── History ──────────────────────────────────────────────────────────────────
function HistoryModal({ parcel }) {
  const [transfers, setTransfers] = useState([]);
  useEffect(() => {
    pb.collection("land_transfers").getFullList({
      filter: `parcel = "${parcel.id}"`, sort: "-created", requestKey: `hist-${parcel.id}`,
    }).then(setTransfers).catch(() => {});
  }, [parcel.id]);

  const history = [
    { date: parcel.created, event: "Parcel registered", by: "Applicant" },
    { date: parcel.updated, event: `Status: ${titleCase(parcel.status)}`, by: "System" },
    parcel.allocationDate && { date: parcel.allocationDate, event: "Land allocated", by: "Authority" },
    parcel.registrationDate && { date: parcel.registrationDate, event: "Title registered", by: "Land Registrar" },
    ...transfers.map((t) => ({
      date: t.updated,
      event: `Transfer ${t.status}: to ${t.toOwnerName || "new owner"}`,
      by: "Land Registry",
    })),
  ].filter(Boolean).sort((a, b) => new Date(a.date) - new Date(b.date));

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">History for <strong>{parcel.parcelNumber}</strong></p>
      <ol className="space-y-3 border-l-2 border-primary/20 pl-5">
        {history.map((h, i) => (
          <li key={i} className="relative text-sm">
            <span className="absolute -left-[21px] top-1.5 h-2.5 w-2.5 rounded-full bg-primary" />
            <p className="font-semibold">{h.event}</p>
            <p className="text-xs text-muted-foreground">{h.by} · {formatDate(h.date)}</p>
          </li>
        ))}
      </ol>
    </div>
  );
}

// ── Transfer Modal ───────────────────────────────────────────────────────────
function TransferModal({ parcel, userId, onClose, onDone }) {
  const { toast } = useToast();
  const [allUsers, setAllUsers] = useState([]);
  const [form, setForm] = useState({ toOwnerUser: "", toOwnerName: "", toOwnerPhone: "", reason: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    pb.collection("users").getFullList({ sort: "fullName", requestKey: "transfer-users" })
      .then((u) => setAllUsers(u.filter((x) => x.id !== userId)))
      .catch(() => {});
  }, [userId]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e?.target ? e.target.value : e }));

  const submit = async () => {
    if (!form.toOwnerName && !form.toOwnerUser) {
      toast({ variant: "destructive", title: "Specify new owner name or select an existing user" });
      return;
    }
    setSaving(true);
    try {
      const selectedUser = form.toOwnerUser ? allUsers.find((u) => u.id === form.toOwnerUser) : null;
      const ownershipHistory = {
        previousOwner: parcel.expand?.owner?.fullName || parcel.owner,
        previousOwnerId: parcel.owner,
        transferDate: new Date().toISOString(),
      };
      await pb.collection("land_transfers").create({
        parcel: parcel.id,
        fromOwner: userId,
        toOwnerUser: form.toOwnerUser || null,
        toOwnerName: selectedUser ? (selectedUser.fullName || selectedUser.email) : form.toOwnerName,
        toOwnerPhone: form.toOwnerPhone,
        reason: form.reason,
        ownershipHistory: [ownershipHistory],
        status: "pending",
        certificateNumber: `TRF-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      });
      toast({ title: "Transfer request submitted", description: "Awaiting approval from Land Registrar or Admin." });
      onDone?.();
      onClose();
    } catch (err) {
      toast({ variant: "destructive", title: "Failed", description: err?.message });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800">
        <AlertTriangle className="inline h-4 w-4 mr-1" />
        Transfers require approval from the Land Registrar or Admin.
      </div>
      <FF label="New Owner (existing user)">
        <Select value={form.toOwnerUser || "none"} onValueChange={(v) => setForm((f) => ({ ...f, toOwnerUser: v === "none" ? "" : v }))}>
          <SelectTrigger><SelectValue placeholder="Select registered user (optional)" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="none">— Enter manually below —</SelectItem>
            {allUsers.map((u) => <SelectItem key={u.id} value={u.id}>{u.fullName || u.email}</SelectItem>)}
          </SelectContent>
        </Select>
      </FF>
      {!form.toOwnerUser && (
        <FRow>
          <FF label="New Owner Full Name" required>
            <Input value={form.toOwnerName} onChange={set("toOwnerName")} placeholder="Full legal name" />
          </FF>
          <FF label="New Owner Phone">
            <Input value={form.toOwnerPhone} onChange={set("toOwnerPhone")} placeholder="+233 XX XXX XXXX" />
          </FF>
        </FRow>
      )}
      <FF label="Transfer Reason">
        <Input value={form.reason} onChange={set("reason")} placeholder="e.g. Sale, inheritance, gift…" />
      </FF>
      <div className="flex gap-2 pt-1">
        <Button variant="outline" onClick={onClose} className="flex-1">Cancel</Button>
        <Button onClick={submit} disabled={saving} className="flex-1">
          {saving ? "Submitting…" : "Submit Transfer Request"}
        </Button>
      </div>
    </div>
  );
}

// ── Edit Request Modal (for registered parcels) ──────────────────────────────
function EditRequestModal({ parcel, userId, onClose, onDone }) {
  const { toast } = useToast();
  const [form, setForm] = useState({
    applicantName: parcel.applicantName || "", contactPhone: parcel.contactPhone || "",
    alternateMobile: parcel.alternateMobile || "", whatsapp: parcel.whatsapp || "",
    applicantEmail: parcel.applicantEmail || "", religion: parcel.religion || "",
    tribe: parcel.tribe || "", areaCouncil: parcel.areaCouncil || "",
    community: parcel.community || "", sector: parcel.sector || "",
    plotNumber: parcel.plotNumber || "", block: parcel.block || "",
    allocationDate: parcel.allocationDate?.split(" ")[0] || "",
    registrationDate: parcel.registrationDate?.split(" ")[0] || "",
  });
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e?.target ? e.target.value : e }));

  const submit = async () => {
    setSaving(true);
    try {
      await pb.collection("land_edit_requests").create({
        parcel: parcel.id,
        requestedBy: userId,
        type: "edit",
        proposedChanges: form,
        reason,
        status: "pending",
      });
      toast({ title: "Edit request submitted", description: "Awaiting approval from Planning Officer or Admin." });
      onDone?.();
      onClose();
    } catch (err) {
      toast({ variant: "destructive", title: "Failed", description: err?.message });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800">
        <AlertTriangle className="inline h-4 w-4 mr-1" />
        Edits to registered parcels require approval from Planning Officer or Admin.
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {Object.entries(form).map(([k, v]) => (
          <FF key={k} label={titleCase(k)}>
            <Input value={v} onChange={set(k)} placeholder={k} type={k.includes("Date") ? "date" : "text"} />
          </FF>
        ))}
      </div>
      <FF label="Reason for edit" required>
        <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Explain the reason for this change" />
      </FF>
      <div className="flex gap-2 pt-1">
        <Button variant="outline" onClick={onClose} className="flex-1">Cancel</Button>
        <Button onClick={submit} disabled={saving} className="flex-1">{saving ? "Submitting…" : "Submit Edit Request"}</Button>
      </div>
    </div>
  );
}

// ── Approvals Panel ──────────────────────────────────────────────────────────
function ApprovalsPanel({ userId, isApprover, reload: reloadParcels }) {
  const { toast } = useToast();
  const [requests, setRequests] = useState([]);
  const [transfers, setTransfers] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [reqs, trfs] = await Promise.all([
        pb.collection("land_edit_requests").getFullList({
          filter: isApprover ? "status = 'pending'" : `requestedBy = "${userId}" && status = 'pending'`,
          sort: "-created", expand: "parcel,requestedBy", requestKey: "approvals-reqs",
        }),
        pb.collection("land_transfers").getFullList({
          filter: isApprover ? "status = 'pending'" : `fromOwner = "${userId}" && status = 'pending'`,
          sort: "-created", expand: "parcel,fromOwner", requestKey: "approvals-trfs",
        }),
      ]);
      setRequests(reqs);
      setTransfers(trfs);
    } catch (_) {}
    setLoading(false);
  };

  useEffect(() => { loadAll(); }, [isApprover, userId]);

  const reviewRequest = async (req, action, comment = "") => {
    try {
      await pb.collection("land_edit_requests").update(req.id, {
        status: action,
        reviewedBy: userId,
        reviewComment: comment,
      });
      if (action === "approved" && req.type === "edit") {
        await pb.collection("parcels").update(req.parcel, req.proposedChanges);
      }
      if (action === "approved" && req.type === "delete") {
        await pb.collection("parcels").delete(req.parcel);
      }
      // Notify requester (in-app + SMS)
      try {
        const p = req.expand?.parcel || await pb.collection("parcels").getOne(req.parcel, { requestKey: `rp-${req.id}` });
        const requester = req.expand?.requestedBy;
        await notify(req.requestedBy, `Your ${req.type} request for ${p.parcelNumber} was ${action}. ${comment || ""}`.trim(), "/app/parcels");
        const ph = requester?.phone || requester?.whatsappNumber || p.contactPhone;
        if (ph) await sendSms(ph, `Dear ${requester?.fullName || "applicant"}, your ${req.type} request for land ${p.parcelNumber} (Plot ${p.plotNumber || "N/A"}/Block ${p.block || "N/A"}, ${p.areaCouncil || "N/A"}) has been ${action.toUpperCase()}.${comment ? " Reason: " + comment : ""} - TeNDA PPD`);
      } catch (_) {}
      toast({ title: `Request ${action}` });
      loadAll();
      reloadParcels();
    } catch (err) {
      toast({ variant: "destructive", title: "Failed", description: err?.message });
    }
  };

  const reviewTransfer = async (trf, action, comment = "") => {
    try {
      await pb.collection("land_transfers").update(trf.id, {
        status: action,
        reviewedBy: userId,
        reviewComment: comment,
      });
      if (action === "approved") {
        // Capture previous owner for ownership history
        let prevOwnerData = {};
        try {
          const prevParcel = await pb.collection("parcels").getOne(trf.parcel, { requestKey: `prev-p-${trf.id}` });
          prevOwnerData = {
            name: prevParcel.applicantName,
            phone: prevParcel.contactPhone,
            email: prevParcel.applicantEmail,
            transferredAt: new Date().toISOString(),
            transferRef: trf.id,
          };
        } catch (_) {}

        // Update parcel ownership with full new owner details
        const parcelUpdates = {
          ownershipHistory: JSON.stringify({
            previous: prevOwnerData,
            transferId: trf.id,
            transferDate: new Date().toISOString(),
          }),
        };
        if (trf.toOwnerUser) parcelUpdates.owner = trf.toOwnerUser;
        if (trf.toOwnerName) parcelUpdates.applicantName = trf.toOwnerName;
        if (trf.toOwnerPhone) {
          parcelUpdates.contactPhone = trf.toOwnerPhone;
          parcelUpdates.alternateMobile = trf.toOwnerPhone;
          parcelUpdates.whatsapp = trf.toOwnerPhone;
        }
        // Clear old email if new owner is a registered user (they have their own email)
        if (trf.toOwnerUser) parcelUpdates.applicantEmail = "";
        await pb.collection("parcels").update(trf.parcel, parcelUpdates, { requestKey: `trf-own-${trf.id}` });

        // Log ownership transfer in audit trail
        try {
          await pb.collection("audit_logs").create({
            actor: userId,
            action: "ownership_transferred",
            entity: trf.parcel,
            details: JSON.stringify({
              transferId: trf.id,
              previousOwner: prevOwnerData.name,
              newOwner: trf.toOwnerName,
              newOwnerPhone: trf.toOwnerPhone,
              newOwnerUserId: trf.toOwnerUser || null,
              date: new Date().toISOString(),
            }),
          });
        } catch (_) {}
      }
      // Notify both parties on transfer approval (in-app + SMS)
      try {
        const p = trf.expand?.parcel || await pb.collection("parcels").getOne(trf.parcel, { requestKey: `tp-${trf.id}` });
        const oldOwner = trf.expand?.fromOwner;
        const landDesc = `Plot ${p.plotNumber || "N/A"}/Block ${p.block || "N/A"} in ${p.areaCouncil || "N/A"}`;
        const refNum = trf.certificateNumber || trf.id;
        const dateStr = new Date().toLocaleDateString("en-GH");
        if (action === "approved") {
          const oldPh = oldOwner?.phone || oldOwner?.whatsappNumber || p.contactPhone;
          if (oldPh) await sendSms(oldPh, `Dear ${oldOwner?.fullName || "owner"}, your land (${landDesc}) has been transferred to ${trf.toOwnerName || "new owner"} (${trf.toOwnerPhone || "N/A"}). Transfer Ref: ${refNum}. Date: ${dateStr}. - Transfer`, "transfer");
          await notify(trf.fromOwner, `Transfer of ${p.parcelNumber} to ${trf.toOwnerName} approved.`, "/app/parcels");
          if (trf.toOwnerUser) await notify(trf.toOwnerUser, `You received land ${p.parcelNumber} from ${oldOwner?.fullName || "previous owner"}.`, "/app/parcels");
          if (trf.toOwnerPhone) await sendSms(trf.toOwnerPhone, `Dear ${trf.toOwnerName || "new owner"}, you have received land (${landDesc}) from ${oldOwner?.fullName || "previous owner"}. Transfer Ref: ${refNum}. Date: ${dateStr}. Your certificate will be updated shortly. - Transfer`, "transfer");
        } else {
          await notify(trf.fromOwner, `Transfer request for ${p.parcelNumber} was ${action}.${comment ? " " + comment : ""}`, "/app/parcels");
          const oldPh = oldOwner?.phone || oldOwner?.whatsappNumber || p.contactPhone;
          if (oldPh) await sendSms(oldPh, `Dear ${oldOwner?.fullName || "owner"}, your transfer request for ${landDesc} was ${action.toUpperCase()}.${comment ? " Reason: " + comment : ""} - Transfer`, "transfer");
        }
      } catch (_) {}
      toast({ title: `Transfer ${action}` });
      loadAll();
      reloadParcels();
    } catch (err) {
      toast({ variant: "destructive", title: "Failed", description: err?.message });
    }
  };

  const total = requests.length + transfers.length;
  if (total === 0 && !loading) return null;

  return (
    <div className="rounded-2xl border border-amber-200 bg-amber-50/60 shadow-sm overflow-hidden">
      <div className="flex items-center gap-2 border-b border-amber-200 bg-amber-100/60 px-5 py-3">
        <Bell className="h-4 w-4 text-amber-700" />
        <h3 className="font-display text-sm font-semibold text-amber-900">
          {isApprover ? "Pending Approvals" : "My Pending Requests"} ({total})
        </h3>
      </div>
      {loading ? <div className="p-4"><Spinner /></div> : (
        <div className="divide-y divide-amber-200">
          {requests.map((req) => (
            <div key={req.id} className="px-5 py-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-medium">
                    {titleCase(req.type)} request — {req.expand?.parcel?.parcelNumber || req.parcel}
                  </p>
                  {isApprover && req.expand?.requestedBy && (
                    <p className="text-xs text-muted-foreground">By: {req.expand.requestedBy.fullName || req.expand.requestedBy.email}</p>
                  )}
                  {req.reason && <p className="text-xs text-muted-foreground mt-0.5">Reason: {req.reason}</p>}
                  <p className="text-xs text-muted-foreground">{formatDate(req.created)}</p>
                </div>
                {isApprover && (
                  <div className="flex gap-1.5 shrink-0">
                    <Button size="sm" variant="outline" className="h-7 text-xs text-emerald-700 border-emerald-200 hover:bg-emerald-50"
                      onClick={() => reviewRequest(req, "approved")}>
                      <Check className="h-3.5 w-3.5 mr-1" /> Approve
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 text-xs text-red-700 border-red-200 hover:bg-red-50"
                      onClick={() => reviewRequest(req, "rejected", "Rejected by reviewer")}>
                      <X className="h-3.5 w-3.5 mr-1" /> Reject
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ))}
          {transfers.map((trf) => (
            <div key={trf.id} className="px-5 py-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-medium">
                    Transfer request — {trf.expand?.parcel?.parcelNumber || trf.parcel}
                  </p>
                  <p className="text-xs text-muted-foreground">To: {trf.toOwnerName || "—"} {trf.toOwnerPhone && `(${trf.toOwnerPhone})`}</p>
                  {trf.reason && <p className="text-xs text-muted-foreground">Reason: {trf.reason}</p>}
                  <p className="text-xs text-muted-foreground">{formatDate(trf.created)}</p>
                </div>
                {isApprover && (
                  <div className="flex gap-1.5 shrink-0">
                    <Button size="sm" variant="outline" className="h-7 text-xs text-emerald-700 border-emerald-200 hover:bg-emerald-50"
                      onClick={() => reviewTransfer(trf, "approved")}>
                      <Check className="h-3.5 w-3.5 mr-1" /> Approve
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 text-xs text-red-700 border-red-200 hover:bg-red-50"
                      onClick={() => reviewTransfer(trf, "rejected", "Rejected by reviewer")}>
                      <X className="h-3.5 w-3.5 mr-1" /> Reject
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Parcel card ──────────────────────────────────────────────────────────────
function ParcelCard({ p, isStaff, isCitizen, isApprover, isAdmin, isDeleted, isTransferred, transferInfo,
  onCert, onHistory, onEdit, onSetStatus, onDispute, onTransfer, onDelete, onRestore, onPermDelete, viewMode = "medium" }) {
  const [expanded, setExpanded] = useState(false);

  // Color grading
  const cardClass = isDeleted
    ? "rounded-2xl border-2 border-red-300 bg-red-50/80 shadow-sm"
    : isTransferred
    ? "rounded-2xl border-2 border-amber-300 bg-amber-50/70 shadow-sm"
    : "rounded-2xl border border-border bg-card shadow-sm hover:shadow-md transition-shadow";

  // Small view
  if (viewMode === "small") {
    return (
      <div className={cn(cardClass, "p-3")}>
        <div className="flex items-center justify-between gap-2 mb-1.5">
          <p className="font-mono text-[10px] text-muted-foreground truncate">{p.parcelNumber}</p>
          <div className="flex gap-1 shrink-0">
            {isDeleted && <span className="rounded-full bg-red-600 px-1.5 py-0.5 text-[9px] font-bold text-white uppercase tracking-wide">Deleted</span>}
            {isTransferred && <span className="rounded-full bg-amber-500 px-1.5 py-0.5 text-[9px] font-bold text-white uppercase tracking-wide">Transferred</span>}
            {!isDeleted && <StatusBadge status={p.status} />}
          </div>
        </div>
        <p className="text-xs font-semibold truncate">{p.applicantName || "—"}</p>
        <p className="text-[10px] text-muted-foreground mt-0.5">Plot {p.plotNumber || "—"} · Block {p.block || "—"}</p>
        <div className="flex gap-1 mt-2">
          <Button size="sm" variant="ghost" className="h-6 px-2 text-[10px]" onClick={() => onHistory(p)}><Clock className="h-3 w-3" /></Button>
          {isDeleted && isApprover && <Button size="sm" variant="ghost" className="h-6 px-2 text-[10px] text-emerald-600" onClick={() => onRestore(p)}><RotateCcw className="h-3 w-3" /></Button>}
          {isDeleted && isAdmin && <Button size="sm" variant="ghost" className="h-6 px-2 text-[10px] text-red-700" title="Permanently delete" onClick={() => onPermDelete(p)}><Trash2 className="h-3 w-3" /></Button>}
        </div>
      </div>
    );
  }

  // List view (table row style)
  if (viewMode === "list") {
    return (
      <div className={cn(cardClass, "flex items-center gap-3 px-4 py-3 rounded-xl")}>
        <div className="w-32 shrink-0">
          <p className="font-mono text-xs text-muted-foreground">{p.parcelNumber}</p>
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate">{p.applicantName || "—"}</p>
          <p className="text-xs text-muted-foreground truncate">{p.areaCouncil} · {p.community}</p>
        </div>
        <div className="hidden sm:block w-24 text-xs text-muted-foreground shrink-0">
          Plot {p.plotNumber || "—"} / {p.block || "—"}
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {isDeleted && <span className="rounded-full bg-red-600 px-2 py-0.5 text-[10px] font-bold text-white uppercase">Deleted</span>}
          {isTransferred && <span className="rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-bold text-white uppercase">Transferred</span>}
          {!isDeleted && <StatusBadge status={p.status} />}
        </div>
        <div className="flex gap-1 shrink-0">
          <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => onHistory(p)}><Clock className="h-3.5 w-3.5" /></Button>
          {isStaff && !isDeleted && <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => onEdit(p)}><Pencil className="h-3.5 w-3.5" /></Button>}
          {isStaff && !isDeleted && <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-600" onClick={() => onDelete(p)}><Trash2 className="h-3.5 w-3.5" /></Button>}
          {isDeleted && isApprover && <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-emerald-600" onClick={() => onRestore(p)}><RotateCcw className="h-3.5 w-3.5" /></Button>}
          {isDeleted && isAdmin && <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-700" title="Permanently delete" onClick={() => onPermDelete(p)}><Trash2 className="h-3.5 w-3.5" /></Button>}
        </div>
      </div>
    );
  }

  // Large view
  const isLarge = viewMode === "large";

  return (
    <div className={cn(cardClass)}>
      <div className="p-5">
        {/* Status strips */}
        {(isDeleted || isTransferred) && (
          <div className={cn("flex items-center gap-2 rounded-lg px-3 py-2 mb-3 text-xs font-semibold",
            isDeleted ? "bg-red-100 text-red-800 border border-red-200" : "bg-amber-100 text-amber-800 border border-amber-200")}>
            {isDeleted ? <><Trash2 className="h-3.5 w-3.5" /> DELETED RECORD — this land has been soft-deleted</> 
              : <><ArrowRightLeft className="h-3.5 w-3.5" /> TRANSFERRED — ownership changed on {transferInfo?.updated ? formatDate(transferInfo.updated) : "—"}</>}
          </div>
        )}

        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="font-mono text-xs text-muted-foreground">{p.parcelNumber}</p>
            <h3 className="mt-0.5 truncate font-display text-base font-semibold">{p.applicantName || "—"}</h3>
            {isTransferred && transferInfo && (
              <p className="text-[10px] text-amber-700 mt-0.5">Ref: {transferInfo.certificateNumber || "—"}</p>
            )}
          </div>
          <div className="flex flex-col items-end gap-1">
            {isDeleted && <span className="rounded-full bg-red-600 px-2 py-0.5 text-[10px] font-bold text-white uppercase tracking-wide">Deleted</span>}
            {isTransferred && <span className="rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-bold text-white uppercase tracking-wide">Transferred</span>}
            {!isDeleted && <StatusBadge status={p.status} />}
          </div>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-muted-foreground sm:grid-cols-3">
          {p.areaCouncil && <span><span className="font-medium text-foreground/70">Area Council:</span> {p.areaCouncil}</span>}
          {p.community && <span><span className="font-medium text-foreground/70">Community:</span> {p.community}</span>}
          {p.sector && <span><span className="font-medium text-foreground/70">Sector:</span> {p.sector}</span>}
          {p.plotNumber && <span><span className="font-medium text-foreground/70">Plot:</span> {p.plotNumber}</span>}
          {p.block && <span><span className="font-medium text-foreground/70">Block:</span> {p.block}</span>}
          {p.contactPhone && <span className="flex items-center gap-0.5"><MapPin className="h-3 w-3" /> {p.contactPhone}</span>}
        </div>

        {(expanded || isLarge) && (
          <div className="mt-3 space-y-1.5 border-t border-border pt-3 text-xs text-muted-foreground">
            {p.alternateMobile && <div><span className="font-medium text-foreground/70">Alt Mobile:</span> {p.alternateMobile}</div>}
            {p.whatsapp && <div><span className="font-medium text-foreground/70">WhatsApp:</span> {p.whatsapp}</div>}
            {p.applicantEmail && <div><span className="font-medium text-foreground/70">Email:</span> {p.applicantEmail}</div>}
            {p.religion && <div><span className="font-medium text-foreground/70">Religion:</span> {p.religion}</div>}
            {p.tribe && <div><span className="font-medium text-foreground/70">Tribe:</span> {p.tribe}</div>}
            {p.allocationDate && <div><span className="font-medium text-foreground/70">Allocation Date:</span> {formatDate(p.allocationDate)}</div>}
            {p.registrationDate && <div><span className="font-medium text-foreground/70">Registration Date:</span> {formatDate(p.registrationDate)}</div>}
            {isStaff && p.expand?.owner && <div className="border-t border-border pt-1.5 mt-1"><span className="font-medium text-foreground/70">Registered Owner:</span> {p.expand.owner.fullName || p.expand.owner.email}</div>}
            {isTransferred && transferInfo && (
              <div className="rounded-lg bg-amber-50 border border-amber-200 p-2.5 mt-2 space-y-1">
                <p className="font-semibold text-amber-800">Transfer Details</p>
                {transferInfo.toOwnerName && <p><span className="font-medium text-amber-700">New Owner:</span> {transferInfo.toOwnerName}</p>}
                {transferInfo.toOwnerPhone && <p><span className="font-medium text-amber-700">New Phone:</span> {transferInfo.toOwnerPhone}</p>}
                {transferInfo.certificateNumber && <p><span className="font-medium text-amber-700">Reference:</span> {transferInfo.certificateNumber}</p>}
              </div>
            )}
          </div>
        )}

        {!isLarge && (
          <div className="mt-3 flex items-center justify-between border-t border-border pt-3">
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" /> {formatDate(p.created)}
            </span>
            <button onClick={() => setExpanded((v) => !v)} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
              {expanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
              {expanded ? "Less" : "More"}
            </button>
          </div>
        )}

        {/* Actions — hidden for deleted unless restoring */}
        {isDeleted ? (
          isApprover && (
            <div className="mt-3 flex flex-wrap gap-2 border-t border-red-200 pt-3">
              <Button size="sm" variant="outline" className="text-emerald-700 border-emerald-200 hover:bg-emerald-50" onClick={() => onRestore(p)}>
                <RotateCcw className="mr-1 h-3.5 w-3.5" /> Restore Record
              </Button>
              <Button size="sm" variant="outline" onClick={() => onHistory(p)}>
                <Clock className="mr-1 h-3.5 w-3.5" /> History
              </Button>
              {isAdmin && (
                <Button size="sm" variant="outline" className="text-red-700 border-red-300 hover:bg-red-100 font-semibold" onClick={() => onPermDelete(p)}>
                  <Trash2 className="mr-1 h-3.5 w-3.5" /> Permanent Delete
                </Button>
              )}
            </div>
          )
        ) : (
          <div className="mt-3 flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => onHistory(p)}>
              <Clock className="mr-1 h-3.5 w-3.5" /> History
            </Button>
            {p.status === "registered" && (
              <Button size="sm" variant="outline" onClick={() => onCert(p)}>
                <Download className="mr-1 h-3.5 w-3.5" /> Certificate
              </Button>
            )}
            {isStaff && (
              <Button size="sm" variant="outline" onClick={() => onEdit(p)}>
                <Pencil className="mr-1 h-3.5 w-3.5" />
                {isApprover ? "Amend" : "Request Edit"}
              </Button>
            )}
            {(p.status === "registered") && isStaff && (
              <Button size="sm" variant="outline" onClick={() => onTransfer(p)}>
                <ArrowRightLeft className="mr-1 h-3.5 w-3.5" /> Transfer
              </Button>
            )}
            {isStaff && p.status !== "registered" && p.status !== "rejected" && (
              <Button size="sm" onClick={() => onSetStatus(p.id, "registered")}>
                <FileCheck className="mr-1 h-3.5 w-3.5" /> Register
              </Button>
            )}
            {isStaff && p.status !== "disputed" && p.status !== "rejected" && (
              <Button size="sm" variant="outline" className="text-orange-600 border-orange-200 hover:bg-orange-50" onClick={() => onDispute(p)}>
                <AlertTriangle className="mr-1 h-3.5 w-3.5" /> Dispute
              </Button>
            )}
            {isStaff && p.status === "disputed" && (
              <Button size="sm" variant="outline" onClick={() => onSetStatus(p.id, "under_review")}>
                <RefreshCw className="mr-1 h-3.5 w-3.5" /> Resolve
              </Button>
            )}
            {isStaff && (
              <Button size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50" onClick={() => onDelete(p)}>
                <Trash2 className="mr-1 h-3.5 w-3.5" /> {isApprover ? "Delete" : "Request Delete"}
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ── CSV Import ───────────────────────────────────────────────────────────────
function ImportModal({ userId, onDone, onClose }) {
  const { log } = useAuth();
  const { toast } = useToast();
  const fileRef = useRef(null);
  const [results, setResults] = useState(null);
  const [importing, setImporting] = useState(false);
  const [parsedRows, setParsedRows] = useState(null); // store parsed data in state

  const TEMPLATE_HEADERS = [
    "applicantName", "contactPhone", "alternateMobile", "whatsapp", "applicantEmail",
    "religion", "tribe", "areaCouncil", "community", "sector",
    "plotNumber", "block", "allocationDate", "registrationDate",
  ];

  const downloadTemplate = () => {
    const sample = [
      "Ama Serwaa", "0244123456", "0554987654", "0244123456", "ama@email.com",
      "Christian", "Akan", "Tuobodom", "Tanoso", "Sector 2",
      "12/A", "", "2024-01-15", "2024-03-20",
    ];
    const csv = [TEMPLATE_HEADERS.join(","), sample.join(",")].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "land-import-template.csv"; a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Template downloaded", description: "Tip: Plot column supports 123/A format — Block is auto-extracted." });
  };

  const parseCSV = (text) => {
    const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    if (lines.length < 2) return null;
    const headers = lines[0].split(",").map((h) => h.trim().replace(/^"|"$/g, ""));
    return lines.slice(1).map((line) => {
      const vals = line.split(",").map((v) => v.trim().replace(/^"|"$/g, ""));
      const obj = {};
      headers.forEach((h, i) => { obj[h] = vals[i] || ""; });
      return obj;
    }).filter((row) => Object.values(row).some((v) => v)); // skip blank rows
  };

  // Parse date: accepts YYYY-MM-DD, dd/mm/yyyy, mm/dd/yyyy, dd-mm-yyyy
  const parseSmartDate = (str) => {
    if (!str || !str.trim()) return null;
    const s = str.trim();
    // Already ISO
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
    const parts = s.split(/[\/\-\.]/);
    if (parts.length === 3) {
      const nums = parts.map(Number);
      // Detect year position
      const yearIdx = nums.findIndex((n) => n > 31);
      if (yearIdx === 2) {
        const [a, b, yr] = nums;
        if (a > 12) {
          // dd/mm/yyyy
          const d = new Date(yr, b - 1, a);
          if (!isNaN(d) && d.getDate() === a) return `${yr}-${String(b).padStart(2, "0")}-${String(a).padStart(2, "0")}`;
        } else if (b > 12) {
          // mm/dd/yyyy
          const d = new Date(yr, a - 1, b);
          if (!isNaN(d) && d.getDate() === b) return `${yr}-${String(a).padStart(2, "0")}-${String(b).padStart(2, "0")}`;
        } else {
          // Ambiguous — assume dd/mm/yyyy (Ghana standard)
          const d = new Date(yr, b - 1, a);
          if (!isNaN(d) && b >= 1 && b <= 12 && a >= 1 && a <= 31) return `${yr}-${String(b).padStart(2, "0")}-${String(a).padStart(2, "0")}`;
        }
      } else if (yearIdx === 0) {
        const [yr, a, b] = nums;
        const d = new Date(yr, a - 1, b);
        if (!isNaN(d)) return `${yr}-${String(a).padStart(2, "0")}-${String(b).padStart(2, "0")}`;
      }
    }
    return null; // invalid
  };

  // Parse phone field: "0244123456/0244654321" → mobile + alternate
  const parsePhoneField = (str) => {
    if (!str || !str.trim()) return { mobile: "", alternate: "" };
    const cleaned = str.trim().replace(/[^\d+\/\s-]/g, "");
    const parts = cleaned.split("/");
    return {
      mobile: parts[0].trim(),
      alternate: parts[1] ? parts[1].trim() : "",
    };
  };

  // Parse plot/block from slash notation
  const parsePlotBlock = (row) => {
    let plotNumber = row.plotNumber || "";
    let block = row.block || "";
    if (plotNumber.includes("/")) {
      const parts = plotNumber.split("/");
      plotNumber = parts[0].trim();
      if (!block) block = parts.slice(1).join("/").trim();
    }
    // Parse phone fields
    const phoneData = parsePhoneField(row.contactPhone || "");
    const contactPhone = phoneData.mobile || row.contactPhone || "";
    const alternateMobile = row.alternateMobile || phoneData.alternate || "";
    // Parse dates
    const allocationDate = parseSmartDate(row.allocationDate);
    const registrationDate = parseSmartDate(row.registrationDate);
    return { ...row, plotNumber, block, contactPhone, alternateMobile, allocationDate, registrationDate };
  };

  const handleFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const rows = parseCSV(ev.target.result);
      if (!rows || rows.length === 0) {
        toast({ variant: "destructive", title: "Invalid or empty CSV" });
        setParsedRows(null);
        return;
      }
      setParsedRows(rows);
      setResults(null);
      toast({ title: `${rows.length} rows ready to import`, description: "Click Import to proceed." });
    };
    reader.readAsText(file);
    // Do NOT clear the input here so user can see filename
  };

  const [importProgress, setImportProgress] = useState(null);

  const doImport = async () => {
    if (!parsedRows || parsedRows.length === 0) {
      toast({ variant: "destructive", title: "No data to import", description: "Please select a valid CSV file first." });
      return;
    }

    setImporting(true);
    const startTime = Date.now();
    let created = 0, failed = 0;
    const errors = [];
    const total = parsedRows.length;

    setImportProgress({ done: 0, total, created: 0, failed: 0, pct: 0, speed: 0, eta: "—", currentRow: "" });

    for (let i = 0; i < total; i++) {
      const raw = parsedRows[i];
      const row = parsePlotBlock(raw);

      if (!row.applicantName) {
        failed++;
        errors.push(`Row ${i + 2}: Missing applicantName`);
        setImportProgress({ done: i + 1, total, created, failed, pct: Math.round(((i + 1) / total) * 100), speed: Math.round((i + 1) / ((Date.now() - startTime) / 1000)), eta: `${Math.round(((total - i - 1) / Math.max(1, (i + 1) / ((Date.now() - startTime) / 1000))))}s`, currentRow: `Row ${i + 2}: skipped (no name)` });
        continue;
      }

      try {
        const rec = await pb.collection("parcels").create({
          owner: userId,
          parcelNumber: genLandId(),
          applicantName: row.applicantName,
          contactPhone: row.contactPhone || "",
          alternateMobile: row.alternateMobile || "",
          whatsapp: row.whatsapp || "",
          applicantEmail: row.applicantEmail || "",
          religion: row.religion || "",
          tribe: row.tribe || "",
          areaCouncil: row.areaCouncil || "",
          community: row.community || "",
          sector: row.sector || "",
          plotNumber: row.plotNumber || "",
          block: row.block || "",
          allocationDate: row.allocationDate || null,
          registrationDate: row.registrationDate || null,
          status: "registered", // Auto-register on bulk upload
        }, { requestKey: `import-${i}-${Date.now()}` });
        created++;
        const elapsed = (Date.now() - startTime) / 1000;
        const speed = Math.round((i + 1) / Math.max(0.1, elapsed));
        const remaining = total - i - 1;
        setImportProgress({ done: i + 1, total, created, failed, pct: Math.round(((i + 1) / total) * 100), speed, eta: speed > 0 ? `${Math.round(remaining / speed)}s` : "—", currentRow: `✓ ${row.applicantName} — ${rec.parcelNumber}` });
      } catch (err) {
        failed++;
        errors.push(`Row ${i + 2}: ${err?.message || "Error"}`);
        const elapsed = (Date.now() - startTime) / 1000;
        const speed = Math.round((i + 1) / Math.max(0.1, elapsed));
        setImportProgress({ done: i + 1, total, created, failed, pct: Math.round(((i + 1) / total) * 100), speed, eta: speed > 0 ? `${Math.round((total - i - 1) / speed)}s` : "—", currentRow: `✗ Row ${i + 2}: ${err?.message || "Error"}` });
      }
    }

    await log("bulk_import", "parcels", `Auto-registered ${created} parcels, ${failed} failed`);
    setResults({ created, failed, errors, total });
    setImportProgress(null);
    setImporting(false);
    if (created > 0) onDone();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between rounded-xl border border-border bg-muted/30 p-4">
        <div className="flex items-center gap-3">
          <FileSpreadsheet className="h-8 w-8 text-primary/60" />
          <div>
            <p className="text-sm font-medium">CSV Import Template</p>
            <p className="text-xs text-muted-foreground">Plot format: "123/A" auto-splits into Plot=123, Block=A</p>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={downloadTemplate}>
          <Download className="mr-1 h-4 w-4" /> Template
        </Button>
      </div>

      <div className="rounded-xl border border-dashed border-border bg-muted/20 p-6 text-center">
        <Upload className="mx-auto h-8 w-8 text-muted-foreground" />
        <p className="mt-2 text-sm font-medium">Upload CSV file</p>
        <p className="mt-1 text-xs text-muted-foreground">Only applicantName is required; all other fields are optional</p>
        <Button variant="outline" size="sm" className="mt-3" onClick={() => fileRef.current?.click()}>
          Choose file
        </Button>
        <input ref={fileRef} type="file" accept=".csv,.txt" className="hidden" onChange={handleFile} />
      </div>

      {importProgress && (
        <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-primary">Auto-Registering Records…</p>
            <span className="text-xs font-mono font-bold text-primary">{importProgress.pct}%</span>
          </div>
          <div className="h-2.5 w-full rounded-full bg-border overflow-hidden">
            <div className="h-full bg-primary rounded-full transition-all duration-150" style={{ width: `${importProgress.pct}%` }} />
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
            <span>Processed: <strong className="text-foreground">{importProgress.done}/{importProgress.total}</strong></span>
            <span>Success: <strong className="text-emerald-600">{importProgress.created}</strong> | Failed: <strong className="text-red-600">{importProgress.failed}</strong></span>
            <span>Speed: <strong className="text-foreground">{importProgress.speed} rec/s</strong></span>
            <span>ETA: <strong className="text-foreground">{importProgress.eta}</strong></span>
          </div>
          {importProgress.currentRow && <p className="text-xs text-muted-foreground truncate">{importProgress.currentRow}</p>}
        </div>
      )}

      {parsedRows && !results && !importProgress && (
        <div className="rounded-xl border border-border bg-card p-3 text-xs text-muted-foreground space-y-1">
          <p className="font-semibold text-foreground">{parsedRows.length} rows parsed — ready to import</p>
          {parsedRows.slice(0, 3).map((row, i) => {
            const processed = parsePlotBlock(row);
            return (
              <p key={i} className="truncate">
                {i + 1}. {processed.applicantName || "(no name)"} — Plot: {processed.plotNumber || "—"} Block: {processed.block || "—"} · {processed.areaCouncil || "—"}
              </p>
            );
          })}
          {parsedRows.length > 3 && <p>… and {parsedRows.length - 3} more rows</p>}
        </div>
      )}

      {results && (
        <div className={cn("rounded-xl p-4 text-sm space-y-2", results.failed === 0 ? "bg-emerald-50 border border-emerald-200" : "bg-amber-50 border border-amber-200")}>
          <div className="flex items-center gap-2 font-semibold">
            {results.failed === 0 ? <CheckCircle2 className="h-4 w-4 text-emerald-600" /> : <AlertTriangle className="h-4 w-4 text-amber-600" />}
            Auto-registration complete — {results.created}/{results.total} registered
          </div>
          <div className="grid grid-cols-2 gap-1 text-xs">
            <span className="text-emerald-700">✓ Registered: <strong>{results.created}</strong></span>
            <span className="text-red-700">✗ Failed: <strong>{results.failed}</strong></span>
          </div>
          {results.errors.length > 0 && (
            <div className="max-h-24 overflow-y-auto space-y-0.5">
              {results.errors.map((e, i) => <p key={i} className="text-xs text-muted-foreground">{e}</p>)}
            </div>
          )}
          {results.created > 0 && (
            <Button size="sm" variant="outline" onClick={() => {
              const lines = ["Row,Status,Details", ...results.errors.map((e) => `FAILED,"${e}"`)];
              const blob = new Blob([lines.join("\n")], { type: "text/csv" });
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a"); a.href = url; a.download = "import-report.csv"; a.click();
            }} className="text-xs h-7">
              <Download className="mr-1 h-3 w-3" /> Download Report
            </Button>
          )}
        </div>
      )}

      <div className="flex gap-2">
        {!results && (
          <Button onClick={doImport} disabled={importing || !parsedRows} className="flex-1">
            {importing ? "Auto-Registering…" : parsedRows ? `Auto-Register ${parsedRows.length} Records` : "Select a file first"}
          </Button>
        )}
        <Button variant={results ? "default" : "outline"} onClick={onClose} className={results ? "flex-1" : ""}>
          {results ? "Done" : "Cancel"}
        </Button>
      </div>
    </div>
  );
}

// ── Parcel form ──────────────────────────────────────────────────────────────
function ParcelForm({ form, setForm, onSubmit, onCancel, saving, submitLabel, userAreaCouncils }) {
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e?.target ? e.target.value : e }));
  const { offices, acForOffice, commForAC, sectForComm, loading: hierLoading } = useHierarchy();

  // Cascading select handlers
  const setOfficeVal = (v) => setForm((f) => ({ ...f, office: v === "none" ? "" : v, areaCouncil: "", community: "", sector: "" }));
  const setACVal = (v) => setForm((f) => ({ ...f, areaCouncil: v === "none" ? "" : v, community: "", sector: "" }));
  const setCommVal = (v) => setForm((f) => ({ ...f, community: v === "none" ? "" : v, sector: "" }));
  const setSectVal = (v) => setForm((f) => ({ ...f, sector: v === "none" ? "" : v }));

  const safeList = (fn, arg, fallback) => {
    try {
      const out = fn(arg);
      return Array.isArray(out) ? out.filter((x) => x && x.name) : (fallback || []);
    } catch (err) {
      console.error("Hierarchy dropdown error", err);
      return fallback || [];
    }
  };

  const acOptions = (offices.length || form.office)
    ? safeList(acForOffice, form.office, [])
    : (userAreaCouncils || ALL_AREA_COUNCILS).filter(Boolean).map((n) => ({ id: n, name: n }));
  const commOptions = safeList(commForAC, form.areaCouncil, []);
  const sectOptions = safeList(sectForComm, form.community, []);

  // Breadcrumb path
  const hierPath = [form.office, form.areaCouncil, form.community, form.sector].filter(Boolean).join(" > ");

  return (
    <div className="space-y-5 py-1">
      <FGroup label="Personal Information" />
      <FRow>
        <FF label="Name" required><Input value={form.applicantName} onChange={set("applicantName")} placeholder="Full legal name" /></FF>
        <FF label="Mobile" required><Input value={form.contactPhone} onChange={set("contactPhone")} placeholder="+233 XX XXX XXXX" /></FF>
      </FRow>
      <FRow>
        <FF label="Alternate Mobile (Optional)"><Input value={form.alternateMobile} onChange={set("alternateMobile")} placeholder="+233 XX XXX XXXX" /></FF>
        <FF label="WhatsApp (Optional)"><Input value={form.whatsapp} onChange={set("whatsapp")} placeholder="+233 XX XXX XXXX" /></FF>
      </FRow>
      <FF label="Email" required><Input type="email" value={form.applicantEmail} onChange={set("applicantEmail")} placeholder="applicant@email.com" /></FF>
      <FRow>
        <FF label="Religion" required>
          <Select value={form.religion || "none"} onValueChange={(v) => setForm((f) => ({ ...f, religion: v === "none" ? "" : v }))}>
            <SelectTrigger><SelectValue placeholder="Select religion" /></SelectTrigger>
            <SelectContent><SelectItem value="none">— Select —</SelectItem>{RELIGIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
          </Select>
        </FF>
        <FF label="Tribe" required>
          <Select value={form.tribe || "none"} onValueChange={(v) => setForm((f) => ({ ...f, tribe: v === "none" ? "" : v }))}>
            <SelectTrigger><SelectValue placeholder="Select tribe" /></SelectTrigger>
            <SelectContent><SelectItem value="none">— Select —</SelectItem>{TRIBES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
          </Select>
        </FF>
      </FRow>

      <FGroup label="Location Details" />
      {hierPath && (
        <p className="text-xs text-primary bg-primary/5 rounded-lg px-3 py-1.5 font-medium">{hierPath}</p>
      )}
      <FRow>
        <FF label="Office" required>
          <Select value={form.office || "none"} onValueChange={setOfficeVal}>
            <SelectTrigger><SelectValue placeholder="Select office" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">— Select Office —</SelectItem>
              {offices.filter((o) => o && o.name).map((o) => <SelectItem key={o.id} value={o.name}>{o.name}{o.code ? ` (${o.code})` : ""}</SelectItem>)}
              {offices.length === 0 && !hierLoading && <SelectItem value="_none" disabled>No offices configured</SelectItem>}
            </SelectContent>
          </Select>
        </FF>
        <FF label="Area Council" required>
          <Select value={form.areaCouncil || "none"} onValueChange={setACVal} disabled={!form.office && offices.length > 0}>
            <SelectTrigger><SelectValue placeholder={form.office ? "Select area council" : "Select office first"} /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">— Select Area Council —</SelectItem>
              {acOptions.filter((ac) => ac && (ac.name || typeof ac === "string")).map((ac) => <SelectItem key={ac.id || ac} value={ac.name || ac}>{ac.name || ac}</SelectItem>)}
              {acOptions.length === 0 && <SelectItem value="_empty_ac" disabled>No area councils available</SelectItem>}
            </SelectContent>
          </Select>
        </FF>
      </FRow>
      <FRow>
        <FF label="Community" required>
          <Select value={form.community || "none"} onValueChange={setCommVal} disabled={!form.areaCouncil}>
            <SelectTrigger><SelectValue placeholder={form.areaCouncil ? "Select community" : "Select area council first"} /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">— Select Community —</SelectItem>
              {commOptions.map((c) => <SelectItem key={c.id} value={c.name}>{c.name}{c.code ? ` (${c.code})` : ""}</SelectItem>)}
              {/* guarded above via safeList */}
              {commOptions.length === 0 && <SelectItem value="_empty" disabled>No communities for this area council</SelectItem>}
            </SelectContent>
          </Select>
        </FF>
        <FF label="Sector" required>
          <Select value={form.sector || "none"} onValueChange={setSectVal} disabled={!form.community}>
            <SelectTrigger><SelectValue placeholder={form.community ? "Select sector" : "Select community first"} /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">— Select Sector —</SelectItem>
              {sectOptions.map((s) => <SelectItem key={s.id} value={s.name}>{s.name}{s.code ? ` (${s.code})` : ""}</SelectItem>)}
              {/* guarded above via safeList */}
              {sectOptions.length === 0 && <SelectItem value="_empty" disabled>No sectors for this community</SelectItem>}
            </SelectContent>
          </Select>
        </FF>
      </FRow>
      <FRow>
        <FF label="Plot Number" required><Input value={form.plotNumber} onChange={set("plotNumber")} placeholder="e.g. Plot 12" /></FF>
        <FF label="Block" required><Input value={form.block} onChange={set("block")} placeholder="e.g. Block A" /></FF>
      </FRow>

      <FGroup label="Registration Dates" />
      <FRow>
        <FF label="Allocation Date" required><Input type="date" value={form.allocationDate} onChange={set("allocationDate")} /></FF>
        <FF label="Registration Date" required><Input type="date" value={form.registrationDate} onChange={set("registrationDate")} /></FF>
      </FRow>

      <FGroup label="Payment Information (Optional)" />
      <div className="rounded-xl border border-border bg-muted/20 p-4 space-y-3">
        <p className="text-xs text-muted-foreground">Attach a payment record to this land registration. Leave blank to skip.</p>
        <FRow>
          <FF label="Payment Amount (GHS)">
            <Input type="number" min="0" step="0.01" value={form.paymentAmount} onChange={set("paymentAmount")} placeholder="e.g. 250.00" />
          </FF>
          <FF label="Payment Method">
            <Select value={form.paymentMethod || "none"} onValueChange={(v) => setForm((f) => ({ ...f, paymentMethod: v === "none" ? "" : v }))}>
              <SelectTrigger><SelectValue placeholder="Select method" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">— Select —</SelectItem>
                <SelectItem value="cash">Cash</SelectItem>
                <SelectItem value="mobile_money">Mobile Money</SelectItem>
                <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                <SelectItem value="card">Card</SelectItem>
              </SelectContent>
            </Select>
          </FF>
        </FRow>
        <FRow>
          <FF label="Payment Status">
            <Select value={form.paymentStatus || "pending"} onValueChange={(v) => setForm((f) => ({ ...f, paymentStatus: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
          </FF>
          <FF label="Payment Date">
            <Input type="date" value={form.paymentDate} onChange={set("paymentDate")} />
          </FF>
        </FRow>
        <FRow>
          <FF label="Reference Number">
            <Input value={form.paymentReference} onChange={set("paymentReference")} placeholder="e.g. REF-2024-001" />
          </FF>
          <FF label="Payment Notes">
            <Input value={form.paymentNotes} onChange={set("paymentNotes")} placeholder="Optional notes" />
          </FF>
        </FRow>
      </div>

      <div className="flex gap-2 pt-1">
        <Button variant="outline" onClick={onCancel} className="flex-1">Cancel</Button>
        <Button onClick={onSubmit} disabled={saving} className="flex-1">{saving ? "Saving…" : submitLabel || "Register"}</Button>
      </div>
    </div>
  );
}

// ── Main page ────────────────────────────────────────────────────────────────
export default function ParcelsPage() {
  const { user, role, log } = useAuth();
  const { toast } = useToast();
  const isCitizen = false;
  const isStaff = true;
  const isAdmin = role === "admin";
  const isApprover = role === "admin" || role === "planning_officer";
  const canBulkRegister = role === "admin" || role === "registrar";

  const userACs = useMemo(() => getUserAreaCouncils(user), [user]);

  const { records, loading, reload } = useCollection("parcels", {
    filter: isCitizen ? `owner = "${user.id}"` : "",
    expand: "owner",
  });

  const accessibleRecords = useMemo(() => {
    if (!userACs) return records;
    if (isCitizen) return records;
    return records.filter((p) => userACs.includes(p.areaCouncil));
  }, [records, userACs, isCitizen]);

  const [selectedIds, setSelectedIds] = useState([]);
  const [bulkStatus, setBulkStatus] = useState("registered");
  const [bulkAmendOpen, setBulkAmendOpen] = useState(false);
  const [bulkAmendReason, setBulkAmendReason] = useState("");
  const [bulkProgress, setBulkProgress] = useState(null);
  const [permDeleteDialog, setPermDeleteDialog] = useState(null);
  const [permDeleteReason, setPermDeleteReason] = useState("");
  const [permDeleting, setPermDeleting] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterAC, setFilterAC] = useState("all");
  const [filterCommunity, setFilterCommunity] = useState("all");
  const [filterSector, setFilterSector] = useState("all");
  const [filterYear, setFilterYear] = useState("all");
  const [showMoreFilters, setShowMoreFilters] = useState(false);
  const [searchQ, setSearchQ] = useState("");
  const [certParcel, setCertParcel] = useState(null);
  const [historyParcel, setHistoryParcel] = useState(null);
  const [editParcel, setEditParcel] = useState(null);
  const [editRequestParcel, setEditRequestParcel] = useState(null);
  const [transferParcel, setTransferParcel] = useState(null);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [viewMode, setViewModeRaw] = useState(() => getViewMode());
  const [deletionFilter, setDeletionFilter] = useState("active"); // active | deleted | all
  const [softDeletedIds, setSoftDeletedIds] = useState(new Set());
  const [transferMap, setTransferMap] = useState({});
  const [deleteDialog, setDeleteDialog] = useState(null);
  const [deleteReason, setDeleteReason] = useState("");

  const switchViewMode = (v) => { setViewModeRaw(v); setViewMode(v); };

  // Load soft-deleted audit log entries and approved transfers
  useEffect(() => {
    let cancelled = false;
    const loadMeta = async () => {
      try {
        const [auditLogs, transfers] = await Promise.all([
          pb.collection("audit_logs").getFullList({
            filter: `action = "parcel_soft_deleted" || action = "parcel_restored"`,
            sort: "created",
            requestKey: "softdel-audit",
          }).catch(() => []),
          pb.collection("land_transfers").getFullList({
            filter: `status = "approved"`,
            sort: "-created",
            requestKey: "transfer-approved-map",
          }).catch(() => []),
        ]);
        if (cancelled) return;
        const stateMap = {};
        for (const entry of auditLogs) { stateMap[entry.entity] = entry.action === "parcel_soft_deleted"; }
        setSoftDeletedIds(new Set(Object.entries(stateMap).filter(([, v]) => v).map(([k]) => k)));
        const tmap = {};
        for (const t of transfers) { if (!tmap[t.parcel]) tmap[t.parcel] = t; }
        setTransferMap(tmap);
      } catch (_) {}
    };
    loadMeta();
    return () => { cancelled = true; };
  }, [records]);

  const defaultAC = userACs?.length === 1 ? userACs[0] : "";

  const filtered = accessibleRecords.filter((p) => {
    const isDel = softDeletedIds.has(p.id);
    if (deletionFilter === "active" && isDel) return false;
    if (deletionFilter === "deleted" && !isDel) return false;
    const matchStatus = filterStatus === "all" || p.status === filterStatus;
    const matchAC = filterAC === "all" || p.areaCouncil === filterAC;
    const matchCommunity = filterCommunity === "all" || p.community === filterCommunity;
    const matchSector = filterSector === "all" || p.sector === filterSector;
    const matchYear = filterYear === "all" || (p.registrationDate && p.registrationDate.startsWith(filterYear)) || (p.created && p.created.startsWith(filterYear));
    const q = searchQ.toLowerCase();
    const matchQ = !q || [p.parcelNumber, p.applicantName, p.areaCouncil, p.community, p.sector, p.plotNumber, p.block, p.contactPhone]
      .filter(Boolean).some((v) => v.toLowerCase().includes(q));
    return matchStatus && matchQ && matchAC && matchCommunity && matchSector && matchYear;
  });

  // Pagination — reset to page 1 whenever filters change
  const { page: parcelPage, setPage: setParcelPage, pageSize: parcelPageSize, setPageSize: setParcelPageSize, totalPages: parcelTotalPages, totalRecords: parcelTotalRecords, pageItems: parcelPageItems } = usePagination(filtered, "tnda-parcels-page-size", 50);
  const prevFilterRef = useRef("");
  const curFilterKey = `${filterStatus}|${filterAC}|${filterCommunity}|${filterSector}|${filterYear}|${searchQ}|${deletionFilter}`;
  useEffect(() => { if (prevFilterRef.current !== curFilterKey) { setParcelPage(1); prevFilterRef.current = curFilterKey; } }, [curFilterKey]); // eslint-disable-line

  const uniqueACs = ["all", ...Array.from(new Set(accessibleRecords.map((p) => p.areaCouncil).filter(Boolean))).sort()];
  const uniqueCommunities = ["all", ...Array.from(new Set(accessibleRecords.map((p) => p.community).filter(Boolean))).sort()];
  const uniqueSectors = ["all", ...Array.from(new Set(accessibleRecords.map((p) => p.sector).filter(Boolean))).sort()];
  const uniqueYears = ["all", ...Array.from(new Set(accessibleRecords.map((p) => (p.registrationDate || p.created || "").substring(0, 4)).filter((y) => y && y.length === 4))).sort().reverse()];
  const activeFilterCount = [filterStatus !== "all", filterAC !== "all", filterCommunity !== "all", filterSector !== "all", filterYear !== "all", searchQ !== ""].filter(Boolean).length;

  const validateForm = (f) => {
    const required = ["applicantName", "contactPhone", "applicantEmail", "religion", "tribe", "office", "areaCouncil", "community", "sector", "plotNumber", "block", "allocationDate", "registrationDate"];
    for (const k of required) {
      if (!f[k]) {
        toast({ variant: "destructive", title: "Required field missing", description: `Please fill in ${titleCase(k)}` });
        return false;
      }
    }
    return true;
  };

  const submit = async () => {
    if (!validateForm(form)) return;

    // Extra field-level validation with specific messages
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRe.test(form.applicantEmail)) {
      toast({ variant: "destructive", title: "Invalid email", description: "Enter a valid email address, e.g. name@example.com" });
      return;
    }
    const phoneRe = /^\+?[\d\s-]{9,15}$/;
    if (!phoneRe.test(form.contactPhone)) {
      toast({ variant: "destructive", title: "Invalid mobile number", description: "Enter a valid phone number (9–15 digits), e.g. +233 24 123 4567" });
      return;
    }
    if (form.allocationDate && form.registrationDate && new Date(form.allocationDate) > new Date(form.registrationDate)) {
      toast({ variant: "destructive", title: "Invalid dates", description: "Allocation date must be on or before the registration date." });
      return;
    }

    setSaving(true);
    await log("parcel_registration_attempt", "parcels", `Attempt by ${user.email} — ${form.applicantName}, Plot ${form.plotNumber}/${form.block}, ${form.areaCouncil}`);
    try {
      // Duplicate check: same plot + block + area council
      const dupFilter = pb.filter(
        "plotNumber = {:p} && block = {:b} && areaCouncil = {:a}",
        { p: form.plotNumber, b: form.block, a: form.areaCouncil }
      );
      const dups = await pb.collection("parcels").getList(1, 1, { filter: dupFilter, requestKey: `dupchk-${Date.now()}` });
      if (dups.totalItems > 0) {
        await log("parcel_registration_failed", "parcels", `Duplicate Plot ${form.plotNumber}/${form.block} in ${form.areaCouncil}`);
        toast({ variant: "destructive", title: "Duplicate registration", description: `A parcel with Plot ${form.plotNumber}, Block ${form.block} in ${form.areaCouncil} already exists.` });
        setSaving(false);
        return;
      }

      const { paymentAmount, paymentMethod, paymentStatus, paymentDate, paymentReference, paymentNotes, ...parcelFields } = form;
      const rec = await pb.collection("parcels").create({
        owner: user.id,
        parcelNumber: genLandId(),
        office: parcelFields.office || "",
        ...parcelFields,
        allocationDate: parcelFields.allocationDate || null,
        registrationDate: parcelFields.registrationDate || null,
        status: "submitted",
      });
      await log("parcel_registered", "parcels", `${rec.parcelNumber} — ${rec.applicantName}`);
      // Create linked payment record if payment amount provided
      if (paymentAmount && parseFloat(paymentAmount) > 0) {
        try {
          await pb.collection("payments").create({
            payer: user.id,
            parcel: rec.id,
            invoiceNumber: `INV-${rec.parcelNumber}`,
            purpose: "registration_fee",
            amount: parseFloat(paymentAmount),
            method: paymentMethod || "cash",
            status: paymentStatus || "pending",
            parcelNumber: rec.parcelNumber,
            plotNumber: form.plotNumber,
            block: form.block,
            areaCouncil: form.areaCouncil,
            community: form.community,
            sector: form.sector,
            ownerName: form.applicantName,
            ownerPhone: form.contactPhone,
            ownerEmail: form.applicantEmail,
          }, { requestKey: `pay-${rec.id}` });
          await log("payment_created", "payments", `Payment GHS ${paymentAmount} for ${rec.parcelNumber}`);
        } catch (_) {}
      }
      toast({ title: "Parcel registered", description: `${rec.parcelNumber} submitted for review.${paymentAmount && parseFloat(paymentAmount) > 0 ? " Payment record created." : ""}` });

      const ref = rec.parcelNumber;
      // Send confirmation SMS to owner
      const phone = form.contactPhone || form.alternateMobile || form.whatsapp;
      if (phone) {
        const smsMsg = `Dear ${form.applicantName}, your land registration (ID: ${rec.parcelNumber}) for Plot ${form.plotNumber || 'N/A'}/Block ${form.block || 'N/A'} in ${form.areaCouncil || 'N/A'}, ${form.community || 'N/A'} has been successfully submitted. Ref: ${ref}. Status: Pending review. - TeNDA PPD`;
        await sendSms(phone, smsMsg);
      }

      // Notify approving officers (Physical Planning Officer + Admin) via SMS + in-app
      try {
        const approvers = await pb.collection("users").getFullList({
          filter: "role = 'planning_officer' || role = 'admin'",
          requestKey: `approvers-${Date.now()}`,
        });
        const officerMsg = `Pending Approval: Land registration by ${form.applicantName} for Plot ${form.plotNumber || 'N/A'}/Block ${form.block || 'N/A'} in ${form.areaCouncil || 'N/A'}. Ref: ${ref}. Please review and approve/decline. - TeNDA PPD`;
        for (const off of approvers) {
          await notify(off.id, `New land registration ${rec.parcelNumber} by ${form.applicantName} pending approval.`, "/app/parcels");
          const offPhone = off.phone || off.whatsappNumber;
          if (offPhone) await sendSms(offPhone, officerMsg);
        }
      } catch (_) {}

      setRegisterOpen(false);
      setForm({ ...EMPTY_FORM });
      reload();
    } catch (err) {
      const data = err?.response?.data || err?.data;
      let desc = err?.message || "Please try again.";
      if (data && typeof data === "object" && Object.keys(data).length) {
        desc = Object.entries(data).map(([f, e]) => `${titleCase(f)}: ${e?.message || e}`).join(" · ");
      }
      await log("parcel_registration_failed", "parcels", `${form.applicantName}: ${desc}`);
      toast({ variant: "destructive", title: "Could not register", description: desc });
    } finally {
      setSaving(false);
    }
  };

  // Bulk operations (admin only)
  const toggleSelect = (id) => setSelectedIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
  const selectAll = () => setSelectedIds(filtered.map((p) => p.id));
  const clearSelection = () => setSelectedIds([]);

  const runBulk = async (op, label, fn) => {
    setBulkProgress({ done: 0, total: selectedIds.length, op: label });
    let done = 0, failed = 0;
    for (let i = 0; i < selectedIds.length; i++) {
      try { await fn(selectedIds[i]); done++; } catch (_) { failed++; }
      setBulkProgress({ done: i + 1, total: selectedIds.length, op: label });
    }
    await log(`bulk_${op}`, "parcels", `${label}: ${done}/${selectedIds.length} succeeded`);
    toast({ title: `Bulk ${label} complete`, description: `${done} succeeded${failed ? `, ${failed} failed` : ""}.` });
    setBulkProgress(null); clearSelection(); reload();
  };

  const bulkRegister = async () => {
    if (!window.confirm(`Register ${selectedIds.length} selected parcels?`)) return;
    await runBulk("register", "Register", (id) => pb.collection("parcels").update(id, { status: "registered" }, { requestKey: `breg-${id}` }));
  };

  const bulkDispute = async () => {
    if (!window.confirm(`Mark ${selectedIds.length} selected parcels as disputed?`)) return;
    await runBulk("dispute", "Dispute", (id) => pb.collection("parcels").update(id, { status: "disputed" }, { requestKey: `bdisp-${id}` }));
  };

  const submitBulkAmend = async () => {
    if (!bulkAmendReason.trim()) { toast({ variant: "destructive", title: "Please enter a reason" }); return; }
    setBulkAmendOpen(false);
    await runBulk("amend", "Amend", (id) =>
      pb.collection("land_edit_requests").create({
        parcel: id, requestedBy: user.id, type: "edit",
        proposedChanges: {}, reason: bulkAmendReason, status: "pending",
      }, { requestKey: `bamend-${id}` })
    );
    setBulkAmendReason("");
  };

  const bulkUpdateStatus = async () => {
    if (!window.confirm(`Update ${selectedIds.length} parcels to "${bulkStatus}"?`)) return;
    await runBulk("status", `Set ${bulkStatus}`, (id) => pb.collection("parcels").update(id, { status: bulkStatus }, { requestKey: `bst-${id}` }));
  };

  const bulkDelete = async () => {
    const reason = window.prompt(`Soft-delete ${selectedIds.length} selected parcels?\nEnter reason (required):`, "Bulk soft-deletion by admin");
    if (reason === null) return;
    await runBulk("soft_delete", "Soft Delete", async (id) => {
      await pb.collection("audit_logs").create({
        actor: user.id, action: "parcel_soft_deleted", entity: id,
        details: JSON.stringify({ reason: reason || "Bulk deletion", deletedBy: user.email, timestamp: new Date().toISOString() }),
      }, { requestKey: `bsdel-${id}` });
    });
    setSoftDeletedIds((prev) => new Set([...prev, ...selectedIds]));
  };

  const saveEdit = async () => {
    if (!editParcel) return;
    setSaving(true);
    try {
      await pb.collection("parcels").update(editParcel.id, {
        applicantName: editParcel.applicantName,
        contactPhone: editParcel.contactPhone,
        alternateMobile: editParcel.alternateMobile,
        whatsapp: editParcel.whatsapp,
        applicantEmail: editParcel.applicantEmail,
        religion: editParcel.religion,
        tribe: editParcel.tribe,
        office: editParcel.office || "",
        areaCouncil: editParcel.areaCouncil,
        community: editParcel.community,
        sector: editParcel.sector,
        plotNumber: editParcel.plotNumber,
        block: editParcel.block,
        allocationDate: editParcel.allocationDate || null,
        registrationDate: editParcel.registrationDate || null,
      });
      await log("parcel_amended", "parcels", `${editParcel.parcelNumber} amended`);
      toast({ title: "Parcel updated" });
      setEditParcel(null);
      reload();
    } catch (err) {
      toast({ variant: "destructive", title: "Update failed", description: err?.message });
    } finally {
      setSaving(false);
    }
  };

  const setStatus = async (id, status) => {
    await pb.collection("parcels").update(id, { status });
    await log("parcel_status_update", "parcels", `Set ${status} on ${id}`);
    reload();
  };

  const flagDispute = async (parcel) => {
    await pb.collection("parcels").update(parcel.id, { status: "disputed" });
    await log("parcel_disputed", "parcels", `Dispute flagged for ${parcel.parcelNumber}`);
    toast({ title: "Dispute flagged" });
    reload();
  };

  const handleEdit = (p) => {
    // Admin and planning_officer can edit directly; others request approval
    if (isApprover) {
      setEditParcel({ ...p });
    } else {
      setEditRequestParcel(p);
    }
  };

  const handleDelete = (p) => {
    if (isApprover) {
      // Open soft-delete dialog
      setDeleteDialog(p);
      setDeleteReason("");
    } else {
      // Create delete request
      pb.collection("land_edit_requests").create({
        parcel: p.id, requestedBy: user.id, type: "delete",
        proposedChanges: {}, reason: "User requested deletion", status: "pending",
      }).then(() => toast({ title: "Delete request submitted", description: "Awaiting approval." }))
        .catch((err) => toast({ variant: "destructive", title: "Failed", description: err?.message }));
    }
  };

  const confirmSoftDelete = async () => {
    if (!deleteDialog) return;
    const p = deleteDialog;
    if (!deleteReason.trim()) {
      toast({ variant: "destructive", title: "Please enter a deletion reason" }); return;
    }
    try {
      await pb.collection("audit_logs").create({
        actor: user.id, action: "parcel_soft_deleted", entity: p.id,
        details: JSON.stringify({ reason: deleteReason, deletedBy: user.email, parcelNumber: p.parcelNumber, timestamp: new Date().toISOString() }),
      });
      setSoftDeletedIds((prev) => new Set([...prev, p.id]));
      toast({ title: "Record soft-deleted", description: `${p.parcelNumber} marked as deleted. It remains in the system.` });
      await log("parcel_soft_deleted", "parcels", `Soft-deleted ${p.parcelNumber}: ${deleteReason}`);
      setDeleteDialog(null); setDeleteReason("");
    } catch (err) {
      toast({ variant: "destructive", title: "Failed", description: err?.message });
    }
  };

  const confirmPermDelete = async () => {
    if (!permDeleteDialog || permDeleting) return;
    const p = permDeleteDialog;
    if (!permDeleteReason.trim()) {
      toast({ variant: "destructive", title: "Please enter a reason for permanent deletion" }); return;
    }
    setPermDeleting(true);
    try {
      // Cascade delete related records first to avoid FK constraint failures
      const related = [
        ["documents", `parcel = "${p.id}"`],
        ["payments", `parcel = "${p.id}"`],
        ["surveys", `parcel = "${p.id}"`],
        ["land_transfers", `parcel = "${p.id}"`],
        ["land_edit_requests", `parcel = "${p.id}"`],
        ["applications", `parcel = "${p.id}"`],
      ];
      for (const [col, filter] of related) {
        try {
          const items = await pb.collection(col).getFullList({ filter, requestKey: `perm-del-${col}-${p.id}` });
          for (const item of items) {
            await pb.collection(col).delete(item.id);
          }
        } catch (_) { /* collection may not exist or may be empty */ }
      }
      await pb.collection("parcels").delete(p.id);
      // Clean up notifications that reference this parcel to remove all traces
      try {
        const relatedNotifs = await pb.collection("notifications").getFullList({
          filter: pb.filter("message ~ {:pn}", { pn: p.parcelNumber }),
          requestKey: `perm-del-notifs-${p.id}`,
        });
        for (const rn of relatedNotifs) {
          await pb.collection("notifications").delete(rn.id).catch(() => {});
        }
      } catch (_) {}
      await log("parcel_permanent_deleted", "parcels", `Record permanently deleted — Reason: ${permDeleteReason} — By: ${user.email}`);
      toast({ title: "Record permanently deleted", description: "The record and all related notifications have been removed." });
      setSoftDeletedIds((prev) => { const next = new Set(prev); next.delete(p.id); return next; });
      setPermDeleteDialog(null); setPermDeleteReason("");
      reload();
    } catch (err) {
      console.error("Permanent delete failed", err);
      const detail = err?.status === 403
        ? "You do not have permission to permanently delete this record."
        : (err?.response?.data?.message || err?.response?.message || err?.message || "Unknown error");
      try { await log("parcel_permanent_delete_failed", "parcels", `${p.parcelNumber}: ${detail}`); } catch (_) {}
      toast({ variant: "destructive", title: "Permanent delete failed", description: `${detail} You can retry.` });
    } finally {
      setPermDeleting(false);
    }
  };

  const handleRestore = async (p) => {
    if (!window.confirm(`Restore parcel ${p.parcelNumber}?`)) return;
    try {
      await pb.collection("audit_logs").create({
        actor: user.id, action: "parcel_restored", entity: p.id,
        details: JSON.stringify({ restoredBy: user.email, parcelNumber: p.parcelNumber, timestamp: new Date().toISOString() }),
      });
      setSoftDeletedIds((prev) => { const n = new Set(prev); n.delete(p.id); return n; });
      toast({ title: "Record restored", description: `${p.parcelNumber} is now active again.` });
      await log("parcel_restored", "parcels", `Restored ${p.parcelNumber}`);
    } catch (err) {
      toast({ variant: "destructive", title: "Restore failed", description: err?.message });
    }
  };

  const exportCSV = () => {
    const headers = ["parcelNumber", "applicantName", "contactPhone", "alternateMobile", "whatsapp", "applicantEmail",
      "religion", "tribe", "areaCouncil", "community", "sector", "plotNumber", "block", "allocationDate", "registrationDate", "status", "created"];
    const rows = [headers, ...filtered.map((p) => headers.map((h) => p[h] || ""))];
    const csv = rows.map((r) => r.map((v) => `"${v}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "parcels.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  const editFormValue = editParcel ? {
    applicantName: editParcel.applicantName || "",
    contactPhone: editParcel.contactPhone || "",
    alternateMobile: editParcel.alternateMobile || "",
    whatsapp: editParcel.whatsapp || "",
    applicantEmail: editParcel.applicantEmail || "",
    religion: editParcel.religion || "",
    tribe: editParcel.tribe || "",
    office: editParcel.office || "",
    areaCouncil: editParcel.areaCouncil || "",
    community: editParcel.community || "",
    sector: editParcel.sector || "",
    plotNumber: editParcel.plotNumber || "",
    block: editParcel.block || "",
    allocationDate: editParcel.allocationDate ? editParcel.allocationDate.split(" ")[0] : "",
    registrationDate: editParcel.registrationDate ? editParcel.registrationDate.split(" ")[0] : "",
  } : { ...EMPTY_FORM };

  const setEditFormValue = (updater) => {
    setEditParcel((prev) => {
      const updated = typeof updater === "function" ? updater(editFormValue) : updater;
      return { ...prev, ...updated };
    });
  };

  const formACs = userACs || ALL_AREA_COUNCILS;

  return (
    <>
      <PageHeader
        title="Land Registration"
        subtitle={isCitizen ? "Register and manage your land parcels" : "District land parcel register"}
        icon={MapPinned}
        action={
          <div className="flex gap-2">
            {isAdmin && (
              <Button variant="outline" size="sm" onClick={() => setImportOpen(true)}>
                <Upload className="mr-1 h-4 w-4" /> Import
              </Button>
            )}
            <Button variant="outline" size="sm" onClick={exportCSV}>
              <Download className="mr-1 h-4 w-4" /> Export
            </Button>
            <Button size="sm" onClick={() => { setForm({ ...EMPTY_FORM, areaCouncil: defaultAC }); setRegisterOpen(true); }}>
              <Plus className="mr-1 h-4 w-4" /> Register parcel
            </Button>
          </div>
        }
      />

      {/* Approvals panel */}
      <ApprovalsPanel userId={user.id} isApprover={isApprover} reload={reload} />

      {/* Filters + View Mode */}
      <div className="rounded-xl border border-border bg-card p-3 space-y-3 shadow-sm">
        <div className="flex flex-wrap gap-2">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={searchQ} onChange={(e) => setSearchQ(e.target.value)}
              placeholder="Search by name, ID, plot, community…" className="pl-9 h-9" />
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-40 h-9"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              {STATUSES.map((s) => <SelectItem key={s} value={s}>{s === "all" ? "All statuses" : titleCase(s)}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={deletionFilter} onValueChange={setDeletionFilter}>
            <SelectTrigger className="w-36 h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active only</SelectItem>
              <SelectItem value="all">Show all</SelectItem>
              <SelectItem value="deleted">Deleted only</SelectItem>
            </SelectContent>
          </Select>
          <button onClick={() => setShowMoreFilters((v) => !v)}
            className={cn("flex items-center gap-1.5 rounded-lg border px-3 h-9 text-xs font-medium transition",
              showMoreFilters ? "bg-primary text-white border-primary" : "border-border text-muted-foreground hover:border-primary/50")}>
            <Filter className="h-3.5 w-3.5" />
            More filters
            {activeFilterCount > 0 && <span className="ml-1 rounded-full bg-white/20 px-1.5 py-0.5 text-[10px]">{activeFilterCount}</span>}
          </button>
          {activeFilterCount > 0 && (
            <button onClick={() => { setFilterStatus("all"); setFilterAC("all"); setFilterCommunity("all"); setFilterSector("all"); setFilterYear("all"); setSearchQ(""); }}
              className="flex items-center gap-1 text-xs text-red-600 hover:text-red-800 px-2 h-9">
              Clear all
            </button>
          )}
          <div className="flex rounded-lg border border-border bg-background overflow-hidden ml-auto">
            {VIEW_MODES.map(({ key, label, icon: Icon }) => (
              <button key={key} title={label} onClick={() => switchViewMode(key)}
                className={cn("flex items-center gap-1 px-2.5 py-1.5 text-xs transition",
                  viewMode === key ? "bg-primary text-white" : "text-muted-foreground hover:bg-muted")}>
                <Icon className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{label}</span>
              </button>
            ))}
          </div>
        </div>
        {showMoreFilters && (
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4 border-t border-border pt-3">
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Area Council</label>
              <SearchableSelect value={filterAC} onValueChange={setFilterAC} options={uniqueACs.map((v) => ({ value: v, label: v === "all" ? "All area councils" : v }))} placeholder="All area councils" className="h-8 text-xs" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Community</label>
              <SearchableSelect value={filterCommunity} onValueChange={setFilterCommunity} options={uniqueCommunities.map((v) => ({ value: v, label: v === "all" ? "All communities" : v }))} placeholder="All communities" className="h-8 text-xs" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Sector</label>
              <SearchableSelect value={filterSector} onValueChange={setFilterSector} options={uniqueSectors.map((v) => ({ value: v, label: v === "all" ? "All sectors" : v }))} placeholder="All sectors" className="h-8 text-xs" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Year</label>
              <SearchableSelect value={filterYear} onValueChange={setFilterYear} options={uniqueYears.map((v) => ({ value: v, label: v === "all" ? "All years" : v }))} placeholder="All years" className="h-8 text-xs" />
            </div>
          </div>
        )}
      </div>

      {/* Stats pills */}
      <div className="flex flex-wrap gap-2">
        {["registered", "submitted", "disputed", "under_review"].map((s) => {
          const count = accessibleRecords.filter((r) => !softDeletedIds.has(r.id) && r.status === s).length;
          return count > 0 ? (
            <button key={s} onClick={() => setFilterStatus(filterStatus === s ? "all" : s)}
              className={cn("rounded-full px-3 py-1 text-xs font-medium transition border",
                filterStatus === s ? "bg-primary text-white border-primary" : "bg-card border-border text-muted-foreground hover:border-primary/40")}>
              {titleCase(s)}: {count}
            </button>
          ) : null;
        })}
        {softDeletedIds.size > 0 && (
          <button onClick={() => setDeletionFilter(deletionFilter === "deleted" ? "active" : "deleted")}
            className={cn("rounded-full px-3 py-1 text-xs font-medium transition border",
              deletionFilter === "deleted" ? "bg-red-600 text-white border-red-600" : "bg-red-50 border-red-200 text-red-700 hover:bg-red-100")}>
            Deleted: {softDeletedIds.size}
          </button>
        )}
        {Object.keys(transferMap).length > 0 && (
          <span className="rounded-full bg-amber-50 border border-amber-200 text-amber-700 px-3 py-1 text-xs font-medium">
            Transferred: {Object.keys(transferMap).length}
          </span>
        )}
        <span className="ml-auto self-center text-xs text-muted-foreground">
          {filtered.length} of {accessibleRecords.length} parcels
        </span>
      </div>
      {/* Bulk operations toolbar */}
      <div className="rounded-xl border border-border bg-muted/30 px-4 py-3 space-y-2">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Bulk operations</span>
          <Button size="sm" variant="outline" onClick={selectAll}>Select all ({filtered.length})</Button>
          {selectedIds.length > 0 && <span className="text-sm text-primary font-semibold">{selectedIds.length} selected</span>}
          {selectedIds.length > 0 && <Button size="sm" variant="ghost" onClick={clearSelection}>Clear</Button>}
        </div>
        {selectedIds.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {canBulkRegister && (
              <Button size="sm" onClick={bulkRegister} disabled={!!bulkProgress}>
                <FileCheck className="mr-1 h-3.5 w-3.5" /> Bulk Register
              </Button>
            )}
            <Button size="sm" variant="outline" className="text-orange-600 border-orange-200 hover:bg-orange-50"
              onClick={bulkDispute} disabled={!!bulkProgress}>
              <AlertTriangle className="mr-1 h-3.5 w-3.5" /> Bulk Dispute
            </Button>
            <Button size="sm" variant="outline" onClick={() => { setBulkAmendReason(""); setBulkAmendOpen(true); }} disabled={!!bulkProgress}>
              <Pencil className="mr-1 h-3.5 w-3.5" /> Bulk Amend Request
            </Button>
            {isAdmin && (
              <>
                <Select value={bulkStatus} onValueChange={setBulkStatus}>
                  <SelectTrigger className="h-8 w-40 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["submitted","under_survey","under_review","registered","rejected"].map((s) => (
                      <SelectItem key={s} value={s}>{titleCase(s)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button size="sm" variant="outline" onClick={bulkUpdateStatus} disabled={!!bulkProgress}>Set Status</Button>
                <Button size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50"
                  onClick={bulkDelete} disabled={!!bulkProgress}>
                  <XCircle className="mr-1 h-3.5 w-3.5" /> Bulk Delete
                </Button>
              </>
            )}
          </div>
        )}
        {bulkProgress && (
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-primary">{bulkProgress.op}</span>
              <span className="font-mono font-bold text-primary">{Math.round((bulkProgress.done / bulkProgress.total) * 100)}%</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-1 h-2 rounded-full bg-border overflow-hidden">
                <div className="h-full bg-primary transition-all duration-150 rounded-full"
                  style={{ width: `${(bulkProgress.done / bulkProgress.total) * 100}%` }} />
              </div>
              <span className="text-xs text-muted-foreground shrink-0">{bulkProgress.done}/{bulkProgress.total}</span>
            </div>
          </div>
        )}
      </div>

      {loading ? <Spinner /> : filtered.length === 0 ? (
        <EmptyState icon={MapPinned} title="No parcels found"
          message={accessibleRecords.length === 0 ? "Register your first land parcel to begin the titling process." : "No parcels match your current filters."} />
      ) : (
        <div className={cn(
          "gap-3",
          viewMode === "small" ? "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5" :
          viewMode === "list" ? "flex flex-col" :
          viewMode === "large" ? "grid gap-4 lg:grid-cols-2" :
          "grid gap-4 md:grid-cols-2"
        )}>
          {parcelPageItems.map((p) => {
            const isDel = softDeletedIds.has(p.id);
            const tInfo = transferMap[p.id] || null;
            return (
              <div key={p.id} className="relative">
                {viewMode !== "list" && (
                  <input type="checkbox" checked={selectedIds.includes(p.id)}
                    onChange={() => toggleSelect(p.id)}
                    className="absolute left-3 top-3 z-10 h-4 w-4 rounded accent-primary cursor-pointer" />
                )}
                {viewMode === "list" && (
                  <input type="checkbox" checked={selectedIds.includes(p.id)}
                    onChange={() => toggleSelect(p.id)}
                    className="absolute left-2 top-1/2 -translate-y-1/2 z-10 h-4 w-4 rounded accent-primary cursor-pointer" />
                )}
                <div className={viewMode === "list" ? "pl-7" : ""}>
                  <ParcelCard p={p} isStaff={isStaff} isCitizen={isCitizen} isApprover={isApprover} isAdmin={isAdmin}
                    isDeleted={isDel} isTransferred={!!tInfo} transferInfo={tInfo} viewMode={viewMode}
                    onCert={setCertParcel} onHistory={setHistoryParcel}
                    onEdit={handleEdit} onSetStatus={setStatus} onDispute={flagDispute}
                    onTransfer={setTransferParcel} onDelete={handleDelete} onRestore={handleRestore}
                    onPermDelete={(p) => { setPermDeleteDialog(p); setPermDeleteReason(""); }} />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination bottom */}
      {filtered.length > 0 && (
        <PaginationControl currentPage={parcelPage} totalPages={parcelTotalPages} totalRecords={parcelTotalRecords} pageSize={parcelPageSize} onPageChange={(p) => { setParcelPage(p); window.scrollTo({ top: 0, behavior: 'smooth' }); }} onPageSizeChange={setParcelPageSize} />
      )}

      {/* Register dialog */}
      <Dialog open={registerOpen} onOpenChange={setRegisterOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader><DialogTitle>Register a Land Parcel</DialogTitle></DialogHeader>
          <ParcelForm form={form} setForm={setForm} onSubmit={submit} onCancel={() => setRegisterOpen(false)}
            saving={saving} submitLabel="Register Parcel" userAreaCouncils={formACs} />
        </DialogContent>
      </Dialog>

      {/* Direct edit dialog (for staff or draft parcels) */}
      <Dialog open={!!editParcel} onOpenChange={(o) => { if (!o) setEditParcel(null); }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader><DialogTitle>Amend Parcel — {editParcel?.parcelNumber}</DialogTitle></DialogHeader>
          {editParcel && (
            <ParcelForm form={editFormValue} setForm={setEditFormValue}
              onSubmit={saveEdit} onCancel={() => setEditParcel(null)}
              saving={saving} submitLabel="Save Changes" userAreaCouncils={formACs} />
          )}
        </DialogContent>
      </Dialog>

      {/* Edit request dialog (for registered parcels by non-approvers) */}
      <Dialog open={!!editRequestParcel} onOpenChange={(o) => { if (!o) setEditRequestParcel(null); }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader><DialogTitle>Request Edit — {editRequestParcel?.parcelNumber}</DialogTitle></DialogHeader>
          {editRequestParcel && (
            <EditRequestModal parcel={editRequestParcel} userId={user.id}
              onClose={() => setEditRequestParcel(null)} onDone={reload} />
          )}
        </DialogContent>
      </Dialog>

      {/* Transfer dialog */}
      <Dialog open={!!transferParcel} onOpenChange={(o) => { if (!o) setTransferParcel(null); }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>Transfer Land — {transferParcel?.parcelNumber}</DialogTitle></DialogHeader>
          {transferParcel && (
            <TransferModal parcel={transferParcel} userId={user.id}
              onClose={() => setTransferParcel(null)} onDone={reload} />
          )}
        </DialogContent>
      </Dialog>

      {/* Certificate modal */}
      <Dialog open={!!certParcel} onOpenChange={() => setCertParcel(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader><DialogTitle>Land Title Certificate</DialogTitle></DialogHeader>
          {certParcel && <CertificateModal parcel={certParcel} onClose={() => setCertParcel(null)} />}
        </DialogContent>
      </Dialog>

      {/* History modal */}
      <Dialog open={!!historyParcel} onOpenChange={() => setHistoryParcel(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle>Parcel History</DialogTitle></DialogHeader>
          {historyParcel && <HistoryModal parcel={historyParcel} />}
        </DialogContent>
      </Dialog>

      {/* Bulk amend dialog */}
      <Dialog open={bulkAmendOpen} onOpenChange={setBulkAmendOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle>Bulk Amendment Request ({selectedIds.length} parcels)</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <p className="text-sm text-muted-foreground">An amendment request will be created for each selected parcel and sent to a Physical Planning Officer or Admin for approval.</p>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Reason <span className="text-destructive">*</span></Label>
              <Input value={bulkAmendReason} onChange={(e) => setBulkAmendReason(e.target.value)} placeholder="Reason for amendment…" />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setBulkAmendOpen(false)} className="flex-1">Cancel</Button>
              <Button onClick={submitBulkAmend} className="flex-1">Submit {selectedIds.length} Requests</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Import modal (Admin only) */}
      {isAdmin && (
        <Dialog open={importOpen} onOpenChange={setImportOpen}>
          <DialogContent className="sm:max-w-xl">
            <DialogHeader><DialogTitle>Bulk Import Parcels (Admin)</DialogTitle></DialogHeader>
            <ImportModal userId={user.id} onDone={reload} onClose={() => setImportOpen(false)} />
          </DialogContent>
        </Dialog>
      )}

      {/* Permanent Delete Confirmation Dialog — Admin only */}
      <Dialog open={!!permDeleteDialog} onOpenChange={(o) => { if (!o) { setPermDeleteDialog(null); setPermDeleteReason(""); } }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle className="flex items-center gap-2 text-red-800"><Trash2 className="h-4 w-4" /> Permanent Delete — {permDeleteDialog?.parcelNumber}</DialogTitle></DialogHeader>
          <div className="space-y-4 py-1">
            <div className="rounded-lg bg-red-100 border-2 border-red-400 p-3 text-sm text-red-900">
              <p className="font-bold mb-1 flex items-center gap-1"><AlertTriangle className="h-4 w-4" /> WARNING: THIS ACTION IS IRREVERSIBLE</p>
              <p>This will <strong>permanently remove</strong> the record from the database. It cannot be recovered. This action is only available for soft-deleted records.</p>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground bg-muted/40 rounded-lg p-3">
              <span><span className="font-medium">Owner:</span> {permDeleteDialog?.applicantName || "—"}</span>
              <span><span className="font-medium">Plot:</span> {permDeleteDialog?.plotNumber || "—"} / {permDeleteDialog?.block || "—"}</span>
              <span><span className="font-medium">Area Council:</span> {permDeleteDialog?.areaCouncil || "—"}</span>
              <span><span className="font-medium">Land ID:</span> {permDeleteDialog?.parcelNumber || "—"}</span>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Reason for Permanent Deletion <span className="text-destructive">*</span></Label>
              <Input value={permDeleteReason} onChange={(e) => setPermDeleteReason(e.target.value)}
                placeholder="Enter reason for permanent deletion…" />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => { setPermDeleteDialog(null); setPermDeleteReason(""); }} className="flex-1">Cancel</Button>
              <Button variant="destructive" onClick={confirmPermDelete} disabled={permDeleting} className="flex-1 bg-red-800 hover:bg-red-900">
                <Trash2 className="mr-1 h-4 w-4" /> {permDeleting ? "Deleting…" : "Permanently Delete"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Soft Delete Confirmation Dialog */}
      <Dialog open={!!deleteDialog} onOpenChange={(o) => { if (!o) { setDeleteDialog(null); setDeleteReason(""); } }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle className="flex items-center gap-2 text-red-700"><Trash2 className="h-4 w-4" /> Soft Delete — {deleteDialog?.parcelNumber}</DialogTitle></DialogHeader>
          <div className="space-y-4 py-1">
            <div className="rounded-lg bg-red-50 border border-red-200 p-3 text-sm text-red-800">
              <p className="font-semibold mb-1">This is a soft delete — the record will remain in the system.</p>
              <p>The land record will be hidden from active listings and color-graded <strong>RED</strong> as DELETED. You can restore it anytime.</p>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground bg-muted/40 rounded-lg p-3">
              <span><span className="font-medium">Owner:</span> {deleteDialog?.applicantName || "—"}</span>
              <span><span className="font-medium">Plot:</span> {deleteDialog?.plotNumber || "—"} / {deleteDialog?.block || "—"}</span>
              <span><span className="font-medium">Area Council:</span> {deleteDialog?.areaCouncil || "—"}</span>
              <span><span className="font-medium">Status:</span> {deleteDialog?.status || "—"}</span>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Deletion Reason <span className="text-destructive">*</span></Label>
              <Input value={deleteReason} onChange={(e) => setDeleteReason(e.target.value)}
                placeholder="Enter reason for deleting this record…" />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => { setDeleteDialog(null); setDeleteReason(""); }} className="flex-1">Cancel</Button>
              <Button variant="destructive" onClick={confirmSoftDelete} className="flex-1">
                <Trash2 className="mr-1 h-4 w-4" /> Confirm Soft Delete
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
