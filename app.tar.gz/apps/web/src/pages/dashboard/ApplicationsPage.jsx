import React, { useState, useMemo } from "react";
import { ClipboardList, Plus, ArrowRight, XCircle, CheckCircle2, MessageSquare, Clock, AlertTriangle, Filter, Search, Send, Calendar, Pencil, Trash2 } from "lucide-react";
import pb from "@/lib/pocketbaseClient";
import { useAuth } from "@/lib/auth";
import { useCollection, notify } from "@/lib/useCollection";
import { PageHeader, StatusBadge, Spinner, EmptyState, StatCard } from "@/components/shared";
import { titleCase, formatDate, timeAgo, genRef } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const APP_TYPES = ["registration", "transfer", "subdivision", "title_search", "customary_record", "renewal"];
const ALL_STATUSES = ["submitted", "planning_review", "survey", "registrar_review", "approved", "rejected", "completed"];

// SLA days per status
const SLA_DAYS = { submitted: 2, planning_review: 5, survey: 10, registrar_review: 5 };

function slaStatus(app) {
  if (!["submitted", "planning_review", "survey", "registrar_review"].includes(app.status)) return null;
  const created = new Date(app.updated || app.created).getTime();
  const days = (Date.now() - created) / 86400000;
  const limit = SLA_DAYS[app.status] || 7;
  if (days > limit) return { status: "overdue", days: Math.round(days), limit };
  if (days > limit * 0.75) return { status: "warning", days: Math.round(days), limit };
  return { status: "ok", days: Math.round(days), limit };
}

const STAGE = {
  planning_officer: { from: "submitted", next: "planning_review", label: "Accept → Planning review" },
  survey_officer: { from: "planning_review", next: "survey", label: "Assign survey" },
  registrar: { from: "survey", next: "registrar_review", label: "Send to registry" },
  customary_secretariat: { from: "submitted", next: "planning_review", label: "Accept → Planning" },
  admin: { from: "*", next: "completed", label: "Mark completed" },
};

// Workflow pipeline steps
const PIPELINE = [
  { key: "submitted", label: "Submitted" },
  { key: "planning_review", label: "Planning" },
  { key: "survey", label: "Survey" },
  { key: "registrar_review", label: "Registry" },
  { key: "approved", label: "Approved" },
  { key: "completed", label: "Issued" },
];

function WorkflowPipeline({ status }) {
  const idx = PIPELINE.findIndex((s) => s.key === status);
  const isRejected = status === "rejected";
  return (
    <div className="flex items-center gap-0.5 overflow-x-auto py-1">
      {PIPELINE.map((step, i) => {
        const done = !isRejected && i <= idx;
        const current = !isRejected && i === idx;
        return (
          <React.Fragment key={step.key}>
            <div className={cn("flex flex-col items-center shrink-0", current ? "opacity-100" : "opacity-60")}>
              <div className={cn("h-2.5 w-2.5 rounded-full border-2 transition",
                done ? "bg-primary border-primary" : "bg-white border-border",
                current && "ring-2 ring-primary/30")} />
              <span className="mt-0.5 text-[9px] text-muted-foreground whitespace-nowrap">{step.label}</span>
            </div>
            {i < PIPELINE.length - 1 && (
              <div className={cn("h-0.5 w-6 shrink-0 rounded", done ? "bg-primary" : "bg-border")} />
            )}
          </React.Fragment>
        );
      })}
      {isRejected && <span className="ml-2 rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-medium text-red-600">Rejected</span>}
    </div>
  );
}

function CommentsThread({ app, onCommented }) {
  const { user } = useAuth();
  const [comment, setComment] = useState("");
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const logs = Array.isArray(app.reviewLog) ? app.reviewLog : [];
  const comments = logs.filter((l) => l.isComment);

  const addComment = async () => {
    if (!comment.trim()) return;
    setSaving(true);
    try {
      const entry = { at: new Date().toISOString(), by: `${user.fullName || user.email}`, note: comment.trim(), isComment: true };
      const reviewLog = [...logs, entry];
      await pb.collection("applications").update(app.id, { reviewLog });
      setComment("");
      onCommented?.();
    } catch (err) {
      toast({ variant: "destructive", title: "Comment failed" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-3">
      {comments.length === 0 ? (
        <p className="text-xs text-muted-foreground">No comments yet.</p>
      ) : (
        <ul className="space-y-2">
          {comments.map((c, i) => (
            <li key={i} className="rounded-lg bg-muted/40 p-3 text-sm">
              <p>{c.note}</p>
              <p className="mt-1 text-xs text-muted-foreground">{c.by} · {timeAgo(c.at)}</p>
            </li>
          ))}
        </ul>
      )}
      <div className="flex gap-2">
        <Input value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Add a comment…" className="text-sm" onKeyDown={(e) => e.key === "Enter" && addComment()} />
        <Button size="sm" onClick={addComment} disabled={saving || !comment.trim()}>
          <Send className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  );
}

export default function ApplicationsPage() {
  const { user, role, log } = useAuth();
  const { toast } = useToast();
  const isCitizen = false; // citizen role removed

  const { records, loading, reload } = useCollection("applications", {
    filter: isCitizen ? `applicant = "${user.id}"` : "",
    expand: "applicant,parcel",
  });
  const { records: myParcels } = useCollection("parcels", {
    filter: isCitizen ? `owner = "${user.id}"` : "",
    enabled: isCitizen,
  });

  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editApp, setEditApp] = useState(null);
  const [deleteApp, setDeleteApp] = useState(null);
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [searchQ, setSearchQ] = useState("");
  const [expandedApp, setExpandedApp] = useState(null);
  const [form, setForm] = useState({ type: "registration", parcel: "none", notes: "" });
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e?.target ? e.target.value : e }));

  const filtered = useMemo(() => {
    return records.filter((a) => {
      const matchStatus = filterStatus === "all" || a.status === filterStatus;
      const matchType = filterType === "all" || a.type === filterType;
      const q = searchQ.toLowerCase();
      const matchQ = !q || a.reference?.toLowerCase().includes(q) || a.expand?.applicant?.fullName?.toLowerCase().includes(q) || a.notes?.toLowerCase().includes(q);
      return matchStatus && matchType && matchQ;
    });
  }, [records, filterStatus, filterType, searchQ]);

  const statsCount = (s) => records.filter((a) => a.status === s).length;
  const overdue = records.filter((a) => slaStatus(a)?.status === "overdue").length;

  const submit = async () => {
    setSaving(true);
    try {
      const rec = await pb.collection("applications").create({
        applicant: user.id,
        parcel: form.parcel !== "none" ? form.parcel : null,
        reference: genRef("application"),
        type: form.type,
        status: "submitted",
        notes: form.notes,
        reviewLog: [{ at: new Date().toISOString(), by: user.fullName || user.email, note: "Application submitted by citizen" }],
      });
      await log("application_submitted", "applications", `${rec.reference} — ${titleCase(form.type)}`);
      toast({ title: "Application submitted", description: `${rec.reference} is now in review.` });
      setOpen(false);
      setForm({ type: "registration", parcel: "none", notes: "" });
      reload();
    } catch (err) {
      toast({ variant: "destructive", title: "Submission failed", description: err?.message });
    } finally {
      setSaving(false);
    }
  };

  const advance = async (app, next, actionLabel) => {
    const entry = { at: new Date().toISOString(), by: `${user.fullName || user.email} (${titleCase(role)})`, note: actionLabel };
    const reviewLog = Array.isArray(app.reviewLog) ? [...app.reviewLog, entry] : [entry];
    await pb.collection("applications").update(app.id, { status: next, reviewLog });
    await log("application_advanced", "applications", `${app.reference} → ${titleCase(next)}`);
    await notify(app.applicant, `Your application ${app.reference} is now at ${titleCase(next)} stage.`, "/app/applications");
    reload();
    toast({ title: "Application advanced", description: `${app.reference} → ${titleCase(next)}` });
  };

  const reject = async (app) => {
    const entry = { at: new Date().toISOString(), by: `${user.fullName || user.email} (${titleCase(role)})`, note: "Application rejected" };
    const reviewLog = Array.isArray(app.reviewLog) ? [...app.reviewLog, entry] : [entry];
    await pb.collection("applications").update(app.id, { status: "rejected", reviewLog });
    await log("application_rejected", "applications", app.reference);
    await notify(app.applicant, `Your application ${app.reference} was rejected. Contact the office for details.`, "/app/applications");
    reload();
  };

  const saveEditApp = async () => {
    if (!editApp) return;
    setSaving(true);
    try {
      await pb.collection("applications").update(editApp.id, {
        type: editApp.type,
        status: editApp.status,
        notes: editApp.notes,
      });
      await log("application_updated", "applications", editApp.reference);
      toast({ title: "Application updated" });
      setEditApp(null);
      reload();
    } catch (err) {
      toast({ variant: "destructive", title: "Update failed", description: err?.message });
    } finally {
      setSaving(false);
    }
  };

  const doDeleteApp = async () => {
    if (!deleteApp) return;
    try {
      await pb.collection("applications").delete(deleteApp.id);
      await log("application_deleted", "applications", deleteApp.reference);
      toast({ title: "Application deleted" });
      setDeleteApp(null);
      reload();
    } catch (err) {
      toast({ variant: "destructive", title: "Delete failed", description: err?.message });
    }
  };

  const approve = async (app) => {
    const entry = { at: new Date().toISOString(), by: `${user.fullName || user.email} (${titleCase(role)})`, note: "Application approved and certificate ready" };
    const reviewLog = Array.isArray(app.reviewLog) ? [...app.reviewLog, entry] : [entry];
    await pb.collection("applications").update(app.id, { status: "completed", reviewLog });
    await notify(app.applicant, `Your application ${app.reference} has been approved! Download your certificate.`, "/app/applications");
    reload();
    toast({ title: "Application approved", description: "Applicant has been notified." });
  };

  const stage = STAGE[role];

  return (
    <>
      <PageHeader
        title="Applications & Workflow"
        subtitle={isCitizen ? "Submit and track your land applications" : "Review, process and advance applications"}
        icon={ClipboardList}
        action={isCitizen && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="mr-1 h-4 w-4" /> New application</Button></DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader><DialogTitle>Submit an application</DialogTitle></DialogHeader>
              <div className="space-y-4 py-2">
                <div className="space-y-2">
                  <Label>Application type</Label>
                  <Select value={form.type} onValueChange={set("type")}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{APP_TYPES.map((v) => <SelectItem key={v} value={v}>{titleCase(v)}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Related parcel (optional)</Label>
                  <Select value={form.parcel} onValueChange={set("parcel")}>
                    <SelectTrigger><SelectValue placeholder="Select a parcel" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No specific parcel</SelectItem>
                      {myParcels.map((p) => <SelectItem key={p.id} value={p.id}>{p.parcelNumber} — {p.title}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Description / notes</Label>
                  <Textarea value={form.notes} onChange={set("notes")} rows={3} placeholder="Describe your request in detail…" />
                </div>
                <div className="rounded-lg bg-muted/50 p-3 text-xs text-muted-foreground">
                  SLA: Registration — 5 days · Transfer — 7 days · Subdivision — 14 days
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button onClick={submit} disabled={saving}>{saving ? "Submitting…" : "Submit"}</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      />

      {/* Stats */}
      {!isCitizen && (
        <div className="grid gap-3 sm:grid-cols-4">
          <StatCard label="Submitted" value={statsCount("submitted")} icon={ClipboardList} accent="blue" />
          <StatCard label="In review" value={statsCount("planning_review") + statsCount("survey") + statsCount("registrar_review")} icon={Clock} accent="gold" />
          <StatCard label="Approved" value={statsCount("approved") + statsCount("completed")} icon={CheckCircle2} accent="emerald" />
          <StatCard label="Overdue SLA" value={overdue} icon={AlertTriangle} accent={overdue > 0 ? "gold" : "primary"} />
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={searchQ} onChange={(e) => setSearchQ(e.target.value)} placeholder="Search applications…" className="pl-9" />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-44"><Filter className="mr-2 h-4 w-4" /><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {ALL_STATUSES.map((s) => <SelectItem key={s} value={s}>{titleCase(s)}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All types</SelectItem>
            {APP_TYPES.map((v) => <SelectItem key={v} value={v}>{titleCase(v)}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {loading ? <Spinner /> : filtered.length === 0 ? (
        <EmptyState icon={ClipboardList} title="No applications" message={isCitizen ? "Submit an application to register, transfer or search a title." : "No applications match your filters."} />
      ) : (
        <div className="space-y-3">
          {filtered.map((a) => {
            const canAct = stage && (stage.from === "*" || stage.from === a.status);
            const sla = slaStatus(a);
            const isExpanded = expandedApp === a.id;
            const reviewLog = Array.isArray(a.reviewLog) ? a.reviewLog : [];
            const timeline = reviewLog.filter((l) => !l.isComment);
            return (
              <div key={a.id} className={cn("rounded-2xl border bg-card shadow-sm transition", sla?.status === "overdue" ? "border-orange-300" : "border-border")}>
                <div className="p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-mono text-xs text-muted-foreground">{a.reference}</p>
                        {sla?.status === "overdue" && (
                          <span className="inline-flex items-center gap-1 rounded-full bg-orange-100 px-2 py-0.5 text-[10px] font-medium text-orange-700">
                            <AlertTriangle className="h-3 w-3" /> SLA overdue ({sla.days}d / {sla.limit}d)
                          </span>
                        )}
                        {sla?.status === "warning" && (
                          <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-medium text-amber-700">
                            Due in {sla.limit - sla.days}d
                          </span>
                        )}
                      </div>
                      <h3 className="mt-0.5 font-display text-base font-semibold">{titleCase(a.type)}</h3>
                      <p className="mt-0.5 text-sm text-muted-foreground">
                        {a.expand?.applicant?.fullName || a.expand?.applicant?.email}
                        {a.expand?.parcel ? ` · ${a.expand.parcel.parcelNumber}` : ""} · {formatDate(a.created)}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <StatusBadge status={a.status} />
                      <button onClick={() => setExpandedApp(isExpanded ? null : a.id)}
                        className="rounded-lg p-1.5 hover:bg-muted/60 text-muted-foreground transition">
                        {isExpanded ? <ArrowRight className="h-4 w-4 rotate-90" /> : <ArrowRight className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Workflow pipeline */}
                  <div className="mt-3">
                    <WorkflowPipeline status={a.status} />
                  </div>

                  {a.notes && <p className="mt-3 text-sm text-muted-foreground">{a.notes}</p>}

                  {/* Actions */}
                  <div className="mt-4 flex flex-wrap gap-2 border-t border-border pt-4">
                    {canAct && a.status !== "completed" && a.status !== "rejected" && (
                      <>
                        <Button size="sm" onClick={() => advance(a, stage.next, stage.label)}>
                          <CheckCircle2 className="mr-1 h-4 w-4" /> {stage.label}
                        </Button>
                        {role === "registrar" && a.status === "registrar_review" && (
                          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => approve(a)}>
                            <CheckCircle2 className="mr-1 h-4 w-4" /> Approve & issue
                          </Button>
                        )}
                        {role !== "admin" && (
                          <Button size="sm" variant="outline" className="text-destructive" onClick={() => reject(a)}>
                            <XCircle className="mr-1 h-4 w-4" /> Reject
                          </Button>
                        )}
                      </>
                    )}
                    {(role === "admin" || role === "planning_officer") && (
                      <Button size="sm" variant="outline" onClick={() => setEditApp({ ...a })}>
                        <Pencil className="mr-1 h-3.5 w-3.5" /> Edit
                      </Button>
                    )}
                    {role === "admin" && (
                      <Button size="sm" variant="outline" className="text-destructive border-red-200 hover:bg-red-50"
                        onClick={() => setDeleteApp(a)}>
                        <Trash2 className="mr-1 h-3.5 w-3.5" /> Delete
                      </Button>
                    )}
                  </div>
                </div>

                {/* Expanded: timeline + comments */}
                {isExpanded && (
                  <div className="border-t border-border px-5 pb-5 pt-4">
                    <div className="grid gap-6 md:grid-cols-2">
                      <div>
                        <h4 className="mb-3 text-sm font-semibold">Review timeline</h4>
                        {timeline.length === 0 ? (
                          <p className="text-xs text-muted-foreground">No review actions yet.</p>
                        ) : (
                          <ol className="space-y-2 border-l-2 border-border pl-4">
                            {timeline.slice(-6).map((r, i) => (
                              <li key={i} className="relative text-xs text-muted-foreground">
                                <span className="absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full bg-primary" />
                                <span className="font-medium text-foreground">{r.note}</span>
                                <span> — {r.by} · {timeAgo(r.at)}</span>
                              </li>
                            ))}
                          </ol>
                        )}
                      </div>
                      <div>
                        <h4 className="mb-3 text-sm font-semibold flex items-center gap-1.5">
                          <MessageSquare className="h-4 w-4" /> Comments
                        </h4>
                        <CommentsThread app={a} onCommented={reload} />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
      {/* Edit Application Dialog */}
      <Dialog open={!!editApp} onOpenChange={(o) => { if (!o) setEditApp(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle>Edit Application — {editApp?.reference}</DialogTitle></DialogHeader>
          {editApp && (
            <div className="space-y-4 py-2">
              <div className="space-y-2">
                <Label>Type</Label>
                <Select value={editApp.type} onValueChange={(v) => setEditApp((a) => ({ ...a, type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{APP_TYPES.map((v) => <SelectItem key={v} value={v}>{titleCase(v)}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={editApp.status} onValueChange={(v) => setEditApp((a) => ({ ...a, status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{ALL_STATUSES.map((v) => <SelectItem key={v} value={v}>{titleCase(v)}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Notes</Label>
                <Textarea value={editApp.notes || ""} onChange={(e) => setEditApp((a) => ({ ...a, notes: e.target.value }))} rows={3} />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditApp(null)}>Cancel</Button>
                <Button onClick={saveEditApp} disabled={saving}>{saving ? "Saving…" : "Save Changes"}</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Application Dialog */}
      <Dialog open={!!deleteApp} onOpenChange={() => setDeleteApp(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader><DialogTitle>Delete Application</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground py-2">
            Permanently delete application <strong>{deleteApp?.reference}</strong>? This cannot be undone.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteApp(null)}>Cancel</Button>
            <Button variant="destructive" onClick={doDeleteApp}>
              <Trash2 className="mr-1 h-4 w-4" /> Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
