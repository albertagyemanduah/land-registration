import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  MapPinned, Wallet, Search, CheckCircle2, KeyRound, BarChart3, Users, Plus,
  TrendingUp, TrendingDown, ArrowRightLeft, ClipboardList, Filter, RotateCcw, Download,
} from "lucide-react";
import {
  ResponsiveContainer, LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, Legend,
  PieChart, Pie, Cell, BarChart, Bar, AreaChart, Area,
} from "recharts";
import pb from "@/lib/pocketbaseClient";
import { useAuth } from "@/lib/auth";
import { roleLabel } from "@/lib/roles";
import { useHierarchy } from "@/hooks/useHierarchy";
import { SectionCard, Spinner, StatusBadge } from "@/components/shared";
import { ghs, timeAgo, titleCase, formatDate } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

const COLORS = ["#166b4a", "#e0a422", "#2563eb", "#7c3aed", "#dc2626", "#0891b2", "#059669", "#d97706"];
const FILTER_KEY = "tnda-dash-filters";

function KpiCard({ label, value, icon: Icon, trend, hint, accent = "primary" }) {
  const accents = {
    primary: "bg-primary/10 text-primary",
    gold: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
    blue: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
    emerald: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400",
  };
  const up = typeof trend === "number" && trend >= 0;
  return (
    <div className="rounded-2xl border border-border bg-card p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
        {Icon && (
          <span className={cn("flex h-8 w-8 items-center justify-center rounded-lg", accents[accent])}>
            <Icon className="h-4 w-4" />
          </span>
        )}
      </div>
      <p className="mt-2 font-display text-2xl font-bold">{value}</p>
      <div className="mt-1 flex items-center gap-2 text-xs">
        {typeof trend === "number" && (
          <span className={cn("inline-flex items-center gap-0.5 font-medium", up ? "text-emerald-600" : "text-red-600")}>
            {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
            {Math.abs(trend)}%
          </span>
        )}
        {hint && <span className="text-muted-foreground">{hint}</span>}
      </div>
    </div>
  );
}

function QuickAction({ to, icon: Icon, title, desc }) {
  return (
    <Link
      to={to}
      className="group flex items-start gap-3 rounded-xl border border-border bg-card p-4 shadow-sm transition hover:border-primary/40 hover:shadow-md active:scale-[0.99]"
    >
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary transition group-hover:bg-primary group-hover:text-primary-foreground">
        <Icon className="h-5 w-5" />
      </span>
      <span className="min-w-0">
        <span className="block text-sm font-semibold">{title}</span>
        <span className="block text-xs leading-snug text-muted-foreground">{desc}</span>
      </span>
    </Link>
  );
}

function monthKey(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function last12(items, dateKey, valueFn) {
  const out = [];
  const now = new Date();
  for (let i = 11; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    out.push({ key: monthKey(d), name: d.toLocaleDateString("en-GB", { month: "short" }), value: 0 });
  }
  const idx = Object.fromEntries(out.map((r, i) => [r.key, i]));
  items.forEach((it) => {
    const d = new Date(it[dateKey]);
    if (isNaN(d)) return;
    const k = monthKey(d);
    if (k in idx) out[idx[k]].value += valueFn ? valueFn(it) : 1;
  });
  return out;
}

function tally(items, key) {
  const map = {};
  items.forEach((i) => {
    const v = i[key] || "unknown";
    map[v] = (map[v] || 0) + 1;
  });
  return Object.entries(map)
    .map(([name, value]) => ({ name: titleCase(name), value }))
    .sort((a, b) => b.value - a.value);
}

function pct(cur, prev) {
  if (!prev) return cur > 0 ? 100 : 0;
  return Math.round(((cur - prev) / prev) * 100);
}

export default function OverviewPage() {
  const { user, role } = useAuth();
  const isAdmin = role === "admin";
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState({ parcels: [], payments: [], transfers: [], requests: [] });
  const { offices, areaCouncils, communities, sectors, acForOffice, commForAC, sectForComm } = useHierarchy();

  const saved = (() => {
    try { return JSON.parse(localStorage.getItem(FILTER_KEY) || "{}"); } catch { return {}; }
  })();
  const [fOffice, setFOffice] = useState(saved.office || "all");
  const [fAC, setFAC] = useState(saved.ac || "all");
  const [fComm, setFComm] = useState(saved.comm || "all");
  const [fSect, setFSect] = useState(saved.sect || "all");
  const [fStatus, setFStatus] = useState(saved.status || "all");
  const [fFrom, setFFrom] = useState(saved.from || "");
  const [fTo, setFTo] = useState(saved.to || "");

  useEffect(() => {
    localStorage.setItem(
      FILTER_KEY,
      JSON.stringify({ office: fOffice, ac: fAC, comm: fComm, sect: fSect, status: fStatus, from: fFrom, to: fTo }),
    );
  }, [fOffice, fAC, fComm, fSect, fStatus, fFrom, fTo]);

  useEffect(() => {
    let alive = true;
    Promise.all([
      pb.collection("parcels").getFullList({ sort: "-created", requestKey: "dash-p" }).catch(() => []),
      pb.collection("payments").getFullList({ sort: "-created", requestKey: "dash-pay" }).catch(() => []),
      pb.collection("land_transfers").getFullList({ sort: "-created", requestKey: "dash-t" }).catch(() => []),
      pb.collection("land_edit_requests").getFullList({ sort: "-created", requestKey: "dash-r" }).catch(() => []),
    ]).then(([parcels, payments, transfers, requests]) => {
      if (!alive) return;
      setData({ parcels, payments, transfers, requests });
      setLoading(false);
    });
    return () => { alive = false; };
  }, []);

  const activeFilters =
    [fOffice, fAC, fComm, fSect, fStatus].filter((v) => v !== "all").length + (fFrom ? 1 : 0) + (fTo ? 1 : 0);

  const matches = (rec) => {
    if (fOffice !== "all" && rec.office && rec.office !== fOffice) return false;
    if (fAC !== "all" && rec.areaCouncil && rec.areaCouncil !== fAC) return false;
    if (fComm !== "all" && rec.community && rec.community !== fComm) return false;
    if (fSect !== "all" && rec.sector && rec.sector !== fSect) return false;
    const d = new Date(rec.created);
    if (fFrom && d < new Date(fFrom)) return false;
    if (fTo && d > new Date(`${fTo}T23:59:59`)) return false;
    return true;
  };

  const filtered = useMemo(() => {
    const parcels = data.parcels.filter((p) => matches(p) && (fStatus === "all" || p.status === fStatus));
    return {
      parcels,
      payments: data.payments.filter(matches),
      transfers: data.transfers.filter((t) => {
        const d = new Date(t.created);
        if (fFrom && d < new Date(fFrom)) return false;
        if (fTo && d > new Date(`${fTo}T23:59:59`)) return false;
        return true;
      }),
      requests: data.requests,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, fOffice, fAC, fComm, fSect, fStatus, fFrom, fTo]);

  if (loading) return <Spinner />;

  const now = new Date();
  const thisMonth = monthKey(now);
  const prevMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const prevMonth = monthKey(prevMonthDate);
  const thisYear = now.getFullYear();

  const inMonth = (arr, mk) => arr.filter((r) => monthKey(new Date(r.created)) === mk);
  const inYear = (arr, y) => arr.filter((r) => new Date(r.created).getFullYear() === y);

  const paid = filtered.payments.filter((p) => p.status === "paid");
  const sum = (arr) => arr.reduce((s, p) => s + (p.amount || 0), 0);

  const landsMonth = inMonth(filtered.parcels, thisMonth).length;
  const landsPrevMonth = inMonth(filtered.parcels, prevMonth).length;
  const landsYear = inYear(filtered.parcels, thisYear).length;
  const landsPrevYear = inYear(filtered.parcels, thisYear - 1).length;
  const revMonth = sum(inMonth(paid, thisMonth));
  const revPrevMonth = sum(inMonth(paid, prevMonth));
  const revYear = sum(inYear(paid, thisYear));
  const revPrevYear = sum(inYear(paid, thisYear - 1));

  const myScope = data.parcels.filter(
    (p) =>
      (!user?.communityRef || p.community === user.communityRef) &&
      (!user?.areaCouncilRef || p.areaCouncil === user.areaCouncilRef),
  ).length;

  const pendingApprovals = filtered.requests.filter((r) => r.status === "pending").length;
  const completedTransfers = filtered.transfers.filter((t) => t.status === "approved").length;

  const regTrend = last12(filtered.parcels, "created");
  const revTrend = last12(paid, "created", (p) => p.amount || 0);
  const byCommunity = tally(filtered.parcels, "community").slice(0, 8);
  const byOffice = tally(filtered.parcels, "office").slice(0, 8);
  const byStatus = tally(filtered.parcels, "status");
  const approvalsByStatus = tally(filtered.requests, "status");

  const hierarchyPath = [user?.officeRef, user?.areaCouncilRef, user?.communityRef, user?.sectorRef]
    .filter(Boolean)
    .join(" › ");

  const clearFilters = () => {
    setFOffice("all"); setFAC("all"); setFComm("all"); setFSect("all");
    setFStatus("all"); setFFrom(""); setFTo("");
  };

  const exportStats = () => {
    const rows = [
      ["TNDA Land Registry — Dashboard Statistics"],
      [`Generated: ${new Date().toLocaleString()}`],
      [`Active filters: ${activeFilters}`],
      [],
      ["Metric", "Value"],
      ["Total lands", filtered.parcels.length],
      ["Lands this month", landsMonth],
      ["Lands this year", landsYear],
      ["Lands in my hierarchy", myScope],
      ["Pending approvals", pendingApprovals],
      ["Completed transfers", completedTransfers],
      ["Revenue (all time)", sum(paid)],
      ["Revenue this month", revMonth],
      ["Revenue this year", revYear],
    ];
    const csv = rows.map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `dashboard_${new Date().toISOString().slice(0, 10).replace(/-/g, "")}.csv`;
    a.click();
  };

  const recentLands = filtered.parcels.slice(0, 10);
  const recentTransfers = filtered.transfers.slice(0, 10);
  const recentPayments = filtered.payments.slice(0, 10);

  return (
    <>
      {/* Welcome */}
      <div className="rounded-2xl border border-border bg-gradient-to-br from-primary/10 via-card to-card p-5 shadow-sm sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl font-bold sm:text-3xl">
              Welcome back, {user?.fullName || user?.firstName || user?.email?.split("@")[0] || "Officer"}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {now.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
              <span className="rounded-full bg-primary/10 px-2.5 py-1 font-medium text-primary">{roleLabel(role)}</span>
              {hierarchyPath && (
                <span className="rounded-full bg-secondary px-2.5 py-1 font-medium text-secondary-foreground">{hierarchyPath}</span>
              )}
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={exportStats} className="min-h-11 sm:min-h-0">
            <Download className="mr-1.5 h-4 w-4" /> Export stats
          </Button>
        </div>
      </div>

      {/* Quick actions */}
      <SectionCard title="Quick actions" description="Jump straight into the most common tasks">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <QuickAction to="/app/parcels" icon={Plus} title="Register new land" desc="Start a new land registration record" />
          <QuickAction to="/app/search" icon={Search} title="Search land" desc="Find parcels across the hierarchy" />
          <QuickAction to="/verify-land" icon={CheckCircle2} title="Verify land" desc="Open the public verification portal" />
          <QuickAction to="/app/reports" icon={BarChart3} title="View reports" desc="Analytics, revenue and trends" />
          {isAdmin && <QuickAction to="/app/verification-codes" icon={KeyRound} title="Verification codes" desc="Generate and manage access codes" />}
          {isAdmin && <QuickAction to="/app/admin" icon={Users} title="Manage users" desc="Accounts, roles and hierarchy" />}
        </div>
      </SectionCard>

      {/* Quick filters */}
      <div className="rounded-2xl border border-border bg-card p-4 shadow-sm">
        <div className="mb-3 flex items-center justify-between gap-3">
          <p className="flex items-center gap-2 text-sm font-semibold">
            <Filter className="h-4 w-4 text-primary" /> Quick filters
            {activeFilters > 0 && (
              <span className="rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold text-primary-foreground">{activeFilters}</span>
            )}
          </p>
          {activeFilters > 0 && (
            <Button size="sm" variant="ghost" onClick={clearFilters}>
              <RotateCcw className="mr-1 h-3.5 w-3.5" /> Clear
            </Button>
          )}
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-1.5">
            <Label className="text-xs">Office</Label>
            <Select value={fOffice} onValueChange={(v) => { setFOffice(v); setFAC("all"); setFComm("all"); setFSect("all"); }}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All offices</SelectItem>
                {offices.map((o) => <SelectItem key={o.id} value={o.name}>{o.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Area council</Label>
            <Select value={fAC} onValueChange={(v) => { setFAC(v); setFComm("all"); setFSect("all"); }}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All area councils</SelectItem>
                {(fOffice !== "all" ? acForOffice(fOffice) : areaCouncils).map((a) => (
                  <SelectItem key={a.id} value={a.name}>{a.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Community</Label>
            <Select value={fComm} onValueChange={(v) => { setFComm(v); setFSect("all"); }}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All communities</SelectItem>
                {(fAC !== "all" ? commForAC(fAC) : communities).map((c) => (
                  <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Sector</Label>
            <Select value={fSect} onValueChange={setFSect}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All sectors</SelectItem>
                {(fComm !== "all" ? sectForComm(fComm) : sectors).map((s) => (
                  <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Status</Label>
            <Select value={fStatus} onValueChange={setFStatus}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                {["draft", "submitted", "under_survey", "under_review", "registered", "disputed", "rejected"].map((s) => (
                  <SelectItem key={s} value={s}>{titleCase(s)}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">From</Label>
            <Input type="date" value={fFrom} onChange={(e) => setFFrom(e.target.value)} className="h-9" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">To</Label>
            <Input type="date" value={fTo} onChange={(e) => setFTo(e.target.value)} className="h-9" />
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard label="Total lands" value={filtered.parcels.length} icon={MapPinned} hint="all time" />
        <KpiCard label="Lands this month" value={landsMonth} icon={MapPinned} trend={pct(landsMonth, landsPrevMonth)} hint="vs last month" accent="emerald" />
        <KpiCard label="Lands this year" value={landsYear} icon={MapPinned} trend={pct(landsYear, landsPrevYear)} hint="vs last year" accent="blue" />
        <KpiCard label="In my hierarchy" value={myScope} icon={ClipboardList} hint={hierarchyPath || "district-wide"} accent="gold" />
        <KpiCard label="Pending approvals" value={pendingApprovals} icon={ClipboardList} accent="gold" />
        <KpiCard label="Completed transfers" value={completedTransfers} icon={ArrowRightLeft} accent="blue" />
        <KpiCard label="Revenue this month" value={ghs(revMonth)} icon={Wallet} trend={pct(revMonth, revPrevMonth)} hint="vs last month" accent="emerald" />
        <KpiCard label="Revenue this year" value={ghs(revYear)} icon={Wallet} trend={pct(revYear, revPrevYear)} hint={`all time ${ghs(sum(paid))}`} accent="gold" />
      </div>

      {/* Charts */}
      <div className="grid gap-6 lg:grid-cols-2">
        <SectionCard title="Land registration trend" description="Last 12 months">
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={regTrend}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip />
                <Line type="monotone" dataKey="value" name="Registrations" stroke="#166b4a" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
        <SectionCard title="Revenue trend" description="Last 12 months">
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revTrend}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip formatter={(v) => ghs(v)} />
                <Area type="monotone" dataKey="value" name="Revenue" stroke="#e0a422" fill="#e0a42233" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
        <SectionCard title="Lands by community" description="Click a slice to filter the dashboard">
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={byCommunity} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}
                  onClick={(e) => e?.name && setFComm(e.name)}
                >
                  {byCommunity.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} cursor="pointer" />)}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
        <SectionCard title="Lands by office" description="Distribution across district offices">
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byOffice} onClick={(e) => e?.activeLabel && setFOffice(e.activeLabel)}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="value" name="Lands" fill="#2563eb" radius={[6, 6, 0, 0]} cursor="pointer" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
        <SectionCard title="Lands by status">
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={byStatus} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}>
                  {byStatus.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
        <SectionCard title="Approval requests by status">
          <div className="h-60">
            {approvalsByStatus.length === 0 ? (
              <p className="py-16 text-center text-sm text-muted-foreground">No approval requests yet.</p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={approvalsByStatus} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}>
                    {approvalsByStatus.map((_, i) => <Cell key={i} fill={COLORS[(i + 2) % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </SectionCard>
      </div>

      {/* Recent activity */}
      <div className="grid gap-6 lg:grid-cols-2">
        <SectionCard
          title="Recent land registrations"
          action={<Link to="/app/parcels" className="text-xs font-medium text-primary hover:underline">View all</Link>}
        >
          {recentLands.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">No registrations yet.</p>
          ) : (
            <ul className="divide-y divide-border text-sm">
              {recentLands.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 py-2.5">
                  <Link to="/app/parcels" className="min-w-0 hover:underline">
                    <p className="truncate font-medium">{p.applicantName || p.parcelNumber}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      Plot {p.plotNumber || "—"}{p.block ? ` / ${p.block}` : ""} · {p.community || "—"} · {timeAgo(p.created)}
                    </p>
                  </Link>
                  <StatusBadge status={p.status} />
                </li>
              ))}
            </ul>
          )}
        </SectionCard>

        <SectionCard
          title="Recent payments"
          action={<Link to="/app/payments" className="text-xs font-medium text-primary hover:underline">View all</Link>}
        >
          {recentPayments.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">No payments recorded.</p>
          ) : (
            <ul className="divide-y divide-border text-sm">
              {recentPayments.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate font-medium">{p.ownerName || p.invoiceNumber || "Payment"}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {titleCase(p.purpose || "fee")} · {titleCase(p.method || "—")} · {formatDate(p.created)}
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="font-semibold">{ghs(p.amount || 0)}</p>
                    <StatusBadge status={p.status} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </SectionCard>

        <SectionCard title="Recent transfers" className="lg:col-span-2">
          {recentTransfers.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">No land transfers recorded.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border text-left text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="py-2 pr-4 font-medium">New owner</th>
                    <th className="hidden py-2 pr-4 font-medium sm:table-cell">Certificate</th>
                    <th className="hidden py-2 pr-4 font-medium sm:table-cell">Date</th>
                    <th className="py-2 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {recentTransfers.map((t) => (
                    <tr key={t.id} className="hover:bg-muted/20">
                      <td className="py-2 pr-4 font-medium">{t.toOwnerName || "—"}</td>
                      <td className="hidden py-2 pr-4 font-mono text-xs text-muted-foreground sm:table-cell">{t.certificateNumber || "—"}</td>
                      <td className="hidden py-2 pr-4 text-muted-foreground sm:table-cell">{formatDate(t.created)}</td>
                      <td className="py-2"><StatusBadge status={t.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </SectionCard>
      </div>
    </>
  );
}
