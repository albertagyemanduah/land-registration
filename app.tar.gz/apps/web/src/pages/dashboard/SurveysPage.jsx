import React, { useState } from "react";
import { Compass, Plus, MapPin, Download, CheckCircle2, AlertTriangle, Calendar, User, BarChart3, ClipboardCheck, Pencil, Trash2 } from "lucide-react";
import pb from "@/lib/pocketbaseClient";
import { useAuth } from "@/lib/auth";
import { useCollection } from "@/lib/useCollection";
import { PageHeader, StatusBadge, Spinner, EmptyState, StatCard } from "@/components/shared";
import { titleCase, formatDate, genRef } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const STATUSES = ["scheduled", "in_progress", "completed", "verified"];

function CadastralMapViewer({ survey }) {
  const beaconList = (survey.beacons || "").split(";").map((b) => b.trim()).filter(Boolean);
  const coords = survey.parcel?.coordinates || {};
  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border bg-muted/30 p-4">
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-sm font-semibold">Cadastral Map View</h4>
          <span className="text-xs text-muted-foreground">Techiman North District</span>
        </div>
        {/* Simulated SVG map */}
        <div className="relative h-48 rounded-lg bg-emerald-50 border border-emerald-200 overflow-hidden flex items-center justify-center">
          <svg width="100%" height="100%" viewBox="0 0 400 200" className="absolute inset-0">
            <rect x="0" y="0" width="400" height="200" fill="#f0fdf4" />
            {/* Grid */}
            {[50, 100, 150, 200, 250, 300, 350].map((x) => (
              <line key={`vx${x}`} x1={x} y1="0" x2={x} y2="200" stroke="#bbf7d0" strokeWidth="0.5" />
            ))}
            {[40, 80, 120, 160].map((y) => (
              <line key={`hy${y}`} x1="0" y1={y} x2="400" y2={y} stroke="#bbf7d0" strokeWidth="0.5" />
            ))}
            {/* Parcel polygon */}
            <polygon points="120,40 280,40 300,160 100,160" fill="#166b4a33" stroke="#166b4a" strokeWidth="2" />
            {/* Beacons */}
            {[[120,40],[280,40],[300,160],[100,160]].map(([x,y], i) => (
              <g key={i}>
                <circle cx={x} cy={y} r="6" fill="#e0a422" stroke="white" strokeWidth="2" />
                <text x={x+8} y={y-6} fontSize="10" fill="#92400e">B{i+1}</text>
              </g>
            ))}
            <text x="190" y="108" fontSize="11" fill="#166b4a" textAnchor="middle" fontWeight="600">
              {survey.expand?.parcel?.parcelNumber || "PARCEL"}
            </text>
          </svg>
        </div>
        <div className="mt-2 flex gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><span className="h-2.5 w-2.5 rounded-full bg-amber-500 inline-block" /> Beacon</span>
          <span className="flex items-center gap-1"><span className="h-2.5 w-2.5 rounded bg-primary/30 border border-primary inline-block" /> Parcel boundary</span>
        </div>
      </div>

      {beaconList.length > 0 && (
        <div>
          <h4 className="text-sm font-semibold mb-2">Beacon Coordinates</h4>
          <div className="space-y-1.5">
            {beaconList.map((b, i) => (
              <div key={i} className="flex items-center gap-2 rounded-lg bg-muted/40 px-3 py-2 text-sm">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white text-xs font-bold">B{i+1}</span>
                <span className="font-mono text-xs">{b}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {survey.computedArea > 0 && (
        <div className="rounded-lg bg-primary/5 p-3 text-sm">
          <span className="text-muted-foreground">Computed area: </span>
          <span className="font-semibold text-primary">{survey.computedArea} acres</span>
        </div>
      )}
    </div>
  );
}

function SurveyReportModal({ survey }) {
  const download = () => {
    const lines = [
      `SURVEY REPORT — Techiman North District Assembly`,
      ``,
      `Parcel: ${survey.expand?.parcel?.parcelNumber || "—"}`,
      `Title: ${survey.expand?.parcel?.title || "—"}`,
      `Surveyor: ${survey.expand?.surveyor?.fullName || "—"}`,
      `Date: ${formatDate(survey.surveyDate)}`,
      `Status: ${titleCase(survey.status)}`,
      `Computed Area: ${survey.computedArea || "—"} acres`,
      ``,
      `BEACONS:`,
      survey.beacons || "Not recorded",
      ``,
      `NOTES:`,
      survey.notes || "None",
      ``,
      `Generated: ${new Date().toLocaleString()}`,
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `survey-report-${survey.id}.txt`; a.click();
    URL.revokeObjectURL(url);
  };
  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border p-4 space-y-3 text-sm">
        {[
          ["Parcel", survey.expand?.parcel?.parcelNumber || "—"],
          ["Title", survey.expand?.parcel?.title || "—"],
          ["Surveyor", survey.expand?.surveyor?.fullName || "—"],
          ["Survey Date", formatDate(survey.surveyDate)],
          ["Computed Area", survey.computedArea ? `${survey.computedArea} acres` : "—"],
          ["Status", titleCase(survey.status)],
        ].map(([k, v]) => (
          <div key={k} className="flex justify-between border-b border-border pb-2">
            <span className="text-muted-foreground">{k}</span>
            <span className="font-medium">{v}</span>
          </div>
        ))}
      </div>
      {survey.beacons && (
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Beacon Data</p>
          <p className="text-sm font-mono bg-muted/40 rounded p-2">{survey.beacons}</p>
        </div>
      )}
      {survey.notes && (
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Field Notes</p>
          <p className="text-sm">{survey.notes}</p>
        </div>
      )}
      <Button onClick={download} className="w-full"><Download className="mr-2 h-4 w-4" /> Download Survey Report</Button>
    </div>
  );
}

export default function SurveysPage() {
  const { user, role, log } = useAuth();
  const { toast } = useToast();
  const { records, loading, reload } = useCollection("surveys", { expand: "parcel,surveyor" });
  const { records: parcels } = useCollection("parcels", {});
  const { records: allUsers } = useCollection("users", { filter: "role = 'survey_officer'" });

  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editSurvey, setEditSurvey] = useState(null);
  const [deleteSurvey, setDeleteSurvey] = useState(null);
  const [mapSurvey, setMapSurvey] = useState(null);
  const [reportSurvey, setReportSurvey] = useState(null);
  const [disputeSurvey, setDisputeSurvey] = useState(null);
  const [disputeNotes, setDisputeNotes] = useState("");
  const [tabStatus, setTabStatus] = useState("all");
  const [form, setForm] = useState({
    parcel: "none", surveyor: "none", surveyDate: "", computedArea: "", beacons: "", notes: "", status: "scheduled",
  });
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e?.target ? e.target.value : e }));

  const filtered = tabStatus === "all" ? records : records.filter((s) => s.status === tabStatus);

  const stats = {
    scheduled: records.filter((s) => s.status === "scheduled").length,
    in_progress: records.filter((s) => s.status === "in_progress").length,
    completed: records.filter((s) => s.status === "completed").length,
    verified: records.filter((s) => s.status === "verified").length,
  };

  const submit = async () => {
    setSaving(true);
    try {
      await pb.collection("surveys").create({
        parcel: form.parcel !== "none" ? form.parcel : null,
        surveyor: form.surveyor !== "none" ? form.surveyor : user.id,
        surveyDate: form.surveyDate || null,
        computedArea: form.computedArea ? Number(form.computedArea) : 0,
        beacons: form.beacons,
        notes: form.notes,
        status: form.status,
        boundaries: {},
      });
      if (form.parcel !== "none") {
        try { await pb.collection("parcels").update(form.parcel, { status: "under_survey" }); } catch (_) {}
      }
      await log("survey_created", "surveys", `Survey scheduled (${titleCase(form.status)})`);
      toast({ title: "Survey record saved" });
      setOpen(false);
      setForm({ parcel: "none", surveyor: "none", surveyDate: "", computedArea: "", beacons: "", notes: "", status: "scheduled" });
      reload();
    } catch (err) {
      toast({ variant: "destructive", title: "Could not save", description: err?.message });
    } finally {
      setSaving(false);
    }
  };

  const setStatus = async (id, status) => {
    await pb.collection("surveys").update(id, { status });
    await log("survey_status_update", "surveys", titleCase(status));
    reload();
    toast({ title: "Survey updated", description: `Status: ${titleCase(status)}` });
  };

  const saveEditSurvey = async () => {
    if (!editSurvey) return;
    setSaving(true);
    try {
      await pb.collection("surveys").update(editSurvey.id, {
        surveyDate: editSurvey.surveyDate || null,
        computedArea: editSurvey.computedArea ? Number(editSurvey.computedArea) : 0,
        beacons: editSurvey.beacons || "",
        notes: editSurvey.notes || "",
        status: editSurvey.status,
      });
      await log("survey_updated", "surveys", `Updated survey ${editSurvey.id}`);
      toast({ title: "Survey updated" });
      setEditSurvey(null);
      reload();
    } catch (err) {
      toast({ variant: "destructive", title: "Update failed", description: err?.message });
    } finally {
      setSaving(false);
    }
  };

  const doDeleteSurvey = async () => {
    if (!deleteSurvey) return;
    try {
      await pb.collection("surveys").delete(deleteSurvey.id);
      await log("survey_deleted", "surveys", `Deleted survey ${deleteSurvey.id}`);
      toast({ title: "Survey deleted" });
      setDeleteSurvey(null);
      reload();
    } catch (err) {
      toast({ variant: "destructive", title: "Delete failed", description: err?.message });
    }
  };

  const submitDispute = async () => {
    if (!disputeSurvey) return;
    const notes = (disputeSurvey.notes || "") + `\n\n[BOUNDARY DISPUTE — ${new Date().toLocaleDateString()}]: ${disputeNotes}`;
    await pb.collection("surveys").update(disputeSurvey.id, { notes });
    await log("boundary_dispute", "surveys", `Dispute on ${disputeSurvey.expand?.parcel?.parcelNumber || disputeSurvey.id}`);
    toast({ title: "Dispute recorded", description: "Dispute note appended to survey record." });
    setDisputeSurvey(null);
    setDisputeNotes("");
    reload();
  };

  const validateGps = (beacons) => {
    if (!beacons) return { valid: false, msg: "No beacon data" };
    const parts = beacons.split(";").map((b) => b.trim()).filter(Boolean);
    if (parts.length < 3) return { valid: false, msg: `Only ${parts.length} beacon(s) — minimum 3 required` };
    return { valid: true, msg: `${parts.length} valid beacons detected` };
  };

  return (
    <>
      <PageHeader
        title="Cadastral & Survey"
        subtitle="Manage surveys, boundaries, beacons and spatial data"
        icon={Compass}
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="mr-1 h-4 w-4" /> New survey</Button></DialogTrigger>
            <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
              <DialogHeader><DialogTitle>Record a cadastral survey</DialogTitle></DialogHeader>
              <div className="space-y-4 py-2">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Parcel</Label>
                    <Select value={form.parcel} onValueChange={set("parcel")}>
                      <SelectTrigger><SelectValue placeholder="Select parcel" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Unassigned</SelectItem>
                        {parcels.map((p) => <SelectItem key={p.id} value={p.id}>{p.parcelNumber} — {p.title}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Assign Surveyor</Label>
                    <Select value={form.surveyor} onValueChange={set("surveyor")}>
                      <SelectTrigger><SelectValue placeholder="Assign to…" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Self</SelectItem>
                        {allUsers.map((u) => <SelectItem key={u.id} value={u.id}>{u.fullName || u.email}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Survey date</Label>
                    <Input type="date" value={form.surveyDate} onChange={set("surveyDate")} />
                  </div>
                  <div className="space-y-2">
                    <Label>Computed area (acres)</Label>
                    <Input type="number" value={form.computedArea} onChange={set("computedArea")} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Beacon coordinates</Label>
                  <Textarea value={form.beacons} onChange={set("beacons")} rows={3}
                    placeholder="B1: 7.591, -1.902; B2: 7.592, -1.901; B3: 7.593, -1.903" />
                  {form.beacons && (() => {
                    const v = validateGps(form.beacons);
                    return <p className={cn("text-xs", v.valid ? "text-emerald-600" : "text-orange-600")}>{v.valid ? "✓" : "⚠"} {v.msg}</p>;
                  })()}
                </div>
                <div className="space-y-2">
                  <Label>Status</Label>
                  <Select value={form.status} onValueChange={set("status")}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{titleCase(s)}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Field notes</Label>
                  <Textarea value={form.notes} onChange={set("notes")} rows={2} placeholder="Observations, adjacent owners, access routes…" />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button onClick={submit} disabled={saving}>{saving ? "Saving…" : "Save survey"}</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid gap-4 sm:grid-cols-4">
        <StatCard label="Scheduled" value={stats.scheduled} icon={Calendar} accent="blue" />
        <StatCard label="In progress" value={stats.in_progress} icon={Compass} accent="primary" />
        <StatCard label="Completed" value={stats.completed} icon={CheckCircle2} accent="gold" />
        <StatCard label="Verified" value={stats.verified} icon={ClipboardCheck} accent="emerald" />
      </div>

      {/* Status tabs */}
      <div className="flex gap-1 border-b border-border overflow-x-auto">
        {[["all", "All"], ...STATUSES.map((s) => [s, titleCase(s)])].map(([v, l]) => (
          <button key={v} onClick={() => setTabStatus(v)}
            className={cn("shrink-0 -mb-px border-b-2 px-4 py-2.5 text-sm font-medium transition",
              tabStatus === v ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground")}>
            {l}
          </button>
        ))}
      </div>

      {loading ? <Spinner /> : filtered.length === 0 ? (
        <EmptyState icon={Compass} title="No surveys" message="Schedule and record cadastral surveys for registered parcels." />
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {filtered.map((s) => {
            const gpsResult = validateGps(s.beacons);
            return (
              <div key={s.id} className="rounded-2xl border border-border bg-card p-5 shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-display text-base font-semibold">
                      {s.expand?.parcel?.parcelNumber || "Unassigned parcel"}
                    </h3>
                    <p className="text-sm text-muted-foreground">{s.expand?.parcel?.title || "—"}</p>
                  </div>
                  <StatusBadge status={s.status} />
                </div>
                <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1.5 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> {formatDate(s.surveyDate)}</span>
                  {s.computedArea ? <span>{s.computedArea} acres</span> : null}
                  <span className="flex items-center gap-1"><User className="h-3.5 w-3.5" /> {s.expand?.surveyor?.fullName || "Unassigned"}</span>
                </div>
                {s.beacons && (
                  <p className={cn("mt-2 flex items-start gap-1 text-xs", gpsResult.valid ? "text-emerald-600" : "text-orange-600")}>
                    <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    {gpsResult.valid ? `${gpsResult.msg}` : `GPS validation: ${gpsResult.msg}`}
                  </p>
                )}
                <div className="mt-3 flex flex-wrap gap-2 border-t border-border pt-3">
                  <Button size="sm" variant="outline" onClick={() => setMapSurvey(s)}>
                    <Compass className="mr-1 h-3.5 w-3.5" /> Map view
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setReportSurvey(s)}>
                    <Download className="mr-1 h-3.5 w-3.5" /> Report
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setEditSurvey({
                    ...s,
                    surveyDate: s.surveyDate?.split(" ")[0] || "",
                    computedArea: String(s.computedArea || ""),
                  })}>
                    <Pencil className="mr-1 h-3.5 w-3.5" /> Edit
                  </Button>
                  <Button size="sm" variant="outline" className="text-orange-600 border-orange-200" onClick={() => { setDisputeSurvey(s); setDisputeNotes(""); }}>
                    <AlertTriangle className="mr-1 h-3.5 w-3.5" /> Dispute
                  </Button>
                  {s.status !== "in_progress" && s.status !== "completed" && s.status !== "verified" && (
                    <Button size="sm" variant="outline" onClick={() => setStatus(s.id, "in_progress")}>Start survey</Button>
                  )}
                  {s.status === "in_progress" && (
                    <Button size="sm" variant="outline" onClick={() => setStatus(s.id, "completed")}>Mark completed</Button>
                  )}
                  {s.status === "completed" && (
                    <Button size="sm" onClick={() => setStatus(s.id, "verified")}>
                      <CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Verify
                    </Button>
                  )}
                  {(role === "admin" || role === "survey_officer") && (
                    <Button size="sm" variant="outline" className="text-destructive border-red-200 hover:bg-red-50" onClick={() => setDeleteSurvey(s)}>
                      <Trash2 className="mr-1 h-3.5 w-3.5" /> Delete
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Cadastral Map Modal */}
      <Dialog open={!!mapSurvey} onOpenChange={() => setMapSurvey(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>Cadastral Map — {mapSurvey?.expand?.parcel?.parcelNumber}</DialogTitle></DialogHeader>
          {mapSurvey && <CadastralMapViewer survey={mapSurvey} />}
        </DialogContent>
      </Dialog>

      {/* Survey Report Modal */}
      <Dialog open={!!reportSurvey} onOpenChange={() => setReportSurvey(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>Survey Report</DialogTitle></DialogHeader>
          {reportSurvey && <SurveyReportModal survey={reportSurvey} />}
        </DialogContent>
      </Dialog>

      {/* Edit Survey Modal */}
      <Dialog open={!!editSurvey} onOpenChange={(o) => { if (!o) setEditSurvey(null); }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>Edit Survey</DialogTitle></DialogHeader>
          {editSurvey && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Survey Date</Label><Input type="date" value={editSurvey.surveyDate || ""} onChange={(e) => setEditSurvey((s) => ({ ...s, surveyDate: e.target.value }))} /></div>
                <div className="space-y-2"><Label>Area (acres)</Label><Input type="number" value={editSurvey.computedArea || ""} onChange={(e) => setEditSurvey((s) => ({ ...s, computedArea: e.target.value }))} /></div>
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={editSurvey.status} onValueChange={(v) => setEditSurvey((s) => ({ ...s, status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{["scheduled","in_progress","completed","verified"].map((v) => <SelectItem key={v} value={v}>{titleCase(v)}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2"><Label>Beacons</Label><Textarea value={editSurvey.beacons || ""} onChange={(e) => setEditSurvey((s) => ({ ...s, beacons: e.target.value }))} rows={2} /></div>
              <div className="space-y-2"><Label>Notes</Label><Textarea value={editSurvey.notes || ""} onChange={(e) => setEditSurvey((s) => ({ ...s, notes: e.target.value }))} rows={2} /></div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditSurvey(null)}>Cancel</Button>
                <Button onClick={saveEditSurvey} disabled={saving}>{saving ? "Saving…" : "Save Changes"}</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Survey Confirm */}
      <Dialog open={!!deleteSurvey} onOpenChange={() => setDeleteSurvey(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader><DialogTitle>Delete Survey</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground py-2">Permanently delete this survey record for <strong>{deleteSurvey?.expand?.parcel?.parcelNumber || "unassigned parcel"}</strong>? This cannot be undone.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteSurvey(null)}>Cancel</Button>
            <Button variant="destructive" onClick={doDeleteSurvey}><Trash2 className="mr-1 h-4 w-4" /> Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Boundary Dispute Modal */}
      <Dialog open={!!disputeSurvey} onOpenChange={() => setDisputeSurvey(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle>Record Boundary Dispute</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <p className="text-sm text-muted-foreground">
              Record a boundary dispute for parcel <strong>{disputeSurvey?.expand?.parcel?.parcelNumber}</strong>.
              This will be logged and attached to the survey record.
            </p>
            <div className="space-y-2">
              <Label>Dispute description</Label>
              <Textarea value={disputeNotes} onChange={(e) => setDisputeNotes(e.target.value)} rows={4}
                placeholder="Describe the boundary dispute, conflicting parties, extent of disagreement…" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDisputeSurvey(null)}>Cancel</Button>
            <Button variant="destructive" onClick={submitDispute} disabled={!disputeNotes.trim()}>
              <AlertTriangle className="mr-1 h-4 w-4" /> Record dispute
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
