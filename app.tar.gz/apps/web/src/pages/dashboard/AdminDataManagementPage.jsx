import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Helmet } from "react-helmet";
import { Database, Trash2, RefreshCw, AlertTriangle, ScrollText, Bell, Clock } from "lucide-react";
import pb from "@/lib/pocketbaseClient";
import { useAuth } from "@/lib/auth";
import { PageHeader, SectionCard, StatCard, Spinner } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { formatDate, timeAgo } from "@/lib/format";
import { cn } from "@/lib/utils";

const EMPTY_FILTERS = { from: "", to: "", action: "all", entity: "all", user: "all", status: "all" };

function buildFilter(parts) {
  return parts.filter(Boolean).join(" && ");
}

function Panel({
  title, description, icon: Icon, records, loading, filters, setFilters,
  actionOptions, entityOptions, userOptions, statusOptions, matched, onDelete, deleting, children,
}) {
  const set = (k) => (v) => setFilters((f) => ({ ...f, [k]: v }));
  return (
    <SectionCard title={title} description={description}>
      <div className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-1.5">
            <Label className="text-xs">From date</Label>
            <Input type="date" value={filters.from} onChange={(e) => set("from")(e.target.value)} className="h-9" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">To date</Label>
            <Input type="date" value={filters.to} onChange={(e) => set("to")(e.target.value)} className="h-9" />
          </div>
          {actionOptions && (
            <div className="space-y-1.5">
              <Label className="text-xs">Action</Label>
              <Select value={filters.action} onValueChange={set("action")}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-64">
                  <SelectItem value="all">All actions</SelectItem>
                  {actionOptions.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          {entityOptions && (
            <div className="space-y-1.5">
              <Label className="text-xs">Entity type</Label>
              <Select value={filters.entity} onValueChange={set("entity")}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-64">
                  <SelectItem value="all">All entities</SelectItem>
                  {entityOptions.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          {statusOptions && (
            <div className="space-y-1.5">
              <Label className="text-xs">Status</Label>
              <Select value={filters.status} onValueChange={set("status")}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  {statusOptions.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          {userOptions && (
            <div className="space-y-1.5">
              <Label className="text-xs">User</Label>
              <Select value={filters.user} onValueChange={set("user")}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-64">
                  <SelectItem value="all">All users</SelectItem>
                  {userOptions.map((u) => <SelectItem key={u.id} value={u.id}>{u.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3 rounded-xl border border-border bg-muted/30 px-4 py-3">
          <Icon className="h-4 w-4 text-primary" />
          <p className="text-sm">
            <strong>{matched.length}</strong> of {records.length} record(s) match the filters.
          </p>
          <Button variant="ghost" size="sm" onClick={() => setFilters({ ...EMPTY_FILTERS })}>Reset filters</Button>
          <Button
            variant="destructive" size="sm" className="ml-auto"
            disabled={deleting || matched.length === 0}
            onClick={onDelete}
          >
            {deleting
              ? <><RefreshCw className="mr-1.5 h-4 w-4 animate-spin" /> Deleting…</>
              : <><Trash2 className="mr-1.5 h-4 w-4" /> Delete {matched.length} record(s)</>}
          </Button>
        </div>

        {loading ? <Spinner /> : children}
      </div>
    </SectionCard>
  );
}

export default function AdminDataManagementPage() {
  const { user, role, log } = useAuth();
  const { toast } = useToast();
  const isAdmin = role === "admin";

  const [logs, setLogs] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(null); // "audit" | "notifications" | "recent"
  const [progress, setProgress] = useState(null);
  const [confirm, setConfirm] = useState(null); // { kind, records, label }

  const [auditFilters, setAuditFilters] = useState({ ...EMPTY_FILTERS });
  const [notifFilters, setNotifFilters] = useState({ ...EMPTY_FILTERS });
  const [recentFilters, setRecentFilters] = useState({ ...EMPTY_FILTERS });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [l, n, u] = await Promise.all([
        pb.collection("audit_logs").getFullList({ sort: "-created", requestKey: "adm-logs" }).catch(() => []),
        pb.collection("notifications").getFullList({ sort: "-created", requestKey: "adm-notifs" }).catch(() => []),
        pb.collection("users").getFullList({ sort: "email", requestKey: "adm-users" }).catch(() => []),
      ]);
      setLogs(l); setNotifications(n); setUsers(u);
    } catch (err) {
      console.error("Data management load failed", err);
      toast({ variant: "destructive", title: "Could not load data", description: err?.message });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => { if (isAdmin) load(); else setLoading(false); }, [isAdmin, load]);

  const userOptions = useMemo(
    () => users.map((u) => ({ id: u.id, label: u.fullName || u.email || u.id })),
    [users],
  );

  const inRange = (rec, f) => {
    const d = new Date(rec.created);
    if (f.from && d < new Date(f.from)) return false;
    if (f.to && d > new Date(`${f.to}T23:59:59`)) return false;
    return true;
  };

  const matchedAudit = useMemo(() => logs.filter((r) =>
    inRange(r, auditFilters)
    && (auditFilters.action === "all" || r.action === auditFilters.action)
    && (auditFilters.entity === "all" || r.entity === auditFilters.entity)
    && (auditFilters.user === "all" || r.actor === auditFilters.user)
  ), [logs, auditFilters]);

  const notifMatch = (list, f) => list.filter((r) =>
    inRange(r, f)
    && (f.user === "all" || r.user === f.user)
    && (f.status === "all" || (f.status === "read" ? !!r.read : !r.read))
  );

  const matchedNotifs = useMemo(() => notifMatch(notifications, notifFilters), [notifications, notifFilters]);

  const recentPool = useMemo(() => {
    const cutoff = Date.now() - 7 * 86400000;
    return notifications.filter((n) => new Date(n.created).getTime() >= cutoff);
  }, [notifications]);
  const matchedRecent = useMemo(() => notifMatch(recentPool, recentFilters), [recentPool, recentFilters]);

  const actionOptions = useMemo(() => [...new Set(logs.map((l) => l.action).filter(Boolean))].sort(), [logs]);
  const entityOptions = useMemo(() => [...new Set(logs.map((l) => l.entity).filter(Boolean))].sort(), [logs]);

  const runDelete = async () => {
    if (!confirm) return;
    const { kind, records, collection, label } = confirm;
    setConfirm(null);
    setDeleting(kind);
    let done = 0, failed = 0;
    setProgress({ done: 0, total: records.length });
    for (let i = 0; i < records.length; i++) {
      try {
        await pb.collection(collection).delete(records[i].id, { requestKey: `del-${kind}-${i}` });
        done++;
      } catch (err) {
        failed++;
        console.error(`Delete failed for ${collection}/${records[i].id}`, err);
      }
      setProgress({ done: i + 1, total: records.length });
    }
    try {
      await log("bulk_data_purge", collection, `${label}: ${done} deleted, ${failed} failed (by ${user?.email})`);
    } catch (_) {}
    toast({
      variant: failed && !done ? "destructive" : "default",
      title: failed && !done ? "Deletion failed" : `${label} complete`,
      description: `${done} record(s) deleted${failed ? `, ${failed} failed` : ""}.`,
    });
    setDeleting(null);
    setProgress(null);
    await load();
  };

  if (!isAdmin) {
    return (
      <>
        <PageHeader title="Data Management" subtitle="Restricted area" icon={Database} />
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-6 text-sm text-destructive">
          Only the District Assembly Administrator can access data management.
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Data Management — Techiman North Land Registry</title>
        <meta name="description" content="Administrator tools to purge audit trail entries and notifications in the Techiman North Land Registry." />
      </Helmet>

      <PageHeader
        title="Data Management"
        subtitle="Purge audit trail entries and notifications"
        icon={Database}
        action={<Button variant="outline" size="sm" onClick={load} disabled={loading}><RefreshCw className={cn("mr-1 h-4 w-4", loading && "animate-spin")} /> Refresh</Button>}
      />

      <div className="rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-800 dark:bg-amber-900/20 dark:text-amber-300">
        <AlertTriangle className="mr-1.5 inline h-4 w-4" />
        Deletions on this page are permanent and cannot be undone. Every purge is itself recorded in the audit trail.
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Audit entries" value={logs.length} icon={ScrollText} accent="primary" />
        <StatCard label="Notifications" value={notifications.length} icon={Bell} accent="gold" />
        <StatCard label="Recent (7 days)" value={recentPool.length} icon={Clock} accent="blue" />
      </div>

      {progress && (
        <div className="space-y-1.5 rounded-xl border border-primary/20 bg-primary/5 p-4">
          <div className="flex items-center justify-between text-xs font-medium text-primary">
            <span>Deleting records…</span>
            <span>{progress.done}/{progress.total}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-border">
            <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${(progress.done / Math.max(1, progress.total)) * 100}%` }} />
          </div>
        </div>
      )}

      <Panel
        title="Delete audit trail" description="Remove audit records matching the filters below"
        icon={ScrollText} records={logs} loading={loading}
        filters={auditFilters} setFilters={setAuditFilters}
        actionOptions={actionOptions} entityOptions={entityOptions} userOptions={userOptions}
        matched={matchedAudit} deleting={deleting === "audit"}
        onDelete={() => setConfirm({ kind: "audit", collection: "audit_logs", records: matchedAudit, label: "Audit trail purge" })}
      >
        <ul className="max-h-56 divide-y divide-border overflow-y-auto text-sm">
          {matchedAudit.slice(0, 25).map((l) => (
            <li key={l.id} className="flex items-start justify-between gap-3 py-2">
              <div className="min-w-0">
                <p className="truncate font-medium">{l.action}</p>
                <p className="truncate text-xs text-muted-foreground">{l.entity || "—"} · {l.details || "—"}</p>
              </div>
              <span className="shrink-0 text-xs text-muted-foreground">{timeAgo(l.created)}</span>
            </li>
          ))}
          {matchedAudit.length === 0 && <li className="py-4 text-center text-sm text-muted-foreground">No matching audit records.</li>}
        </ul>
      </Panel>

      <Panel
        title="Delete notifications" description="Remove notification records matching the filters below"
        icon={Bell} records={notifications} loading={loading}
        filters={notifFilters} setFilters={setNotifFilters}
        userOptions={userOptions}
        statusOptions={[{ value: "read", label: "Read" }, { value: "unread", label: "Unread" }]}
        matched={matchedNotifs} deleting={deleting === "notifications"}
        onDelete={() => setConfirm({ kind: "notifications", collection: "notifications", records: matchedNotifs, label: "Notifications purge" })}
      >
        <ul className="max-h-56 divide-y divide-border overflow-y-auto text-sm">
          {matchedNotifs.slice(0, 25).map((n) => (
            <li key={n.id} className="flex items-start justify-between gap-3 py-2">
              <p className="min-w-0 truncate">{n.message}</p>
              <span className="shrink-0 text-xs text-muted-foreground">{formatDate(n.created)}</span>
            </li>
          ))}
          {matchedNotifs.length === 0 && <li className="py-4 text-center text-sm text-muted-foreground">No matching notifications.</li>}
        </ul>
      </Panel>

      <Panel
        title="Delete recent notifications" description="Only notifications created in the last 7 days"
        icon={Clock} records={recentPool} loading={loading}
        filters={recentFilters} setFilters={setRecentFilters}
        userOptions={userOptions}
        statusOptions={[{ value: "read", label: "Read" }, { value: "unread", label: "Unread" }]}
        matched={matchedRecent} deleting={deleting === "recent"}
        onDelete={() => setConfirm({ kind: "recent", collection: "notifications", records: matchedRecent, label: "Recent notifications purge" })}
      >
        <ul className="max-h-56 divide-y divide-border overflow-y-auto text-sm">
          {matchedRecent.slice(0, 25).map((n) => (
            <li key={n.id} className="flex items-start justify-between gap-3 py-2">
              <p className="min-w-0 truncate">{n.message}</p>
              <span className="shrink-0 text-xs text-muted-foreground">{timeAgo(n.created)}</span>
            </li>
          ))}
          {matchedRecent.length === 0 && <li className="py-4 text-center text-sm text-muted-foreground">No recent notifications.</li>}
        </ul>
      </Panel>

      <Dialog open={!!confirm} onOpenChange={(o) => { if (!o) setConfirm(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle className="flex items-center gap-2 text-destructive"><Trash2 className="h-4 w-4" /> Confirm permanent deletion</DialogTitle></DialogHeader>
          <div className="space-y-3 py-1 text-sm">
            <div className="rounded-lg border-2 border-red-300 bg-red-50 p-3 text-red-800 dark:bg-red-900/20 dark:text-red-300">
              You are about to permanently delete <strong>{confirm?.records.length}</strong> record(s) from <strong>{confirm?.collection}</strong>. This cannot be undone.
            </div>
            <p className="text-muted-foreground">The purge itself will be written to the audit trail with your account details.</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirm(null)}>Cancel</Button>
            <Button variant="destructive" onClick={runDelete}><Trash2 className="mr-1 h-4 w-4" /> Delete permanently</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
