import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  MapPinned, Compass, FileText, ClipboardList, SearchCheck, Wallet,
  BarChart3, ShieldCheck, ArrowRight, Lock, Fingerprint, ScrollText,
  CheckCircle2, ChevronDown, ChevronUp, Phone, Mail, MapPin,
  Users, Clock, Award, Globe, Star, Building2, FileCheck, AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";
import PublicNav from "@/components/PublicNav";
import PublicFooter from "@/components/PublicFooter";

const HERO = "https://images.hostinger.com/be655138-806c-4137-85f0-2f9e6569c1a8.png";
const SURVEY = "https://images.hostinger.com/1cf01faf-bfa6-4262-bcfa-179cc06f71ff.png";
const CITIZEN = "https://images.hostinger.com/a7dbec65-2e55-4a59-a87e-e8f967f65d44.png";

const SERVICES = [
  { icon: MapPinned, title: "Land Registration", desc: "Register land parcels with full ownership records, parcel numbers, and official certification." },
  { icon: SearchCheck, title: "Title Search & Verification", desc: "Verify ownership, check encumbrances, and obtain official title search certificates instantly." },
  { icon: FileText, title: "Document Management", desc: "Securely store and manage all land documents — deeds, indentures, site plans, and certificates." },
  { icon: ClipboardList, title: "Land Transfer", desc: "Process ownership transfers with full audit trail, approval workflows, and certification." },
  { icon: Compass, title: "Cadastral Survey", desc: "Commission and manage professional land surveys with GPS coordinates and boundary data." },
  { icon: Wallet, title: "Fee Payment", desc: "Pay all land-related fees online via mobile money, card, or bank transfer with instant receipts." },
];

const STEPS = [
  { num: "01", title: "Create an account", desc: "Contact the District Assembly Administrator to create your staff account." },
  { num: "02", title: "Register your land", desc: "Fill in your parcel details — applicant info, location, sector, and dates." },
  { num: "03", title: "Submit documents", desc: "Upload supporting documents including site plans, deeds, and identification." },
  { num: "04", title: "Review & approval", desc: "Your application moves through Planning, Survey, and Registry review stages." },
  { num: "05", title: "Pay registration fees", desc: "Receive an invoice and pay via your preferred payment method." },
  { num: "06", title: "Receive certificate", desc: "Download your official land title certificate once approved and registered." },
];

const STATS = [
  { value: "5", label: "Area Councils served", icon: MapPin },
  { value: "3", label: "District offices", icon: Building2 },
  { value: "7", label: "Role-based portals", icon: Users },
  { value: "24/7", label: "System availability", icon: Clock },
];

const FAQS = [
  {
    q: "Who can use the Techiman North Land Registry System?",
    a: "The system is for authorized district staff including Planning Officers, Surveyors, Land Registrars, Finance Officers, and District Administrators. Staff accounts are created by the District Assembly Administrator.",
  },
  {
    q: "What documents do I need to register land?",
    a: "You typically need a site plan, Ghana Card identification, proof of ownership (deed/indenture), and any relevant customary documentation. The system supports uploading all document types securely.",
  },
  {
    q: "How long does land registration take?",
    a: "The process typically takes 5–14 days depending on the complexity of the application. Applications with complete documentation and no disputes are processed faster.",
  },
  {
    q: "Is my data secure on this platform?",
    a: "Yes. All data is encrypted with AES-256, access is controlled by role-based permissions, all actions are immutably logged in an audit trail, and multi-factor authentication protects every account.",
  },
  {
    q: "What payment methods are accepted?",
    a: "The system accepts Mobile Money (MTN, Vodafone, AirtelTigo), debit/credit cards, bank transfers, and cash payments at the district office.",
  },
  {
    q: "What are the Area Councils covered?",
    a: "The system covers Tuobodom, Offuman, Aworowa, Buoyem, and Krobo Area Councils within the Techiman North District.",
  },
];

const COMPLIANCE = [
  { icon: Fingerprint, title: "Ghana Card verified", body: "Every identity is validated against the National Identification number." },
  { icon: Lock, title: "AES-256 encryption", body: "Data encrypted at rest and in transit end-to-end." },
  { icon: ScrollText, title: "Full audit trails", body: "Every transaction and change immutably logged." },
  { icon: ShieldCheck, title: "MFA & RBAC", body: "Multi-factor sign-in and least-privilege role controls." },
];

function FAQItem({ q, a }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-border last:border-0">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-4 py-5 text-left"
      >
        <span className="font-medium text-foreground">{q}</span>
        {open ? <ChevronUp className="h-4 w-4 shrink-0 text-primary" /> : <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />}
      </button>
      {open && (
        <p className="pb-5 text-sm leading-relaxed text-muted-foreground">{a}</p>
      )}
    </div>
  );
}



export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      <PublicNav />

      {/* Hero */}
      <section className="relative flex min-h-[100dvh] items-center overflow-hidden pt-16">
        <div className="absolute inset-0">
          <img src={HERO} alt="Aerial view of Techiman North District farmland parcels" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/90 to-primary/40" />
        </div>
        <div className="relative mx-auto max-w-[80rem] px-5 py-16">
          <div className="max-w-2xl">
            <motion.span
              initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/15 px-3 py-1 text-xs font-semibold text-accent"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-accent" /> Techiman North District Assembly — Official Portal
            </motion.span>
            <motion.h1
              initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.05 }}
              className="mt-5 font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-white text-balance sm:text-5xl lg:text-6xl"
            >
              Secure Digital Land Administration for Techiman North
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.12 }}
              className="mt-5 max-w-xl text-lg text-primary-foreground/80"
            >
              The official land registration, survey, and title management platform for the Techiman North District Assembly. Serving five area councils with transparent, secure, and efficient land administration.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }}
              className="mt-8 flex flex-wrap gap-3"
            >
              <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                <Link to="/auth">Staff Portal Login <ArrowRight className="ml-1 h-4 w-4" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white/30 bg-white/5 text-white hover:bg-white/15 hover:text-white">
                <a href="#how-it-works">How It Works</a>
              </Button>
            </motion.div>
            <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-primary-foreground/70">
              {["Ghana Card Verified", "AES-256 Encrypted", "Audit Logged", "Act 1036 Compliant"].map((t) => (
                <span key={t} className="inline-flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-accent" /> {t}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Stats Band */}
      <div className="border-y border-border bg-card">
        <div className="mx-auto max-w-[80rem] px-5">
          <div className="grid grid-cols-2 gap-px bg-border lg:grid-cols-4">
            {STATS.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="flex flex-col items-center gap-2 bg-card px-6 py-10 text-center"
              >
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                  <s.icon className="h-5 w-5" strokeWidth={1.8} />
                </span>
                <p className="font-display text-3xl font-extrabold text-primary">{s.value}</p>
                <p className="text-sm text-muted-foreground">{s.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Services */}
      <section id="services" className="mx-auto max-w-[80rem] px-5 py-20">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <p className="text-sm font-semibold uppercase tracking-wider text-accent">Our Services</p>
          <h2 className="mt-2 font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Comprehensive Land Administration Services
          </h2>
          <p className="mt-3 text-muted-foreground">
            Everything you need to manage land ownership, registration, and documentation in one integrated platform.
          </p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.4, delay: (i % 3) * 0.06 }}
              className="group rounded-2xl border border-border bg-card p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-md hover:border-primary/30"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition group-hover:bg-primary group-hover:text-primary-foreground">
                <s.icon className="h-5 w-5" strokeWidth={1.8} />
              </span>
              <h3 className="mt-4 font-display text-base font-semibold">{s.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="border-y border-border bg-secondary/40">
        <div className="mx-auto max-w-[80rem] px-5 py-20">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <p className="text-sm font-semibold uppercase tracking-wider text-accent">Step by Step</p>
            <h2 className="mt-2 font-display text-3xl font-bold tracking-tight sm:text-4xl">How Land Registration Works</h2>
            <p className="mt-3 text-muted-foreground">Follow these steps to successfully register your land and receive an official title certificate.</p>
          </div>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {STEPS.map((step, i) => (
              <motion.div
                key={step.num}
                initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.07 }}
                className="relative"
              >
                <div className="rounded-2xl border border-border bg-card p-6 shadow-sm h-full">
                  <div className="flex items-center gap-4 mb-4">
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-primary font-display text-lg font-extrabold text-primary-foreground">
                      {step.num}
                    </span>
                    {i < STEPS.length - 1 && (
                      <div className="hidden lg:block h-0.5 flex-1 bg-primary/20" />
                    )}
                  </div>
                  <h3 className="font-display text-base font-semibold">{step.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{step.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About / Photo section */}
      <section className="mx-auto max-w-[80rem] px-5 py-20">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <div className="relative">
            <img src={SURVEY} alt="Land surveyor at work in Techiman North District" className="w-full rounded-3xl object-cover shadow-lg" />
            <div className="absolute -bottom-6 -right-4 hidden rounded-2xl border border-border bg-card p-5 shadow-xl sm:block">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/15">
                  <Award className="h-5 w-5 text-amber-600" />
                </span>
                <div>
                  <p className="font-display text-base font-bold text-foreground">Act 1036 Compliant</p>
                  <p className="text-xs text-muted-foreground">Ghana Land Act 2020</p>
                </div>
              </div>
            </div>
          </div>
          <div>
            <p className="text-sm font-semibold uppercase tracking-wider text-accent">About the System</p>
            <h2 className="mt-2 font-display text-3xl font-bold tracking-tight sm:text-4xl">
              Built for Transparent, Accountable Land Governance
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              The Techiman North District Land Registry System is the official digital platform for managing all land administration activities within the district. Built in compliance with the Land Registration Act 2020 (Act 1036), it brings together registration, survey, documentation, and payment workflows under one secure platform.
            </p>
            <p className="mt-3 text-muted-foreground leading-relaxed">
              Seven specialized portals serve different stakeholders — from Physical Planning Officers reviewing applications, to Surveyors capturing boundary data, to Finance Officers processing payments — all with strict role-based access controls and immutable audit trails.
            </p>
            <ul className="mt-6 space-y-3">
              {[
                "Covers all 5 Area Councils in the district",
                "Real-time notifications and SMS updates",
                "Full Arabic and English support",
                "Integrated payment processing",
                "Complete ownership transfer workflow",
              ].map((item) => (
                <li key={item} className="flex items-center gap-2.5 text-sm">
                  <CheckCircle2 className="h-4 w-4 shrink-0 text-primary" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Security */}
      <section id="security" className="border-y border-border bg-primary">
        <div className="mx-auto max-w-[80rem] px-5 py-20">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <p className="text-sm font-semibold uppercase tracking-wider text-accent">Security & Compliance</p>
            <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Protected by Enterprise-Grade Security
            </h2>
            <p className="mt-3 text-primary-foreground/75">
              Every record is protected by multiple layers of security and compliant with Ghanaian law.
            </p>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {COMPLIANCE.map((c, i) => (
              <motion.div
                key={c.title}
                initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur"
              >
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent/20 text-accent">
                  <c.icon className="h-5 w-5" strokeWidth={1.8} />
                </span>
                <h3 className="mt-4 font-display text-base font-semibold text-white">{c.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-primary-foreground/70">{c.body}</p>
              </motion.div>
            ))}
          </div>
          <div className="mt-10 text-center">
            <p className="text-sm text-primary-foreground/60">
              Compliant with Ghana's Land Act (Act 1036) · Data Protection Act (Act 843) · Cybersecurity Act (Act 1038)
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="mx-auto max-w-[80rem] px-5 py-20">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.4fr]">
          <div>
            <p className="text-sm font-semibold uppercase tracking-wider text-accent">FAQ</p>
            <h2 className="mt-2 font-display text-3xl font-bold tracking-tight sm:text-4xl">Frequently Asked Questions</h2>
            <p className="mt-3 text-muted-foreground">Have a question not listed here? Contact the Techiman North District Assembly office.</p>
            <div className="mt-8 space-y-4">
              <div className="flex items-start gap-3">
                <Phone className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                <div>
                  <p className="text-sm font-medium">District Office</p>
                  <p className="text-sm text-muted-foreground">+233 XX XXX XXXX</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                <div>
                  <p className="text-sm font-medium">Email</p>
                  <p className="text-sm text-muted-foreground">info@tenda.gov.gh</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                <div>
                  <p className="text-sm font-medium">Office Location</p>
                  <p className="text-sm text-muted-foreground">Techiman North District Assembly, Tuobodom, Bono East Region</p>
                </div>
              </div>
            </div>
            <div className="mt-8 rounded-2xl border border-border bg-card p-6">
              <div className="flex items-center gap-3 mb-3">
                <img src={CITIZEN} alt="Land certificate holder" className="h-14 w-14 rounded-full object-cover" />
                <div>
                  <p className="text-sm font-semibold">"Fast and transparent"</p>
                  <p className="text-xs text-muted-foreground">District Land Registrar</p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                "The system has transformed how we handle land records — everything is searchable, auditable, and secure."
              </p>
            </div>
          </div>
          <div className="divide-y divide-border rounded-2xl border border-border bg-card px-6">
            {FAQS.map((faq) => (
              <FAQItem key={faq.q} q={faq.q} a={faq.a} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-br from-primary to-primary/90">
        <div className="mx-auto max-w-[80rem] px-5 py-16 text-center">
          <h2 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl">
            Ready to Manage Land Records Digitally?
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-primary-foreground/80">
            Access your role-based portal to register, manage, and verify land records across all Techiman North Area Councils.
          </p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
              <Link to="/auth">Sign in to Portal <ArrowRight className="ml-1 h-4 w-4" /></Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-white/30 bg-white/5 text-white hover:bg-white/15 hover:text-white">
              <a href="#services">Learn more</a>
            </Button>
          </div>
        </div>
      </section>

      <PublicFooter />
    </div>
  );
}
