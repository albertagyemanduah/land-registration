import { useState, useEffect } from "react";
import pb from "@/lib/pocketbaseClient";

/**
 * Loads all 4 hierarchy levels from PocketBase (non-deleted records only).
 * Returns { offices, areaCouncils, communities, sectors, loading }
 * All values are stored as record names (strings) in existing text fields.
 */
export function useHierarchy() {
  const [offices, setOffices] = useState([]);
  const [areaCouncils, setAreaCouncils] = useState([]);
  const [communities, setCommunities] = useState([]);
  const [sectors, setSectors] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      pb.collection("offices_struct").getFullList({ sort: "name", requestKey: "hier-off" }).catch(() => []),
      pb.collection("area_councils").getFullList({ sort: "name", expand: "office", requestKey: "hier-ac" }).catch(() => []),
      pb.collection("communities").getFullList({ sort: "name", expand: "areaCouncil", requestKey: "hier-comm" }).catch(() => []),
      pb.collection("sectors").getFullList({ sort: "name", expand: "community", requestKey: "hier-sect" }).catch(() => []),
    ]).then(([o, a, c, s]) => {
      const ok = (x) => x && !x.isDeleted && typeof x.name === "string" && x.name.trim() !== "";
      setOffices(o.filter(ok));
      setAreaCouncils(a.filter(ok));
      setCommunities(c.filter(ok));
      setSectors(s.filter(ok));
      setLoading(false);
    }).catch((err) => { console.error("Hierarchy load failed", err); setLoading(false); });
  }, []);

  /** Filter helpers (cascade by parent name) */
  const acForOffice = (officeName) => {
    if (!officeName) return areaCouncils;
    const office = offices.find((o) => o.name === officeName);
    if (!office) return areaCouncils;
    return areaCouncils.filter((a) => a.office === office.id);
  };

  const commForAC = (acName) => {
    if (!acName) return communities;
    const ac = areaCouncils.find((a) => a.name === acName);
    if (!ac) return communities;
    return communities.filter((c) => c.areaCouncil === ac.id);
  };

  const sectForComm = (commName) => {
    if (!commName) return sectors;
    const comm = communities.find((c) => c.name === commName);
    if (!comm) return sectors;
    return sectors.filter((s) => s.community === comm.id);
  };

  return { offices, areaCouncils, communities, sectors, loading, acForOffice, commForAC, sectForComm };
}
