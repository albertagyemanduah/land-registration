import React, { useEffect, useRef } from "react";
import { Route, Routes, BrowserRouter as Router, Navigate, useNavigate } from "react-router-dom";
import ScrollToTop from "./components/ScrollToTop";
import { AuthProvider, useAuth } from "@/lib/auth";
import { initTheme } from "@/lib/useTheme";
import { canAccess } from "@/lib/roles";
import LandingPage from "@/pages/LandingPage";
import AuthPage from "@/pages/AuthPage";
import DashboardLayout from "@/pages/dashboard/DashboardLayout";
import OverviewPage from "@/pages/dashboard/OverviewPage";
import ParcelsPage from "@/pages/dashboard/ParcelsPage";
import DocumentsPage from "@/pages/dashboard/DocumentsPage";
import SearchPage from "@/pages/dashboard/SearchPage";
import PaymentsPage from "@/pages/dashboard/PaymentsPage";
import ReportsPage from "@/pages/dashboard/ReportsPage";
import AdminPage from "@/pages/dashboard/AdminPage";
import StructurePage from "@/pages/dashboard/StructurePage";
import ChatPage from "@/pages/dashboard/ChatPage";
import ProfilePage from "@/pages/dashboard/ProfilePage";
import TicketsPage from "@/pages/dashboard/TicketsPage";
import TemplateDesignerPage from "@/pages/dashboard/TemplateDesignerPage";
import UserManualPage from "@/pages/dashboard/UserManualPage";
import UpdateNotificationsPage from "@/pages/dashboard/UpdateNotificationsPage";
import VerificationCodesPage from "@/pages/dashboard/VerificationCodesPage";
import AdminDataManagementPage from "@/pages/dashboard/AdminDataManagementPage";
import AboutPage from "@/pages/AboutPage";
import ServicesPage from "@/pages/ServicesPage";
import ContactPage from "@/pages/ContactPage";
import FAQPage from "@/pages/FAQPage";
import VerifyLandPage from "@/pages/VerifyLandPage";

const IDLE_MS = 20 * 60 * 1000; // 20-minute session timeout

function Protected({ children }) {
  const { isAuthed, logout } = useAuth();
  const navigate = useNavigate();
  const timer = useRef(null);

  useEffect(() => {
    if (!isAuthed) return;
    const reset = () => {
      clearTimeout(timer.current);
      timer.current = setTimeout(() => {
        logout();
        navigate("/auth");
      }, IDLE_MS);
    };
    const events = ["mousemove", "keydown", "click", "scroll", "touchstart"];
    events.forEach((e) => window.addEventListener(e, reset));
    reset();
    return () => {
      clearTimeout(timer.current);
      events.forEach((e) => window.removeEventListener(e, reset));
    };
  }, [isAuthed, logout, navigate]);

  if (!isAuthed) return <Navigate to="/auth" replace />;
  return children;
}

function ModuleGuard({ moduleKey, children }) {
  const { role, roles } = useAuth();
  const effective = roles.length > 0 ? roles : [role];
  if (!effective.some((r) => canAccess(r, moduleKey))) return <Navigate to="/app" replace />;
  return children;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/about" element={<AboutPage />} />
      <Route path="/services" element={<ServicesPage />} />
      <Route path="/contact" element={<ContactPage />} />
      <Route path="/faq" element={<FAQPage />} />
      <Route path="/verify-land" element={<VerifyLandPage />} />
      <Route path="/auth" element={<AuthPage />} />
      <Route
        path="/app"
        element={
          <Protected>
            <DashboardLayout />
          </Protected>
        }
      >
        <Route index element={<OverviewPage />} />
        <Route path="parcels" element={<ModuleGuard moduleKey="parcels"><ParcelsPage /></ModuleGuard>} />
        <Route path="documents" element={<ModuleGuard moduleKey="documents"><DocumentsPage /></ModuleGuard>} />
        <Route path="search" element={<ModuleGuard moduleKey="search"><SearchPage /></ModuleGuard>} />
        <Route path="payments" element={<ModuleGuard moduleKey="payments"><PaymentsPage /></ModuleGuard>} />
        <Route path="reports" element={<ModuleGuard moduleKey="reports"><ReportsPage /></ModuleGuard>} />
        <Route path="admin" element={<ModuleGuard moduleKey="admin"><AdminPage /></ModuleGuard>} />
        <Route path="structure" element={<ModuleGuard moduleKey="structure"><StructurePage /></ModuleGuard>} />
        <Route path="chat" element={<ModuleGuard moduleKey="chat"><ChatPage /></ModuleGuard>} />
        <Route path="chat/:userId" element={<ModuleGuard moduleKey="chat"><ChatPage /></ModuleGuard>} />
        <Route path="tickets" element={<ModuleGuard moduleKey="tickets"><TicketsPage /></ModuleGuard>} />
        <Route path="template-designer" element={<ModuleGuard moduleKey="template-designer"><TemplateDesignerPage /></ModuleGuard>} />
        <Route path="manual" element={<ModuleGuard moduleKey="manual"><UserManualPage /></ModuleGuard>} />
        <Route path="update-notifications" element={<ModuleGuard moduleKey="update-notifications"><UpdateNotificationsPage /></ModuleGuard>} />
        <Route path="verification-codes" element={<ModuleGuard moduleKey="verification-codes"><VerificationCodesPage /></ModuleGuard>} />
        <Route path="data-management" element={<ModuleGuard moduleKey="data-management"><AdminDataManagementPage /></ModuleGuard>} />
        <Route path="profile" element={<ProfilePage />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function App() {
  useEffect(() => { initTheme(); }, []);
  return (
    <AuthProvider>
      <Router>
        <ScrollToTop />
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}

export default App;
